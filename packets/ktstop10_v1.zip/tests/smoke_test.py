from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
config = json.loads((root / 'runtime' / 'ktstop10_config.json').read_text(encoding='utf-8'))
assert manifest['run_mode'] == 'RUN_STOPSEQ_10ROW_PROMPT_PROBE_V1'
assert manifest['kaggle_dataset_name'] == 'ktstop10-v1'
assert manifest['training_authority'] is False
assert manifest['production_prompt_mutation_authority'] is False
assert len(config['rows']) == 10
assert {arm['arm_id'] for arm in config['prompt_arm_manifest']['arms']} == {'A0_CURRENT_PROMPT', 'A1_STOP_AFTER_FINAL_ANSWER'}
assert all('expected_answer' not in row for row in config['rows'])
