from __future__ import annotations

import hashlib
import json
import os
import re
import time
import zipfile
from pathlib import Path


RUN_MODE = "RUN_STOPSEQ_10ROW_PROMPT_PROBE_V1"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
HF_RESULTS_REPO = os.environ.get("KT_HF_RESULTS_REPO", "Kinrokin/ktstop10-v1-results")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def extract_answer(text: str):
    patterns = [
        r"FINAL_ANSWER\s*:\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"####\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"final answer\s*(?:is|:)?\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"answer\s*(?:is|:)?\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return match.group(1).replace("$", "").replace(",", "").strip()
    numbers = re.findall(r"[-+]?\$?[\d,]+(?:\.\d+)?", text)
    return numbers[-1].replace("$", "").replace(",", "").strip() if numbers else None


def final_marker_span(text: str):
    return re.search(r"FINAL_ANSWER\s*:\s*[-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?", text, re.I)


def render_prompt(template: str, question: str) -> str:
    return f"{template}\n\nProblem:\n{question}\n"


def version_tuple(value: str):
    nums = []
    for part in re.split(r"[.+-]", value):
        if part.isdigit():
            nums.append(int(part))
        else:
            break
    return tuple(nums)


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    try:
        import bitsandbytes as bnb
    except Exception as exc:
        raise RuntimeError(f"bitsandbytes unavailable: {exc}") from exc
    bnb_version = getattr(bnb, "__version__", "0.0.0")
    if version_tuple(bnb_version) < (0, 46, 1):
        raise RuntimeError(f"bitsandbytes>=0.46.1 required, found {bnb_version}")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    use_4bit = os.environ.get("KT_LOAD_IN_4BIT", "1") != "0"
    kwargs = {"device_map": "auto", "trust_remote_code": True}
    if use_4bit:
        kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, **kwargs)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer, {"schema_id": "kt.ktstop10.model_loader_receipt.v1", "status": "PASS", "model_repo": MODEL_REPO, "bitsandbytes_version": bnb_version, "load_in_4bit_via_quantization_config": use_4bit}


def generate(model, tokenizer, prompt: str, max_new_tokens: int):
    import torch
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    start = time.time()
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    latency_seconds = time.time() - start
    generated = output_ids[0][inputs["input_ids"].shape[-1]:]
    text = tokenizer.decode(generated, skip_special_tokens=True)
    return text, int(inputs["input_ids"].shape[-1]), int(generated.shape[-1]), latency_seconds


def score(expected: str, extracted: str | None) -> bool:
    return normalize(expected) == normalize(extracted)


def write_blocker(outdir: Path, status: str, reason: str) -> None:
    payload = {
        "schema_id": "kt.ktstop10.blocker_receipt.runtime.v1",
        "status": status,
        "reason": reason,
        "run_mode": RUN_MODE,
        "training_authority": False,
        "promotion_authority": False,
        "selector_deployment_authority": False,
        "adapter_mutation_authority": False,
        "production_prompt_mutation_authority": False,
        "production_math_mode_claim": False,
        "claim_ceiling_status": "PRESERVED",
    }
    write_json(outdir / "BLOCKER_RECEIPT.json", payload)


def maybe_upload_to_hf(outdir: Path, assessment_zip: Path) -> dict:
    token = os.environ.get("HF_TOKEN")
    if not token:
        return {"schema_id": "kt.ktstop10.hf_upload_receipt.v1", "status": "SKIPPED_NO_HF_TOKEN", "repo_id": HF_RESULTS_REPO}
    try:
        from huggingface_hub import HfApi, create_repo, upload_file, upload_folder
        create_repo(HF_RESULTS_REPO, repo_type="dataset", private=False, exist_ok=True, token=token)
        upload_folder(repo_id=HF_RESULTS_REPO, repo_type="dataset", folder_path=str(outdir), path_in_repo="artifacts", token=token)
        upload_file(repo_id=HF_RESULTS_REPO, repo_type="dataset", path_or_fileobj=str(assessment_zip), path_in_repo=assessment_zip.name, token=token)
        info = HfApi(token=token).dataset_info(HF_RESULTS_REPO)
        return {"schema_id": "kt.ktstop10.hf_upload_receipt.v1", "status": "PASS", "repo_id": HF_RESULTS_REPO, "url": f"https://huggingface.co/datasets/{HF_RESULTS_REPO}", "private": bool(info.private)}
    except Exception as exc:
        return {"schema_id": "kt.ktstop10.hf_upload_receipt.v1", "status": "FAILED_NON_FATAL", "repo_id": HF_RESULTS_REPO, "error": str(exc)}


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktstop10_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop10_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    events = [{"event": "start", "run_mode": RUN_MODE, "row_count": len(config["rows"])}]
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP10_V1_ASSESSMENT_ONLY.zip"))
    try:
        write_json(outdir / "PACKET_MANIFEST_RUN.json", {"schema_id": "kt.ktstop10.packet_manifest_run.v1", "run_mode": RUN_MODE, "packet_manifest": config["packet_manifest"], "claim_ceiling_status": "PRESERVED"})
        write_json(outdir / "row_manifest.json", {"schema_id": "kt.ktstop10.runtime_row_manifest.v1", "rows": config["rows"], "row_count": len(config["rows"]), "claim_ceiling_status": "PRESERVED"})
        write_json(outdir / "prompt_arm_manifest.json", config["prompt_arm_manifest"])
        write_json(outdir / "claim_boundary_receipt.json", config["claim_boundary"])
        model, tokenizer, loader_receipt = load_model()
        write_json(outdir / "model_loader_receipt.json", loader_receipt)
        predictions = []
        token_rows = []
        baseline_correct_by_row = {}
        for row in config["rows"]:
            expected = config["scorer_expected_answers"][row["row_id"]]
            for arm in config["prompt_arm_manifest"]["arms"]:
                prompt = render_prompt(arm["template_text"], row["question"])
                # Gold fields are not rendered. Native answer literals inside a question are not treated as leakage.
                output, prompt_tokens, output_tokens, latency_seconds = generate(model, tokenizer, prompt, int(arm["max_new_tokens"]))
                extracted = extract_answer(output)
                correct = score(expected, extracted)
                if arm["arm_id"] == "A0_CURRENT_PROMPT":
                    baseline_correct_by_row[row["row_id"]] = correct
                marker = final_marker_span(output)
                trailer = output[marker.end():].strip() if marker else ""
                record = {
                    "schema_id": "kt.ktstop10.prediction_row.v1",
                    "row_id": row["row_id"],
                    "row_bucket": row["row_bucket"],
                    "source_artifact": row["source_artifact"],
                    "question_hash": row["question_hash"],
                    "rendered_prompt_hash": sha256_text(prompt),
                    "arm_id": arm["arm_id"],
                    "output_hash": sha256_text(output),
                    "raw_output": output,
                    "extracted_answer": extracted,
                    "correct": correct,
                    "extraction_success": extracted is not None,
                    "final_answer_marker_present": marker is not None,
                    "trailer_present": bool(trailer),
                    "tokens_after_final_answer": len(tokenizer(trailer, return_tensors="pt")["input_ids"][0]) if trailer else 0,
                    "chars_after_final_answer": len(trailer),
                    "post_final_marker_text_hash": sha256_text(trailer) if trailer else None,
                    "control_damage": False,
                    "prompt_tokens_if_available": prompt_tokens,
                    "output_tokens_if_available": output_tokens,
                    "latency_seconds": round(latency_seconds, 3),
                    "claim_ceiling_status": "PRESERVED",
                }
                if arm["arm_id"] == "A1_STOP_AFTER_FINAL_ANSWER" and row["control_flag"]:
                    record["control_damage"] = bool(baseline_correct_by_row.get(row["row_id"]) and not correct)
                predictions.append(record)
                token_rows.append({"schema_id": "kt.ktstop10.token_ledger_row.v1", "row_id": row["row_id"], "arm_id": arm["arm_id"], "prompt_tokens": prompt_tokens, "output_tokens": output_tokens, "tokens_after_final_answer": record["tokens_after_final_answer"]})
        write_jsonl(outdir / "predictions.jsonl", predictions)
        write_jsonl(outdir / "token_ledger.jsonl", token_rows)
        a0 = [row for row in predictions if row["arm_id"] == "A0_CURRENT_PROMPT"]
        a1 = [row for row in predictions if row["arm_id"] == "A1_STOP_AFTER_FINAL_ANSWER"]
        a0_trailer = sum(1 for row in a0 if row["trailer_present"]) / max(len(a0), 1)
        a1_trailer = sum(1 for row in a1 if row["trailer_present"]) / max(len(a1), 1)
        a0_correct = sum(1 for row in a0 if row["correct"])
        a1_correct = sum(1 for row in a1 if row["correct"])
        control_damage_count = sum(1 for row in a1 if row["control_damage"])
        pass_gate = ((a1_trailer <= 0.20 or (a1_trailer - a0_trailer) <= -0.50) and control_damage_count == 0 and a1_correct >= a0_correct)
        scorecard = {
            "schema_id": "kt.ktstop10.scorecard.v1",
            "run_mode": RUN_MODE,
            "a0_trailer_rate": round(a0_trailer, 4),
            "a1_trailer_rate": round(a1_trailer, 4),
            "trailer_rate_delta": round(a1_trailer - a0_trailer, 4),
            "a0_correct": a0_correct,
            "a1_correct": a1_correct,
            "correctness_delta": a1_correct - a0_correct,
            "control_damage_count": control_damage_count,
            "extraction_success_delta": sum(1 for row in a1 if row["extraction_success"]) - sum(1 for row in a0 if row["extraction_success"]),
            "a0_tokens_after_final_answer_total": sum(row["tokens_after_final_answer"] for row in a0),
            "a1_tokens_after_final_answer_total": sum(row["tokens_after_final_answer"] for row in a1),
            "pass_gate": pass_gate,
            "next_lane_suggestion": "RUN_40ROW_KTCF_STOPSEQ_CONFIRMATION_OR_FORGE_IF_NO_LOCAL_RUNTIME" if pass_gate else "AUTHOR_KTCFFIX_CANONICALIZER_V2_CONFIRMATION_PACKET_V1",
            "claim_ceiling_status": "PRESERVED",
        }
        final_summary = {
            "schema_id": "kt.ktstop10.final_summary.v1",
            "status": "PASS_MODEL_GENERATED_AND_SCORED",
            "run_mode": RUN_MODE,
            "row_count": len(config["rows"]),
            "arm_count": len(config["prompt_arm_manifest"]["arms"]),
            "prediction_count": len(predictions),
            "pass_gate": pass_gate,
            "claim_ceiling_status": "PRESERVED",
        }
        write_json(outdir / "stopseq_scorecard.json", scorecard)
        write_json(outdir / "final_summary.json", final_summary)
        events.append({"event": "completed", "status": final_summary["status"], "pass_gate": pass_gate})
    except Exception as exc:
        write_blocker(outdir, "KT_STOP10_RUNTIME_BLOCKED", str(exc))
        write_json(outdir / "model_loader_receipt.json", {"schema_id": "kt.ktstop10.model_loader_receipt.v1", "status": "BLOCKED", "reason": str(exc), "model_repo": MODEL_REPO})
        events.append({"event": "blocked", "reason": str(exc)})
        assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP10_V1_BLOCKER_ASSESSMENT_ONLY.zip"))
    write_jsonl(outdir / "run_events.jsonl", events)
    with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(outdir.iterdir()):
            zf.write(path, path.name)
    upload_receipt = maybe_upload_to_hf(outdir, assessment)
    write_json(outdir / "HF_UPLOAD_RECEIPT.json", upload_receipt)
    with zipfile.ZipFile(assessment, "a", zipfile.ZIP_DEFLATED) as zf:
        zf.write(outdir / "HF_UPLOAD_RECEIPT.json", "HF_UPLOAD_RECEIPT.json")
    print(str(assessment))


if __name__ == "__main__":
    main()
