import os
import zipfile
from pathlib import Path

os.environ.setdefault("KT_OUTPUT_MODE", "ASSESSMENT_ONLY")
os.environ.setdefault("KT_QUIET_LOGS", "1")
os.environ.setdefault("KT_SUPPRESS_PROGRESS_BARS", "1")
os.environ.setdefault("KT_PRINT_JSON_EVENTS_ONLY", "1")
os.environ.setdefault("KT_NO_FULL_TEXT_DUMPS", "1")
os.environ.setdefault("KT_UPLOAD_EVIDENCE_TO_HF", "1")
os.environ.setdefault("KT_HF_PRIVATE", "1")

packet = Path("/kaggle/input/ktbud100-v1/ktbud100_v1.zip")
if not packet.exists():
    packet = Path("ktbud100_v1.zip")

work = Path("/kaggle/working/ktbud100_packet")
work.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(packet) as zf:
    zf.extractall(work)

exec((work / "runtime" / "KT_CANONICAL_RUNNER.py").read_text(encoding="utf-8"))
