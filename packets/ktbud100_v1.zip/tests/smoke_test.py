import zipfile
from pathlib import Path

def test_packet_shape():
    z=Path('ktbud100_v1.zip')
    if z.exists():
        with zipfile.ZipFile(z) as f:
            assert 'runtime/KT_CANONICAL_RUNNER.py' in f.namelist()
