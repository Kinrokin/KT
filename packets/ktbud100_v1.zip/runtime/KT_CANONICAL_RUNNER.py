from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path


RUN_MODE = "RUN_KT_BUDGET_MONITOR_GSM8K_100"
ASSESSMENT_ZIP = "KT_BUD100_V1_ASSESSMENT_ONLY.zip"
MODEL_NAME = os.environ.get("KT_BUD100_MODEL", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
ROW_START = int(os.environ.get("KT_BUD100_ROW_START", "25"))
ROW_COUNT = int(os.environ.get("KT_BUD100_ROW_COUNT", "100"))
QUIET = os.environ.get("KT_QUIET_LOGS", "1") == "1"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def emit(event: dict) -> None:
    event.setdefault("ts", utc_now())
    print(json.dumps(event, sort_keys=True), flush=True)


def write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def append_jsonl(path: Path, row: dict) -> None:
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, sort_keys=True) + "\n")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def normalize_answer(value: str | None) -> str | None:
    if value is None:
        return None
    return str(value).strip().replace(",", "")


def extract_answer(text: str) -> str | None:
    patterns = [
        r"####\s*(-?[\d,]+(?:\.\d+)?)",
        r"final answer\s*:\s*(-?[\d,]+(?:\.\d+)?)",
        r"answer\s*:\s*(-?[\d,]+(?:\.\d+)?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return normalize_answer(match.group(1))
    matches = re.findall(r"-?[\d,]+(?:\.\d+)?", text)
    return normalize_answer(matches[-1]) if matches else None


def final_marker_detected(text: str) -> bool:
    return any(
        re.search(pattern, text, re.IGNORECASE)
        for pattern in [
            r"####\s*-?[\d,]+(?:\.\d+)?",
            r"final answer\s*:\s*-?[\d,]+(?:\.\d+)?",
            r"answer\s*:\s*-?[\d,]+(?:\.\d+)?",
        ]
    )


def answer_from_gsm8k(raw: str) -> str:
    if "####" in raw:
        return normalize_answer(raw.split("####")[-1])
    return normalize_answer(extract_answer(raw) or raw)


def prompt_for(question: str, answer_only: bool = False) -> str:
    if answer_only:
        return f"Answer with only the final numeric answer.\n\n{question}"
    return (
        "Solve the following grade-school math problem step by step. "
        "End with exactly 'Final answer: <number>'.\n\n"
        f"Problem: {question}\n\nSolution:"
    )


def token_count(tokenizer, text: str) -> int:
    return len(tokenizer(text, add_special_tokens=False).input_ids)


def generate_once(model, tokenizer, prompt: str, max_new_tokens: int) -> tuple[str, int]:
    import torch

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {key: value.to(model.device) for key, value in inputs.items()}
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            temperature=None,
            top_p=None,
            pad_token_id=tokenizer.eos_token_id,
        )
    generated_ids = outputs[0][inputs["input_ids"].shape[-1] :]
    text = tokenizer.decode(generated_ids, skip_special_tokens=True)
    return text, len(generated_ids)


def ensure_deps() -> None:
    try:
        import datasets  # noqa: F401
        import transformers  # noqa: F401
    except Exception:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "datasets", "transformers", "accelerate", "bitsandbytes"])


def load_model():
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, trust_remote_code=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    quantization_config = BitsAndBytesConfig(load_in_4bit=True)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        device_map="auto",
        quantization_config=quantization_config,
        trust_remote_code=True,
    )
    return model, tokenizer


def score_row(row, arm, output_text: str, prompt_tokens: int, output_tokens: int, extensions: int, stop_reason: str) -> dict:
    expected = answer_from_gsm8k(row["answer"])
    extracted = extract_answer(output_text)
    correct = extracted == expected
    return {
        "row_id": row["row_id"],
        "row_index": row["row_index"],
        "source": "openai/gsm8k:test",
        "arm_id": arm["arm_id"],
        "mode": arm["mode"],
        "task_class": "multi_step_math",
        "budget": arm.get("max_new_tokens") or arm.get("hard_ceiling"),
        "budget_extensions_used": extensions,
        "budget_cap_hit": output_tokens >= int(arm.get("max_new_tokens") or arm.get("hard_ceiling") or output_tokens),
        "stop_reason": stop_reason,
        "final_marker_detected": final_marker_detected(output_text),
        "expected_hash": sha256_text(expected or ""),
        "extracted_answer": extracted,
        "correct": correct,
        "answer_format_pass": extracted is not None,
        "prompt_tokens": prompt_tokens,
        "output_tokens": output_tokens,
        "total_tokens": prompt_tokens + output_tokens,
        "output_hash": sha256_text(output_text),
        "training_authority": False,
        "production_prompt_mutation_authority": False,
        "adapter_enabled": False,
        "preliminary_owner_candidate": "TOKEN_BUDGET_OWNED" if not correct and arm["arm_id"].startswith("A0_") else ("UNKNOWN_REQUIRES_G32" if not correct else "NONE_CORRECT"),
    }


def summarize(rows: list[dict]) -> list[dict]:
    out = []
    for arm_id in sorted({row["arm_id"] for row in rows}):
        arm_rows = [row for row in rows if row["arm_id"] == arm_id]
        total = len(arm_rows)
        correct = sum(1 for row in arm_rows if row["correct"])
        prompt_tokens = sum(row["prompt_tokens"] for row in arm_rows)
        output_tokens = sum(row["output_tokens"] for row in arm_rows)
        total_tokens = sum(row["total_tokens"] for row in arm_rows)
        out.append(
            {
                "arm_id": arm_id,
                "total": total,
                "correct": correct,
                "accuracy": correct / total if total else 0.0,
                "prompt_tokens": prompt_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
                "full_tokens_per_correct": total_tokens / correct if correct else None,
                "output_tokens_per_correct": output_tokens / correct if correct else None,
                "budget_extensions_mean": sum(row["budget_extensions_used"] for row in arm_rows) / total if total else 0.0,
                "budget_cap_hit_rate": sum(1 for row in arm_rows if row["budget_cap_hit"]) / total if total else 0.0,
                "final_marker_rate": sum(1 for row in arm_rows if row["final_marker_detected"]) / total if total else 0.0,
            }
        )
    return out


def main() -> int:
    start = time.time()
    os.environ.setdefault("KT_OUTPUT_MODE", "ASSESSMENT_ONLY")
    os.environ.setdefault("KT_QUIET_LOGS", "1")
    os.environ.setdefault("KT_SUPPRESS_PROGRESS_BARS", "1")
    os.environ.setdefault("KT_PRINT_JSON_EVENTS_ONLY", "1")
    os.environ.setdefault("KT_NO_FULL_TEXT_DUMPS", "1")
    os.environ.setdefault("KT_UPLOAD_EVIDENCE_TO_HF", "1")
    os.environ.setdefault("KT_HF_PRIVATE", "1")

    work = Path.cwd() / "ktbud100_v1_run"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    for name in ["budget_predictions.jsonl", "token_ledger.jsonl", "budget_extension_ledger.jsonl", "run_events.jsonl"]:
        (work / name).write_text("", encoding="utf-8")

    emit({"event": "run_start", "run_mode": RUN_MODE, "model": MODEL_NAME, "row_start": ROW_START, "row_count": ROW_COUNT})
    ensure_deps()
    from datasets import load_dataset

    dataset = load_dataset("openai/gsm8k", "main", split="test")
    selected = []
    for idx in range(ROW_START, ROW_START + ROW_COUNT):
        row = dict(dataset[idx])
        row["row_index"] = idx
        row["row_id"] = f"gsm8k_test_{idx:03d}"
        selected.append(row)
    emit({"event": "dataset_loaded", "rows": len(selected), "source": f"openai/gsm8k:test[{ROW_START}:{ROW_START+ROW_COUNT}]"})

    row_manifest = {
        "schema_id": "kt.bud100.runtime_row_manifest.v1",
        "row_count": len(selected),
        "primary_slice": f"GSM8K test[{ROW_START}:{ROW_START+ROW_COUNT}]",
        "overlap_with_bud25": ROW_START < 25,
        "rows": [
            {
                "row_id": row["row_id"],
                "row_index": row["row_index"],
                "source": "openai/gsm8k:test",
                "task_class": "multi_step_math",
                "expected_answer_hash": sha256_text(answer_from_gsm8k(row["answer"]) or ""),
                "expected_answer_model_visible": False,
                "training_use_authority": False,
            }
            for row in selected
        ],
    }
    write_json(work / "row_manifest.json", row_manifest)

    arms = [
        {"arm_id": "A0_COT_96_FIXED", "mode": "fixed", "max_new_tokens": 96},
        {"arm_id": "A1_COT_256_FIXED", "mode": "fixed", "max_new_tokens": 256},
        {"arm_id": "A2_COT_512_FIXED", "mode": "fixed", "max_new_tokens": 512},
        {"arm_id": "A3_ADAPTIVE_MONITOR", "mode": "adaptive", "initial_tokens": 256, "extension_size": 128, "max_extensions": 2, "hard_ceiling": 512},
        {"arm_id": "A4_ANSWER_ONLY_96", "mode": "answer_only", "max_new_tokens": 96},
        {"arm_id": "A5_ORACLE_DIAGNOSTIC", "mode": "oracle_diagnostic", "model_generation": False},
    ]
    write_json(work / "budget_arm_manifest.json", {"schema_id": "kt.bud100.budget_arm_manifest.v1", "arms": arms})
    write_json(work / "task_class_budget_config.json", {"schema_id": "kt.task_class_budget_policy.v1", "policy_id": "BUDGET_MONITOR_MATH_V1", "classes": {"multi_step_math": {"initial_tokens": 256, "extension_size": 128, "max_extensions": 2, "hard_ceiling": 512}}})

    model, tokenizer = load_model()
    prediction_rows = []
    oracle_rows = []
    for row in selected:
        for arm in arms:
            if arm["mode"] == "oracle_diagnostic":
                expected = answer_from_gsm8k(row["answer"])
                record = {
                    "row_id": row["row_id"],
                    "row_index": row["row_index"],
                    "source": "openai/gsm8k:test",
                    "arm_id": arm["arm_id"],
                    "mode": arm["mode"],
                    "task_class": "multi_step_math",
                    "budget": 0,
                    "budget_extensions_used": 0,
                    "budget_cap_hit": False,
                    "stop_reason": "oracle_diagnostic_no_model_generation",
                    "final_marker_detected": True,
                    "expected_hash": sha256_text(expected or ""),
                    "extracted_answer": expected,
                    "correct": True,
                    "answer_format_pass": True,
                    "prompt_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "output_hash": sha256_text(expected or ""),
                    "training_authority": False,
                    "production_prompt_mutation_authority": False,
                    "adapter_enabled": False,
                    "preliminary_owner_candidate": "SCORER_ORACLE_DIAGNOSTIC_ONLY",
                }
                oracle_rows.append(record)
            else:
                answer_only = arm["mode"] == "answer_only"
                prompt = prompt_for(row["question"], answer_only=answer_only)
                prompt_tokens = token_count(tokenizer, prompt)
                if arm["mode"] == "adaptive":
                    chunks = []
                    total_output_tokens = 0
                    extensions = 0
                    stop_reason = "budget_cap"
                    current_prompt = prompt
                    for step in range(1 + arm["max_extensions"]):
                        budget = arm["initial_tokens"] if step == 0 else arm["extension_size"]
                        text, out_tokens = generate_once(model, tokenizer, current_prompt, budget)
                        chunks.append(text)
                        total_output_tokens += out_tokens
                        joined = "".join(chunks)
                        if final_marker_detected(joined):
                            stop_reason = "final_marker_detected"
                            break
                        if step < arm["max_extensions"]:
                            extensions += 1
                            current_prompt = prompt + joined
                    output_text = "".join(chunks)
                    output_tokens = total_output_tokens
                else:
                    output_text, output_tokens = generate_once(model, tokenizer, prompt, arm["max_new_tokens"])
                    extensions = 0
                    stop_reason = "fixed_budget"
                record = score_row(row, arm, output_text, prompt_tokens, output_tokens, extensions, stop_reason)
            prediction_rows.append(record)
            append_jsonl(work / "budget_predictions.jsonl", record)
            append_jsonl(work / "token_ledger.jsonl", {key: record[key] for key in ["row_id", "arm_id", "prompt_tokens", "output_tokens", "total_tokens", "budget_extensions_used"]})
            append_jsonl(work / "budget_extension_ledger.jsonl", {key: record[key] for key in ["row_id", "arm_id", "budget_extensions_used", "budget_cap_hit", "final_marker_detected", "stop_reason"]})
            append_jsonl(work / "run_events.jsonl", {"event": "row_done", "row_id": row["row_id"], "arm": arm["arm_id"], "correct": record["correct"], "output_tokens": record["output_tokens"], "extensions": record["budget_extensions_used"], "stop_reason": record["stop_reason"]})

    scorecard = summarize(prediction_rows)
    oracle_score = next((row["accuracy"] for row in scorecard if row["arm_id"] == "A5_ORACLE_DIAGNOSTIC"), 0.0)
    adaptive = next((row for row in scorecard if row["arm_id"] == "A3_ADAPTIVE_MONITOR"), {})
    answer_only = next((row for row in scorecard if row["arm_id"] == "A4_ANSWER_ONLY_96"), {})
    cot512 = next((row for row in scorecard if row["arm_id"] == "A2_COT_512_FIXED"), {})

    interpretation = "TOKEN_BUDGET_NOT_GENERALIZED__CAPABILITY_OR_DATA_NEXT"
    if oracle_score < 0.98:
        interpretation = "BUD100_PROMPT_OR_SCORER_CONCLUSIONS_BLOCKED"
    elif adaptive.get("accuracy", 0) >= 0.65 and abs(adaptive.get("accuracy", 0) - cot512.get("accuracy", 0)) <= 0.05 and (adaptive.get("full_tokens_per_correct") or 1e18) < (cot512.get("full_tokens_per_correct") or 0):
        interpretation = "ADAPTIVE_MONITOR_STRONG_CONFIRMATION_SUPPORTED"
    elif adaptive.get("accuracy", 0) >= 0.55 and adaptive.get("accuracy", 0) > answer_only.get("accuracy", 0) + 0.20:
        interpretation = "ADAPTIVE_MONITOR_CONFIRMATION_SUPPORTED"
    elif cot512.get("accuracy", 0) >= 0.55:
        interpretation = "TOKEN_BUDGET_SUPPORTED__MONITOR_POLICY_NEEDS_REPAIR"

    write_json(work / "budget_probe_scorecard.json", {"schema_id": "kt.bud100.budget_probe_scorecard.v1", "scorecard": scorecard, "interpretation": interpretation})
    write_json(work / "oracle_diagnostic_receipt.json", {"schema_id": "kt.bud100.oracle_diagnostic_receipt.v1", "oracle_score": oracle_score, "rows": oracle_rows, "status": "PASS" if oracle_score >= 0.98 else "BLOCKED"})
    write_json(work / "claim_boundary_receipt.json", {"schema_id": "kt.bud100.claim_boundary_receipt.v1", "claim_ceiling_preserved": True, "runtime_authority": False, "dataset_generation_authority": False, "training_authority": False, "promotion_authority": False, "adapter_mutation_authority": False, "production_prompt_mutation_authority": False})
    write_json(work / "final_summary.json", {"schema_id": "kt.bud100.final_summary.v1", "run_mode": RUN_MODE, "model": MODEL_NAME, "row_count": len(selected), "scorecard": scorecard, "oracle_diagnostic_score": oracle_score, "interpretation": interpretation, "elapsed_seconds": time.time() - start, "authority": {"claim_ceiling_preserved": True, "runtime_authority": False, "dataset_generation_authority": False, "training_authority": False, "promotion_authority": False, "adapter_mutation_authority": False, "production_prompt_mutation_authority": False}})
    write_json(work / "PACKET_MANIFEST_RUN.json", {"schema_id": "kt.bud100.packet_manifest_run.v1", "created_utc": utc_now(), "files": sorted(p.name for p in work.iterdir() if p.is_file())})

    assessment = Path.cwd() / ASSESSMENT_ZIP
    if assessment.exists():
        assessment.unlink()
    with zipfile.ZipFile(assessment, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(work.iterdir()):
            if path.is_file():
                zf.write(path, path.name)
    emit({"event": "run_done", "assessment_zip": str(assessment), "interpretation": interpretation})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
