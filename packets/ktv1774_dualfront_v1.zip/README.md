# KTV1774 DualFront V1

Runs the reasoning-preserving admission bench: correctness and compression are measured together. The packet preserves bounded reasoning for math, emits compact visible answers, scores final visible answers, and keeps oracle shadow non-runtime. No training, promotion, V18, router-superiority, commercial, frontier, S-tier, 7B, or multi-lobe claim is authorized.
