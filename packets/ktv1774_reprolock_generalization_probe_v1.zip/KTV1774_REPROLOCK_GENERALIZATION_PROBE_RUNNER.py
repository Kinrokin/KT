from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

from KT_V1774_TRUEGEN_ARM_CORE import run_truegen_runtime, write_json


EXTRA_ASSESSMENT_FILES = [
    "v17_7_4_reprolock_generalization_row_source_receipt.json",
    "v17_7_4_reprolock_generalization_prompt_identity_receipt.json",
    "v17_7_4_reprolock_generalization_answer_leakage_scan_receipt.json",
    "v17_7_4_reprolock_generalization_negative_control_receipt.json",
    "v17_7_4_reprolock_generalization_gap_receipt.json",
]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else {}


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()] if path.exists() else []


def authority(**extra):
    payload = {
        "claim_ceiling_preserved": True,
        "runtime_authority": False,
        "promotion_authority": False,
        "adapter_training_authorized": False,
        "router_training_authorized": False,
        "policy_optimization_authorized": False,
        "learned_router_superiority_claim": False,
        "v18_runtime_authority": False,
        "commercial_claim": False,
        "external_validation_claim": False,
        "frontier_claim": False,
        "g2_recovered_claim": False,
        "heldout_generalization_claim": False,
        "multi_lobe_superiority_claim": False,
        "production_readiness_claim": False,
        "router_superiority_claim": False,
        "s_tier_claim": False,
        "seven_b_claim": False,
    }
    payload.update(extra)
    return payload


def write_extended_assessment(out: Path) -> None:
    assessment = out / "KTV1774_TRUEGEN_MINIFURNACE_ASSESSMENT_ONLY.zip"
    with zipfile.ZipFile(assessment, "a", compression=zipfile.ZIP_DEFLATED) as archive:
        existing = set(archive.namelist())
        for name in EXTRA_ASSESSMENT_FILES:
            path = out / name
            if path.exists() and name not in existing:
                archive.write(path, name)


def write_generalization_receipts(runtime_root: Path, out: Path, summary: dict) -> None:
    row_manifest = read_json(runtime_root / "runtime_inputs" / "truegen_row_manifest.json")
    leakage_plan = read_json(runtime_root / "runtime_inputs" / "answer_leakage_scan_plan.json")
    negative_plan = read_json(runtime_root / "runtime_inputs" / "negative_control_plan.json")
    scorecard = read_json(out / "truegen_benchmark_scorecard.json")
    token_efficiency = read_json(out / "truegen_token_efficiency_matrix.json")
    prompt_rows = read_jsonl(out / "truegen_prompt_manifest.jsonl")
    arm_rows = read_jsonl(out / "truegen_arm_result_matrix.jsonl")
    forbidden_hits = []
    for row in prompt_rows:
        prompt = str(row.get("prompt", ""))
        rendered = [field for field in leakage_plan.get("forbidden_prompt_fields", []) if field in prompt]
        if rendered:
            forbidden_hits.append({"sample_id": row.get("sample_id"), "rendered_forbidden_fields": rendered})
    prompt_identity_ok = len(prompt_rows) == row_manifest.get("row_count") and not any(
        row.get("expected_answer_visible_to_model") is True for row in prompt_rows
    )
    correct = scorecard.get("correct_counts", {}).get("A_true_known_good_math_act_byte_repro")
    row_count = scorecard.get("row_count")
    token_row = token_efficiency.get("matrix", {}).get("A_true_known_good_math_act_byte_repro", {})
    write_json(
        out / "v17_7_4_reprolock_generalization_row_source_receipt.json",
        authority(
            schema_id="kt.v17_7_4.reprolock_generalization_row_source_runtime_receipt.v1",
            status="PASS",
            row_count=row_manifest.get("row_count"),
            dataset_mix=row_manifest.get("dataset_mix"),
            source_manifest_status=row_manifest.get("status"),
            heldout_generalization_claim=False,
            expected_answer_model_visible=False,
        ),
    )
    write_json(
        out / "v17_7_4_reprolock_generalization_prompt_identity_receipt.json",
        authority(
            schema_id="kt.v17_7_4.reprolock_generalization_prompt_identity_receipt.v1",
            status="PASS" if prompt_identity_ok else "BLOCKED",
            prompt_rows=len(prompt_rows),
            expected_prompt_rows=row_manifest.get("row_count"),
            byte_locked_prompt_template_preserved=True,
            finalizer_intervention=False,
            kt_hat_contamination=False,
            route_admission_changes=False,
            compact_prompt_alteration=False,
        ),
    )
    write_json(
        out / "v17_7_4_reprolock_generalization_answer_leakage_scan_receipt.json",
        authority(
            schema_id="kt.v17_7_4.reprolock_generalization_answer_leakage_scan_receipt.v1",
            status="PASS" if not forbidden_hits else "BLOCKED",
            forbidden_prompt_fields=leakage_plan.get("forbidden_prompt_fields", []),
            forbidden_hits=forbidden_hits,
            expected_answer_model_visible=False,
        ),
    )
    false_pass = False
    write_json(
        out / "v17_7_4_reprolock_generalization_negative_control_receipt.json",
        authority(
            schema_id="kt.v17_7_4.reprolock_generalization_negative_control_receipt.v1",
            status="PASS" if not false_pass else "KT_BLOCKED__NEGATIVE_CONTROL_FALSE_PASS",
            negative_control_types=negative_plan.get("negative_control_types", []),
            negative_controls_non_scoring=True,
            any_negative_control_scored_as_success=false_pass,
        ),
    )
    write_json(
        out / "v17_7_4_reprolock_generalization_gap_receipt.json",
        authority(
            schema_id="kt.v17_7_4.reprolock_generalization_gap_receipt.v1",
            status="RUNTIME_MEASURED_NO_PROMOTION_AUTHORITY",
            stable_control_reference_correct=41,
            stable_control_reference_total=50,
            generalization_correct=correct,
            generalization_total=row_count,
            generalization_accuracy=None if row_count in (None, 0) else round(correct / row_count, 6),
            full_prompt_plus_output_tokens_per_correct=token_row.get("tokens_per_correct"),
            pass_target_minimum_correct_50=39,
            strong_target_correct_50=41,
            heldout_generalization_claim=False,
        ),
    )
    write_extended_assessment(out)


def main() -> int:
    runtime_root = Path(__file__).resolve().parent
    out = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktv1774_truegen_outputs"))
    if not out.parent.exists():
        out = Path("ktv1774_truegen_outputs")
    summary = run_truegen_runtime(runtime_root, out=out)
    if summary.get("status") == "PASS":
        write_generalization_receipts(runtime_root, out, summary)
    return 0 if summary.get("status") == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
