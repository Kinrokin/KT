# KTV1774 ReproLock Generalization Probe V1

Runs the byte-locked known-good ReproLock path on a non-overlapping 50-row public benchmark slice. This packet tests held-out/generalization evidence only after runtime. It does not train, promote, authorize V18, mutate prompts/routes/finalizers/KT-hat, claim router superiority, claim G2 recovery, or expand the claim ceiling.
