```python
import zipfile, pathlib, subprocess, sys
packet = pathlib.Path('/kaggle/input/ktg3full-v17-canary-route-value/ktg3full_v17_canary_route_value.zip')
work = pathlib.Path('/kaggle/working/ktg3full_v17')
work.mkdir(parents=True, exist_ok=True)
zipfile.ZipFile(packet).extractall(work)
subprocess.check_call([sys.executable, 'KTG3FULL_V17_CANARY_RUNNER.py'], cwd=work)
```
