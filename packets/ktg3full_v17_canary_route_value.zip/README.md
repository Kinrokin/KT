# KTG3FULL V17 Canary Route-Value Packet

This packet runs a measured-row canary route-value benchmark only. It does not train, promote, or authorize runtime routing.

Place a non-empty `benchmark_predictions.jsonl` beside the runner or in a Kaggle input dataset, then run `python KTG3FULL_V17_CANARY_RUNNER.py`.
