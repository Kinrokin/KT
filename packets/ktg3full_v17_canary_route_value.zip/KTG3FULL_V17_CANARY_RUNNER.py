from __future__ import annotations

import json
import os
import zipfile
from collections import Counter
from pathlib import Path

ALLOWED_RUNTIME_FEATURES = [
  "math_act_features",
  "prompt_length",
  "answer_format_requirement",
  "risk_tier",
  "claim_boundary_signal",
  "evidence_grounding_signal",
  "uncertainty_markers",
  "contradiction_markers",
  "temporal_cues",
  "external_knowledge_cues",
  "route_cost_priors",
  "historical_route_habitat_priors"
]
FORBIDDEN_RUNTIME_FEATURES = [
  "oracle_correct",
  "gold_answer",
  "post_hoc_correctness",
  "posthoc_winner",
  "arm_correctness",
  "benchmark_answer",
  "post_generation_output_quality"
]
REQUIRED_ARMS = [
  "base_raw",
  "feature_bound_route",
  "label_bound_route",
  "best_static_adapter",
  "V16_shadow_replay_baseline",
  "V17_canary_policy",
  "oracle"
]
ACTIVATION_MARGINS = [0.0, 0.03, 0.05, 0.07, 0.10]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_jsonl(path: Path):
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def locate_input_rows() -> Path | None:
    candidates = [
        Path("benchmark_predictions.jsonl"),
        Path("/kaggle/working/benchmark_predictions.jsonl"),
    ]
    input_root = Path("/kaggle/input")
    if input_root.exists():
        candidates.extend(sorted(input_root.rglob("benchmark_predictions.jsonl")))
    for candidate in candidates:
        if candidate.exists() and candidate.stat().st_size > 0:
            return candidate
    return None


def features_for(row):
    raw = row.get("runtime_features") or row.get("pre_generation_features") or {}
    forbidden = sorted(set(raw) & set(FORBIDDEN_RUNTIME_FEATURES))
    allowed = {key: raw[key] for key in raw if key in ALLOWED_RUNTIME_FEATURES}
    return allowed, forbidden


def choose_route(row, config, margin):
    features, forbidden = features_for(row)
    if forbidden:
        return "base_raw", 0.0, features, forbidden, "forbidden_feature_fallback"
    if row.get("math_act_features") or features.get("math_act_features") or features.get("answer_format_requirement") == "numeric":
        confidence = 0.65
        route = "formal_math_repair_adapter_global"
    elif features.get("risk_tier") in {"high", "critical"} or features.get("claim_boundary_signal"):
        confidence = 0.60
        route = "base_kt_hat_compact"
    else:
        confidence = 0.40
        route = "base_raw"
    if confidence < (0.50 + margin):
        return "base_raw", confidence, features, forbidden, "margin_fallback"
    return route, confidence, features, forbidden, "selected"


def correct_for(row, arm):
    arms = row.get("arm_results") or row.get("arms") or {}
    if isinstance(arms.get(arm), dict):
        return bool(arms[arm].get("correct"))
    if arm in row:
        value = row[arm]
        if isinstance(value, dict):
            return bool(value.get("correct"))
        return bool(value)
    return False


def score(rows, config, margin):
    decisions = []
    counts = Counter()
    canary_correct = 0
    base_correct = 0
    feature_correct = 0
    best_static_correct = 0
    oracle_correct = 0
    harmful = 0
    base_opportunities = 0
    oracle_leaks = 0
    for idx, row in enumerate(rows):
        route, confidence, features, forbidden, reason = choose_route(row, config, margin)
        if forbidden:
            oracle_leaks += len(forbidden)
        counts[route] += 1
        base_ok = correct_for(row, "base_raw")
        feature_ok = correct_for(row, "feature_bound_route")
        best_ok = correct_for(row, "best_static_adapter")
        oracle_ok = correct_for(row, "oracle")
        route_ok = correct_for(row, route) if route in row.get("arm_results", {}) or route in row else base_ok
        canary_correct += int(route_ok)
        base_correct += int(base_ok)
        feature_correct += int(feature_ok)
        best_static_correct += int(best_ok)
        oracle_correct += int(oracle_ok)
        if base_ok:
            base_opportunities += 1
            if not route_ok:
                harmful += 1
        decisions.append({
            "schema_id": "kt.v17_canary_route_decision.v1",
            "row_index": idx,
            "sample_id": row.get("sample_id", f"row_{idx}"),
            "selected_route": route,
            "confidence": confidence,
            "decision_reason": reason,
            "runtime_features_used": sorted(features),
            "forbidden_features_seen": forbidden,
            "runtime_authority": False,
            "promotion_authority": False,
            "claim_ceiling_preserved": True,
        })
    total = len(rows)
    gap = max(oracle_correct - base_correct, 1)
    feature_gap = max(oracle_correct - feature_correct, 1)
    ocr = (canary_correct - base_correct) / gap
    rrc = (canary_correct - feature_correct) / feature_gap
    bpr = 1 - (harmful / max(base_opportunities, 1))
    har = harmful / max(total, 1)
    olr = 0 if oracle_leaks == 0 else oracle_leaks / max(total, 1)
    scorecard = {
        "schema_id": "kt.v17_benchmark_scorecard.v1",
        "rows": total,
        "base_raw_correct": base_correct,
        "feature_bound_correct": feature_correct,
        "best_static_correct": best_static_correct,
        "canary_policy_correct": canary_correct,
        "oracle_correct": oracle_correct,
        "oracle_conversion_rate": ocr,
        "route_regret_closure": rrc,
        "base_preservation_rate": bpr,
        "harmful_activation_rate": har,
        "oracle_leakage_rate": olr,
        "route_distribution": dict(sorted(counts.items())),
        "runtime_authority": False,
        "promotion_authority": False,
        "claim_ceiling_preserved": True,
    }
    return decisions, scorecard


def main():
    out = Path("/kaggle/working/v17_outputs") if Path("/kaggle").exists() else Path("v17_outputs")
    out.mkdir(parents=True, exist_ok=True)
    config = read_json(Path("V17_CANARY_POLICY_CONFIG.json"))
    input_path = locate_input_rows()
    if input_path is None:
        blocker = {
            "schema_id": "kt.v17_blocker_receipt.v1",
            "status": "BLOCKED",
            "reason": "missing non-empty benchmark_predictions.jsonl",
            "runtime_authority": False,
            "promotion_authority": False,
            "claim_ceiling_preserved": True,
        }
        write_json(out / "BLOCKER_RECEIPT.json", blocker)
        raise SystemExit(2)
    rows = read_jsonl(input_path)
    if not rows:
        write_json(out / "BLOCKER_RECEIPT.json", {"status": "BLOCKED", "reason": "empty benchmark_predictions.jsonl"})
        raise SystemExit(2)
    all_scorecards = []
    final_decisions = []
    final_scorecard = None
    for margin in ACTIVATION_MARGINS:
        decisions, scorecard = score(rows, config, margin)
        scorecard["activation_margin"] = margin
        all_scorecards.append(scorecard)
        if margin == 0.05:
            final_decisions = decisions
            final_scorecard = scorecard
    if final_scorecard is None:
        final_decisions, final_scorecard = score(rows, config, 0.0)
    write_jsonl(out / "benchmark_predictions.jsonl", rows)
    write_jsonl(out / "v17_canary_route_decisions.jsonl", final_decisions)
    write_json(out / "benchmark_scorecard.json", final_scorecard)
    write_json(out / "v17_activation_margin_sweep.json", {"schema_id": "kt.v17_activation_margin_sweep.v1", "scorecards": all_scorecards})
    write_json(out / "v17_oracle_conversion_scorecard.json", {"schema_id": "kt.v17_oracle_conversion_scorecard.v1", "oracle_conversion_rate": final_scorecard["oracle_conversion_rate"], "status": "PASS" if final_scorecard["oracle_conversion_rate"] > 0.3636363636 else "FAIL"})
    write_json(out / "v17_route_regret_closure_scorecard.json", {"schema_id": "kt.v17_route_regret_closure_scorecard.v1", "route_regret_closure": final_scorecard["route_regret_closure"], "status": "PASS" if final_scorecard["route_regret_closure"] >= 0.30 else "OBSERVED_NOT_STRONG"})
    write_json(out / "v17_base_preservation_receipt.json", {"schema_id": "kt.v17_base_preservation_receipt.v1", "base_preservation_rate": final_scorecard["base_preservation_rate"], "status": "PASS" if final_scorecard["base_preservation_rate"] >= 0.95 else "FAIL"})
    write_json(out / "v17_harmful_activation_receipt.json", {"schema_id": "kt.v17_harmful_activation_receipt.v1", "harmful_activation_rate": final_scorecard["harmful_activation_rate"], "status": "PASS" if final_scorecard["harmful_activation_rate"] <= 0.10 else "FAIL"})
    write_json(out / "v17_oracle_leakage_scan.json", {"schema_id": "kt.v17_oracle_leakage_scan.v1", "oracle_leakage_rate": final_scorecard["oracle_leakage_rate"], "status": "PASS" if final_scorecard["oracle_leakage_rate"] == 0 else "FAIL", "forbidden_runtime_features": FORBIDDEN_RUNTIME_FEATURES})
    write_json(out / "v17_route_distribution_health.json", {"schema_id": "kt.v17_route_distribution_health.v1", "route_distribution": final_scorecard["route_distribution"], "status": "PASS" if len(final_scorecard["route_distribution"]) > 1 else "OBSERVED_SINGLE_ROUTE"})
    write_json(out / "v17_claim_admissibility_casefile.json", {"schema_id": "kt.v17_claim_admissibility_casefile.v1", "runtime_authority": False, "promotion_authority": False, "claim_ceiling_preserved": True, "status": "OBSERVED_RUNTIME_OUTPUT_ONLY"})
    with zipfile.ZipFile(out / "V17_ASSESSMENT_ONLY.zip", "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(out.glob("*.json")) + sorted(out.glob("*.jsonl")):
            zf.write(path, path.name)
    print(json.dumps({"status": "COMPLETE", "output_dir": str(out), "rows": len(rows)}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
