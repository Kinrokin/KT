from runtime.final_answer_stopping_criteria_v41 import KTFinalAnswerStoppingCriteria
from runtime.pairwise_court_v41 import synthetic_mutation_suite


class FakeTokenizer:
    def decode(self, ids, skip_special_tokens=False):
        mapping = {1: 'FINAL_ANSWER:', 2: ' 42', 3: '\\n', 4: ' trailer'}
        return ''.join(mapping[int(i)] for i in ids)


def test_stop300_v41_smoke():
    c = KTFinalAnswerStoppingCriteria(tokenizer=FakeTokenizer(), prompt_token_count=2, monitor_only=False)
    assert c.consume_new_token_ids([1]) is False
    assert c.consume_new_token_ids([2]) is False
    assert c.consume_new_token_ids([3]) is True
    assert c.first_boundary_decision.semantic_boundary_type.value == 'FINAL_LINE_CLOSE'
    assert synthetic_mutation_suite()['status'] == 'PASS_RAW_TRACE_FAIL_CLOSED_MUTATION_SUITE'
