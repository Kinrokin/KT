from __future__ import annotations

import json
import os
import time
import traceback
from pathlib import Path

import torch
from transformers import AutoConfig, AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, StoppingCriteriaList

from runtime.atomic_record_store import AtomicRecordStore, work_key
from runtime.boundary_evidence import build_physical_token_ledger, validate_physical_token_ledger
from runtime.checkpoint_manager import CheckpointManager
from runtime.final_answer_stopping_criteria_v41 import KTFinalAnswerStoppingCriteria
from runtime.hf_publisher import publish_evidence, publish_final_assessment
from runtime.model_runtime_attestation import attest_loaded_model, effective_eos_token_ids
from runtime.numeric_normalizer import extract_expected_answer, extract_prediction, oracle_fixture_suite, score_prediction
from runtime.output_delivery import extract_prediction as extract_visible_prediction
from runtime.pairwise_court_v41 import execute_core_result_court, synthetic_mutation_suite
from runtime.publication_disposition import final_disposition
from runtime.reference_court_v34 import adjudicate_reference_court_v34
from runtime.timing_protocol import timing_protocol_receipt
from runtime.work_plan import build_work_plan, work_plan_receipt

MODEL_REPO = "unsloth/Qwen2.5-7B-Instruct-bnb-4bit"


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def load_model():
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO)
    config = AutoConfig.from_pretrained(MODEL_REPO)
    embedded_quant = getattr(config, "quantization_config", None)
    if embedded_quant:
        model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, device_map="auto")
        quantization_authority = "MODEL_EMBEDDED"
    else:
        quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
        model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, quantization_config=quant, device_map="auto")
        quantization_authority = "RUNTIME_DECLARED"
    return model, tokenizer, quantization_authority


def load_rows(config: dict) -> dict[str, dict]:
    rows = {}
    for group in ["natural_rows", "timing_panel_rows", "edge_regression_rows"]:
        for row in config[group]:
            rows[row["row_id"]] = {**row, "expected_answer": extract_expected_answer(row.get("answer", row.get("expected_answer", "")))}
    return rows


def render_prompt(template: str, question: str) -> str:
    return template.replace("{question}", question)


def make_stopping_criteria(tokenizer, prompt_len: int, arm_id: str):
    if arm_id == "L0_LEGACY_NO_DETECTOR":
        return None, None
    criterion = KTFinalAnswerStoppingCriteria(
        tokenizer=tokenizer,
        prompt_token_count=prompt_len,
        monitor_only=(arm_id == "M0_STREAMING_DETECTOR_MONITOR_ONLY"),
    )
    return StoppingCriteriaList([criterion]), criterion


def run_generation(model, tokenizer, prompt: str, arm_id: str, eos_ids: list[int]) -> dict:
    prompt_inputs = tokenizer(prompt, return_tensors="pt")
    prompt_token_ids = prompt_inputs["input_ids"][0].tolist()
    device = next(model.parameters()).device
    prompt_inputs = {k: v.to(device) for k, v in prompt_inputs.items()}
    criteria, criterion = make_stopping_criteria(tokenizer, len(prompt_token_ids), arm_id)
    cuda_timing_available = torch.cuda.is_available()
    start_event = torch.cuda.Event(enable_timing=True) if cuda_timing_available else None
    end_event = torch.cuda.Event(enable_timing=True) if cuda_timing_available else None
    wall_started = time.perf_counter_ns()
    if start_event:
        start_event.record()
    with torch.no_grad():
        outputs = model.generate(
            **prompt_inputs,
            max_new_tokens=512,
            do_sample=False,
            return_dict_in_generate=False,
            stopping_criteria=criteria,
        )
    if end_event:
        end_event.record()
        torch.cuda.synchronize()
    wall_ended = time.perf_counter_ns()
    raw_ids = outputs[0].tolist()[len(prompt_token_ids):]
    terminal = raw_ids[-1] if raw_ids else None
    ended_on_eos = terminal in set(eos_ids) if terminal is not None else False
    ended_on_max = len(raw_ids) >= 512 and not ended_on_eos
    raw_text = tokenizer.decode(raw_ids, skip_special_tokens=False)
    first = criterion.first_boundary_decision if criterion is not None else None
    visible_text = first.visible_text if first else raw_text
    boundary_floor = first.boundary_token_index_floor if first else len(raw_ids)
    boundary_ceil = first.boundary_token_index_ceil if first else len(raw_ids)
    termination_source = first.generator_termination_source.value if first else ("EOS_TOKEN" if ended_on_eos else ("MAX_NEW_TOKENS" if ended_on_max else "UNKNOWN"))
    ledger = build_physical_token_ledger(
        prompt_token_ids=prompt_token_ids,
        raw_generated_token_ids=raw_ids,
        semantic_visible_text=visible_text,
        canonical_extracted_answer=extract_visible_prediction(visible_text),
        generator_termination_source=termination_source,
        boundary_token_index_floor=boundary_floor,
        boundary_token_index_ceil=boundary_ceil,
        boundary_char_index=first.boundary_char_index if first else None,
        trigger_token_start_index=first.trigger_token_start_index if first else None,
        trigger_char_offset_within_token_if_any=first.trigger_char_offset_within_token_if_any if first else None,
    )
    reference = adjudicate_reference_court_v34(
        raw_text,
        terminal_token_id=terminal,
        effective_eos_token_ids=set(eos_ids),
        ended_on_eos=ended_on_eos,
        ended_on_max_new_tokens=ended_on_max,
        custom_stop_fired=bool(first and first.generator_termination_source.value == "CUSTOM_STOP_CRITERION"),
    )
    timing = {
        "wall_ns": wall_ended - wall_started,
        "cuda_event_ms": float(start_event.elapsed_time(end_event)) if start_event and end_event else None,
        "cuda_event_timing_executed": bool(start_event and end_event),
        "detector_cpu_ns": criterion.fsm.detector_cpu_ns_total if criterion is not None else 0,
    }
    return {
        **ledger.to_json(),
        "raw_generated_text": raw_text,
        "reference_court": reference.to_json(),
        "runtime_first_boundary": first.to_json() if first else None,
        "detector_telemetry": criterion.telemetry if criterion is not None else {"full_sequence_rescan_count": 0},
        "terminal_token_id": terminal,
        "effective_eos_token_ids": eos_ids,
        "ended_on_eos": ended_on_eos,
        "ended_on_max_new_tokens": ended_on_max,
        "custom_stop_fired": bool(first and first.generator_termination_source.value == "CUSTOM_STOP_CRITERION"),
        "token_boundary_errors": validate_physical_token_ledger(ledger.to_json()),
        "timing": timing,
        "v41_generation_time_stop_path": "TRANSFORMERS_STOPPING_CRITERIA" if criteria is not None else "BASELINE_NO_STOPPING_CRITERIA",
    }


def package_blocker(outdir: Path, checkpoint: CheckpointManager, assessment: Path, wrapper: Path, status: str, error: str) -> None:
    write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.stop300.v41.blocker_receipt.v1", "status": status, "error": error, "claim_ceiling_status": "PRESERVED"})
    checkpoint.checkpoint("blocker")
    checkpoint.final_zips(assessment, wrapper)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / "runtime" / "ktstop300_v41_config.json").read_text(encoding="utf-8-sig"))
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_v4_1_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP300_V4_1_ASSESSMENT_ONLY.zip"))
    wrapper = Path(os.environ.get("KT_WRAPPER_ZIP", "/kaggle/working/KT_STOP300_V4_1_WRAPPER_COLLECTION.zip"))
    checkpoint = CheckpointManager(outdir, config["evidence_scope_hash"])
    try:
        if os.environ.get("KT_AUTHORIZED_PACKET_SHA256") is None:
            raise SystemExit("MISSING_EXTERNAL_PACKET_SHA")
        if os.environ.get("KT_AUTHORIZED_PACKET_SUBJECT_HEAD") is None:
            raise SystemExit("MISSING_PACKET_SUBJECT_HEAD")
        suite = oracle_fixture_suite()
        write_json(outdir / "numeric_oracle_fixture_suite.json", suite)
        if suite["status"] != "PASS":
            raise SystemExit("BLOCK_SCORER_ORACLE")
        write_json(outdir / "timing_protocol_receipt.json", timing_protocol_receipt())
        write_json(outdir / "work_plan_receipt.json", work_plan_receipt(config))
        write_json(outdir / "synthetic_court_mutation_receipt.json", synthetic_mutation_suite())
        rows = load_rows(config)
        model, tokenizer, quantization_authority = load_model()
        eos_ids = effective_eos_token_ids(model, tokenizer)
        attestation = attest_loaded_model(model, tokenizer, MODEL_REPO)
        attestation["quantization_authority"] = quantization_authority
        write_json(outdir / "model_runtime_attestation.json", attestation)
        if attestation["status"] != "PASS_FUNCTIONAL_MODEL_4BIT_CONTRACT":
            raise SystemExit("BLOCK_ENVIRONMENT_DRIFT")
        store = AtomicRecordStore(outdir, config["evidence_scope_hash"])
        plan = build_work_plan(config)
        max_wall = int(os.environ.get("KT_MAX_WALL_SECONDS", "0") or "0")
        started = time.monotonic()
        for item in plan:
            key = work_key(config["evidence_scope_hash"], item["phase"], item["row_id"], item["repetition"], item["arm_id"])
            if key in store.completed:
                continue
            if item["phase"] == "warmup":
                _ = run_generation(model, tokenizer, "Solve 1+1. FINAL_ANSWER:", item["arm_id"], eos_ids)
                store.write_once(key, {**item, "schema_id": "kt.stop300.v41.warmup_record.v1", "evidence": False})
                continue
            row = rows[item["row_id"]]
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            gen = run_generation(model, tokenizer, prompt, item["arm_id"], eos_ids)
            prediction = extract_prediction(gen["semantic_visible_text"])
            record = {**item, **gen, "schema_id": "kt.stop300.v41.measured_record.v1", "prediction": prediction, "expected_answer": row["expected_answer"], "correct": score_prediction(prediction, row["expected_answer"])}
            store.write_once(key, record)
            if max_wall and time.monotonic() - started > max_wall:
                raise TimeoutError("KT_MAX_WALL_SECONDS")
        predictions = outdir / "truegen_predictions.jsonl"
        store.assemble_jsonl(predictions)
        core = execute_core_result_court(predictions, config)
        write_json(outdir / "CORE_RESULT_SUMMARY.json", core)
        publish_evidence(outdir, config)
        checkpoint.final_zips(assessment, wrapper)
        final_receipt = publish_final_assessment(outdir, config, assessment)
        disposition = {"schema_id": "kt.stop300.v41.final_run_disposition.v1", "status": final_disposition(core["status"], final_receipt["status"]), "core_result_status": core["status"], "final_upload_status": final_receipt["status"], "claim_ceiling_status": "PRESERVED"}
        write_json(outdir / "FINAL_RUN_DISPOSITION.json", disposition)
        checkpoint.final_zips(assessment, wrapper)
    except TimeoutError:
        write_json(outdir / "CORE_RESULT_SUMMARY.json", {"schema_id": "kt.stop300.v41.core_result_summary.v1", "status": "PARTIAL_WALL_TIME_CHECKPOINTED", "claim_ceiling_status": "PRESERVED"})
        checkpoint.checkpoint("wall_time")
        checkpoint.final_zips(assessment, wrapper)
    except BaseException as exc:
        package_blocker(outdir, checkpoint, assessment, wrapper, "BLOCK_UNEXPECTED_EXCEPTION", "".join(traceback.format_exception_only(type(exc), exc)).strip())
        if os.environ.get("KT_RAISE_ON_BLOCKER", "0") == "1":
            raise


if __name__ == "__main__":
    main()
