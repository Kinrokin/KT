from __future__ import annotations

import hashlib
import json
import os
import runpy
import sys
import traceback
import zipfile
from pathlib import Path

EXPECTED_MEMBER_MANIFEST_SHA256 = "d314d03031b3806d82d8642ba1dd8b1f73267539479f251b53031ebc7616580b"
EXPECTED_PACKET_NAME = "ktstop300_v4_1.zip"
EXPECTED_RUN_MODE = "RUN_KTSTOP_RUNTIME_STOP_PAIRED300_V4_1"


def write_blocker(root: Path, status: str, error: str) -> None:
    out = Path(os.environ.get("KT_OUTPUT_DIR", root / "bootstrap_blocker"))
    out.mkdir(parents=True, exist_ok=True)
    payload = {"schema_id": "kt.stop300.v41.bootstrap_blocker.v1", "status": status, "error": error, "claim_ceiling_status": "PRESERVED"}
    (out / "BLOCKER_RECEIPT.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with zipfile.ZipFile(out / "KT_STOP300_V4_1_WRAPPER_COLLECTION.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(out / "BLOCKER_RECEIPT.json", "BLOCKER_RECEIPT.json")


def main() -> None:
    packet_root = Path(__file__).resolve().parent
    sys.path.insert(0, str(packet_root))
    os.chdir(packet_root)
    try:
        authorized_sha = os.environ.get("KT_AUTHORIZED_PACKET_SHA256")
        subject_head = os.environ.get("KT_AUTHORIZED_PACKET_SUBJECT_HEAD")
        current_head = os.environ.get("KT_CURRENT_MAIN_HEAD")
        expected_run_mode = os.environ.get("KT_EXPECTED_RUN_MODE")
        if not authorized_sha or not subject_head or not current_head or expected_run_mode != EXPECTED_RUN_MODE:
            raise SystemExit("missing external packet SHA/subject/current-head/run-mode authority")
        manifest_payload = json.loads((packet_root / "SHA256_MANIFEST.json").read_text(encoding="utf-8-sig"))
        stable_members = {
            key: value
            for key, value in manifest_payload["members"].items()
            if key not in {"KAGGLE_BOOTSTRAP_CELL.py", "SHA256_MANIFEST.json", "runtime/ktstop300_v41_config.json"}
        }
        actual_member_manifest_sha = hashlib.sha256(json.dumps(stable_members, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        if actual_member_manifest_sha != EXPECTED_MEMBER_MANIFEST_SHA256:
            raise SystemExit("internal member manifest SHA mismatch")
        outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_v4_1_outputs"))
        outdir.mkdir(parents=True, exist_ok=True)
        from runtime.dependency_preflight import ensure_dependencies, native_library_receipt
        ensure_dependencies(outdir)
        native_library_receipt(outdir)
        import runtime.KT_CANONICAL_RUNNER  # noqa: F401
        if os.environ.get("KT_STOP300_BOOTSTRAP_SMOKE_ONLY") == "1":
            Path("BOOTSTRAP_SMOKE_RECEIPT.json").write_text(json.dumps({"status": "PASS_FRESH_SUBPROCESS_UNRELATED_CWD"}, indent=2) + "\n", encoding="utf-8")
            return
        runpy.run_path(str(packet_root / "runtime" / "KT_CANONICAL_RUNNER.py"), run_name="__main__")
    except BaseException as exc:
        write_blocker(packet_root, "KT_STOP300_V4_1_BOOTSTRAP_BLOCKED", "".join(traceback.format_exception_only(type(exc), exc)).strip())
        if os.environ.get("KT_RAISE_ON_BLOCKER", "0") == "1":
            raise


if __name__ == "__main__":
    main()
