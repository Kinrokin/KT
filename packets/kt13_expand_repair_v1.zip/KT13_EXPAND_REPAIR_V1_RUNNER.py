from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path


PACKET_BUILD_HEAD = "cbc477899417fcfb0d3d56aa78c616664a6d8e63"
KNOWN_EVIDENCE_HEAD = "4de572be825acb0e7551174575e225b74d6cf523"
REQUESTED_HEAD_ENV = os.environ.get("KT_REQUESTED_HEAD")
HF_FINAL_ADAPTER_STORE = os.environ.get("KT_HF_ADAPTER_STORE", "Kinrokin/kt13-full-e2e-final-only-20260524-174447")
OUT_DIR = Path(os.environ.get("KT_OUT_DIR", "/kaggle/working/kt13_expand_repair_v1_outputs"))


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write_json(name: str, obj: dict) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def git_head() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    except Exception:
        return os.environ.get("KT_ACTUAL_HEAD", "UNKNOWN")


def requested_head(actual_head: str, actual_head_known: bool) -> tuple[str, str]:
    if REQUESTED_HEAD_ENV is not None:
        requested = REQUESTED_HEAD_ENV.strip()
        if requested:
            return requested, "KT_REQUESTED_HEAD_ENV"
        return "", "KT_REQUESTED_HEAD_ENV_EMPTY"
    if actual_head_known:
        return actual_head, "ACTUAL_GIT_HEAD_DEFAULT"
    return PACKET_BUILD_HEAD, "PACKET_BUILD_HEAD_FALLBACK"


def is_ancestor(ancestor: str, descendant: str) -> bool | None:
    if not ancestor or not descendant or descendant == "UNKNOWN":
        return None
    try:
        proc = subprocess.run(
            ["git", "merge-base", "--is-ancestor", ancestor, descendant],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return None
    return proc.returncode == 0


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    actual_head = git_head()
    actual_head_known = actual_head not in {"", "UNKNOWN"}
    requested, requested_source = requested_head(actual_head, actual_head_known)
    head_match = actual_head_known and actual_head == requested
    packet_build_head_is_ancestor = is_ancestor(PACKET_BUILD_HEAD, actual_head)
    write_json(
        "head_binding_receipt.json",
        {
            "schema_id": "kt.kaggle.head_binding_receipt.v1",
            "generated_utc": utc_now(),
            "requested_head": requested,
            "requested_head_source": requested_source,
            "actual_head": actual_head,
            "actual_head_known": actual_head_known,
            "packet_build_head": PACKET_BUILD_HEAD,
            "known_evidence_head": KNOWN_EVIDENCE_HEAD,
            "packet_build_head_is_ancestor_of_actual": packet_build_head_is_ancestor,
            "head_match": head_match,
            "fail_closed_if_mismatch": True,
            "assessment_only_if_unknown": False,
        },
    )
    if not head_match:
        blocker_id = "REQUESTED_HEAD_EMPTY" if requested_source == "KT_REQUESTED_HEAD_ENV_EMPTY" else ("HEAD_UNKNOWN" if not actual_head_known else "HEAD_MISMATCH")
        write_json(
            "blocker_ledger.json",
            {
                "schema_id": "kt.kaggle.blocker_ledger.v1",
                "blockers": [{"blocker_id": blocker_id, "requested_head": requested, "actual_head": actual_head}],
                "next_lawful_move": "REPLAY_PACKET_ON_CURRENT_HEAD_BEFORE_BENCHMARK",
            },
        )
        return 2

    write_json(
        "run_manifest.json",
        {
            "schema_id": "kt.kaggle.kt13_expand_repair.run_manifest.v1",
            "generated_utc": utc_now(),
            "run_mode": "RUN_EXPANDED_EXTERNAL_MARKET_BENCHMARK_AND_DETACHED_VERIFIER_PACKET",
            "hf_final_adapter_store": HF_FINAL_ADAPTER_STORE,
            "claim_ceiling_preserved": True,
            "commercial_claim_authorized": False,
            "external_audit_complete": False,
            "s_tier_claim_authorized": False,
            "seven_b_amplification_proven": False,
        },
    )
    write_json(
        "evaluator_integrity_receipt.json",
        {
            "schema_id": "kt.benchmark.evaluator_integrity_receipt.v1",
            "evaluator_integrity_status": "PENDING_EXECUTION",
            "evaluator_integrity_pass": False,
            "detached_verifier_mode": True,
            "claim_authority": "NONE_PENDING_ACTUAL_EVALUATION",
        },
    )
    write_json(
        "benchmark_leakage_scan.json",
        {
            "schema_id": "kt.benchmark.leakage_scan.v1",
            "leakage_scan_status": "PENDING_EXECUTION",
            "leakage_scan_pass": False,
            "leakage_findings": [],
            "claim_authority": "NONE_PENDING_ACTUAL_SCAN",
        },
    )
    write_json("route_regret_matrix.json", {"schema_id": "kt.router.route_regret_matrix.v1", "sample_count": 0, "rows": [], "note": "populate during benchmark execution"})
    write_json("verified_work_per_token_scorecard.json", {"schema_id": "kt.benchmark.verified_work_per_token_scorecard.v1", "verified_work": 0, "token_count": 0, "verified_work_per_token": 0})
    write_json(
        "assessment_summary.json",
        {
            "schema_id": "kt.kaggle.kt13_expand_repair.assessment_summary.v1",
            "outcome": "KT_13_EXPANDED_DETACHED_BENCHMARK_PACKET_STARTED__AWAITING_MODEL_EXECUTION_RESULTS",
            "next_lawful_move": "RUN_TARGETED_REPAIR_RETRAIN_FOR_MATH_HAT_ROUTE_REGRET_SCAR_DELTA_AFTER_RESULTS",
        },
    )
    print(f"KT expand/repair packet initialized at {OUT_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
