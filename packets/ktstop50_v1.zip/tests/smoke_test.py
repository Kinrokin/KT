from runtime.final_answer_stop import evaluate_generated_text


def test_line_anchored_marker_stops_once_complete():
    decision = evaluate_generated_text("work\nFINAL_ANSWER: 42\ntrailer")
    assert decision.should_stop
    assert decision.reason == "FINAL_ANSWER_LINE_COMPLETE"


def test_inline_marker_does_not_stop():
    decision = evaluate_generated_text("work says FINAL_ANSWER: 42 but not as a line")
    assert not decision.should_stop
