from __future__ import annotations

import runpy
from pathlib import Path

packet_root = Path(__file__).resolve().parent
runpy.run_path(str(packet_root / "runtime" / "KT_CANONICAL_RUNNER.py"), run_name="__main__")
