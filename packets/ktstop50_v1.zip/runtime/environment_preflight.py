from __future__ import annotations

import json
from pathlib import Path


def version_tuple(value: str):
    parts = []
    for part in value.replace("-", ".").split("."):
        if part.isdigit():
            parts.append(int(part))
        else:
            break
    return tuple(parts)


def inspect_model_quantization(model) -> dict:
    linear4bit_count = 0
    cpu_offloaded = 0
    disk_offloaded = 0
    device_map = getattr(model, "hf_device_map", {}) or {}
    for module in model.modules():
        if module.__class__.__name__ == "Linear4bit":
            linear4bit_count += 1
    for value in device_map.values() if isinstance(device_map, dict) else []:
        text = str(value).lower()
        if text == "cpu":
            cpu_offloaded += 1
        if text == "disk":
            disk_offloaded += 1
    return {
        "linear4bit_module_count": linear4bit_count,
        "model_is_loaded_in_4bit": linear4bit_count > 0,
        "cpu_offloaded_module_count": cpu_offloaded,
        "disk_offloaded_module_count": disk_offloaded,
    }


def cuda_environment_contract() -> dict:
    receipt = {
        "schema_id": "kt.stop50.cuda_environment_contract.runtime.v1",
        "status": "PENDING",
        "cuda_required": True,
        "bitsandbytes_functional_required": True,
    }
    try:
        import torch
        import bitsandbytes as bnb
        receipt["cuda_available"] = bool(torch.cuda.is_available())
        receipt["torch_version"] = getattr(torch, "__version__", "unknown")
        receipt["bitsandbytes_version"] = getattr(bnb, "__version__", "unknown")
        receipt["bitsandbytes_version_ok"] = version_tuple(receipt["bitsandbytes_version"]) >= (0, 49, 2)
        receipt["status"] = "PASS_IMPORTS" if receipt["cuda_available"] and receipt["bitsandbytes_version_ok"] else "FAIL_ENVIRONMENT"
    except Exception as exc:
        receipt["status"] = "FAIL_ENVIRONMENT"
        receipt["error"] = str(exc)
    return receipt


def write_blocker(outdir: Path, reason: str, receipt: dict) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "BLOCKER_RECEIPT.json").write_text(
        json.dumps(
            {
                "schema_id": "kt.stop50.blocker_receipt.runtime.v1",
                "status": "BLOCKED_ENVIRONMENT_CONTRACT",
                "reason": reason,
                "environment_receipt": receipt,
                "claim_ceiling_status": "PRESERVED",
                "training_authority": False,
                "promotion_authority": False,
                "selector_deployment_authority": False,
                "production_runtime_authority": False,
                "production_prompt_mutation_authority": False,
                "production_math_mode_claim": False,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
