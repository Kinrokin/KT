from __future__ import annotations

import json
import os
import re
import time
import zipfile
from pathlib import Path


RUN_MODE = "RUN_STOPSEQ_RUNTIME_STOP_CRITERIA_50ROW_V1"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
HF_RESULTS_REPO = os.environ.get("KT_HF_RESULTS_REPO", "Kinrokin/ktstop50-v1-results")


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def extract_answer(text: str):
    matches = re.findall(r"(?m)^[ \t]*FINAL_ANSWER\s*:\s*([^\r\n]*)", text)
    target = matches[-1] if matches else text
    fractions = re.findall(r"[-+]?\d[\d,]*\s*/\s*\d[\d,]*", target)
    if fractions:
        return fractions[-1].replace(" ", "").replace(",", "")
    numbers = re.findall(r"[-+]?\$?\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?", target)
    return numbers[-1].replace("$", "").replace(",", "").strip() if numbers else None


def expected_answer(answer_text: str):
    if "####" in answer_text:
        return answer_text.split("####")[-1].strip()
    return extract_answer(answer_text)


def score(expected: str, extracted) -> bool:
    return normalize(expected) == normalize(extracted)


def render_prompt(template: str, question: str) -> str:
    return f"{template}\n\nProblem:\n{question}\n"


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from runtime.environment_preflight import inspect_model_quantization

    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_REPO,
        device_map="auto",
        torch_dtype="auto",
        trust_remote_code=True,
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    quant = inspect_model_quantization(model)
    receipt = {
        "schema_id": "kt.stop50.model_loader_receipt.runtime.v1",
        "status": "PASS" if quant["model_is_loaded_in_4bit"] else "FAIL_NOT_4BIT",
        "model_repo": MODEL_REPO,
        "auto_model_for_causal_lm": True,
        "runtime_quantization_config_used": False,
        **quant,
    }
    return model, tokenizer, receipt


def load_rows(config):
    from datasets import load_dataset

    dataset = load_dataset("openai/gsm8k", "main", split="test")
    rows = []
    for row in config["rows"]:
        item = dataset[int(row["split_index"])]
        rows.append({**row, "question": item["question"], "expected_answer": expected_answer(item["answer"])})
    return rows


def generate(model, tokenizer, prompt: str, max_new_tokens: int, terminate: bool):
    import torch
    from transformers import StoppingCriteriaList
    from runtime.final_answer_stop import FirstCompleteFinalAnswerLineStoppingCriteria, evaluate_generated_text

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    prompt_len = int(inputs["input_ids"].shape[-1])
    stop_criteria = FirstCompleteFinalAnswerLineStoppingCriteria(tokenizer, prompt_len, tokenizer.eos_token_id)
    criteria = StoppingCriteriaList([stop_criteria]) if terminate else None
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    start = time.time()
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            stopping_criteria=criteria,
        )
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    latency = time.time() - start
    generated_ids = output_ids[0][prompt_len:]
    text = tokenizer.decode(generated_ids, skip_special_tokens=True)
    if terminate and stop_criteria.last_decision:
        stop_decision = stop_criteria.last_decision.to_json()
    else:
        stop_decision = evaluate_generated_text(text, eos=False).to_json()
    return text, generated_ids.tolist(), prompt_len, int(generated_ids.shape[-1]), latency, stop_decision


def maybe_upload(outdir: Path, assessment: Path) -> dict:
    token = os.environ.get("HF_TOKEN")
    if not token:
        return {"schema_id": "kt.stop50.hf_upload_receipt.v1", "status": "SKIPPED_NO_HF_TOKEN", "repo_id": HF_RESULTS_REPO}
    try:
        from huggingface_hub import HfApi, create_repo, upload_file, upload_folder
        create_repo(HF_RESULTS_REPO, repo_type="dataset", private=False, exist_ok=True, token=token)
        upload_folder(repo_id=HF_RESULTS_REPO, repo_type="dataset", folder_path=str(outdir), path_in_repo="artifacts", token=token)
        upload_file(repo_id=HF_RESULTS_REPO, repo_type="dataset", path_or_fileobj=str(assessment), path_in_repo=assessment.name, token=token)
        info = HfApi(token=token).dataset_info(HF_RESULTS_REPO)
        return {"schema_id": "kt.stop50.hf_upload_receipt.v1", "status": "PASS", "repo_id": HF_RESULTS_REPO, "url": f"https://huggingface.co/datasets/{HF_RESULTS_REPO}", "private": bool(info.private)}
    except Exception as exc:
        return {"schema_id": "kt.stop50.hf_upload_receipt.v1", "status": "FAILED_NON_FATAL", "repo_id": HF_RESULTS_REPO, "error": str(exc)}


def main() -> None:
    from runtime.effective_config_receipt import generation_config_receipt, quantization_authority_receipt
    from runtime.environment_preflight import cuda_environment_contract, write_blocker
    from runtime.paired_timing import deterministic_arm_order, protocol_receipt

    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktstop50_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop50_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP50_V1_ASSESSMENT_ONLY.zip"))

    env_receipt = cuda_environment_contract()
    write_json(outdir / "environment_contract_receipt.json", env_receipt)
    write_json(outdir / "quantization_authority_receipt.json", quantization_authority_receipt(MODEL_REPO))
    generation_config = {"max_new_tokens": 512, "do_sample": False, "temperature": None, "top_p": None}
    write_json(outdir / "generation_config_authority_receipt.json", generation_config_receipt(generation_config))
    write_json(outdir / "paired_timing_protocol_receipt.json", protocol_receipt())
    write_json(outdir / "row_manifest.json", {"schema_id": "kt.stop50.row_manifest.runtime.v1", "rows": config["rows"], "row_count": len(config["rows"]), "claim_ceiling_status": "PRESERVED"})
    write_json(outdir / "arm_manifest.json", config["arm_manifest"])
    write_json(outdir / "claim_boundary_receipt.json", config["claim_boundary"])

    if env_receipt.get("status") != "PASS_IMPORTS":
        write_blocker(outdir, "CUDA/bitsandbytes runtime imports failed before model load.", env_receipt)
        with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(outdir.glob("*")):
                zf.write(path, path.name)
        return

    try:
        model, tokenizer, loader = load_model()
        write_json(outdir / "model_loader_receipt.json", loader)
        if loader["status"] != "PASS":
            write_blocker(outdir, "Model did not load with embedded 4-bit quantization.", loader)
            return
        rows = load_rows(config)
        predictions = []
        token_rows = []
        timing_rows = []
        prefix_rows = []
        for row in rows:
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            warmup_order = deterministic_arm_order(row["row_id"], -1)
            for arm_id in warmup_order[:1]:
                generate(model, tokenizer, prompt, 32, terminate=arm_id.startswith("C1"))
            rep_results = {}
            for rep in range(3):
                for arm_id in deterministic_arm_order(row["row_id"], rep):
                    terminate = arm_id.startswith("C1")
                    text, ids, prompt_len, output_tokens, latency, stop_decision = generate(model, tokenizer, prompt, 512, terminate)
                    extracted = extract_answer(text)
                    correct = score(row["expected_answer"], extracted)
                    result = {
                        "schema_id": "kt.stop50.prediction_row.v1",
                        "run_mode": RUN_MODE,
                        "row_id": row["row_id"],
                        "arm_id": arm_id,
                        "repetition": rep,
                        "correct": correct,
                        "extracted_answer": extracted,
                        "output_tokens": output_tokens,
                        "prompt_tokens": prompt_len,
                        "full_tokens": prompt_len + output_tokens,
                        "latency_seconds": latency,
                        "stop_decision": stop_decision,
                        "raw_output": text,
                        "claim_ceiling_status": "PRESERVED",
                    }
                    predictions.append(result)
                    token_rows.append({k: result[k] for k in ["row_id", "arm_id", "repetition", "prompt_tokens", "output_tokens", "full_tokens"]})
                    timing_rows.append({k: result[k] for k in ["row_id", "arm_id", "repetition", "latency_seconds"]})
                    rep_results[(rep, arm_id)] = {"ids": ids, "raw_output": text}
                c0 = rep_results.get((rep, "C0_MONITOR_FIRST_COMPLETE_FINAL_ANSWER_LINE"))
                c1 = rep_results.get((rep, "C1_TERMINATE_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP"))
                if c0 and c1:
                    c0_prefix = c0["ids"][: len(c1["ids"])]
                    prefix_rows.append({
                        "row_id": row["row_id"],
                        "repetition": rep,
                        "prefix_equal": c0_prefix == c1["ids"],
                        "c0_output_token_count": len(c0["ids"]),
                        "c1_output_token_count": len(c1["ids"]),
                    })

        write_jsonl(outdir / "predictions.jsonl", predictions)
        write_jsonl(outdir / "token_ledger.jsonl", token_rows)
        write_jsonl(outdir / "timing_ledger.jsonl", timing_rows)
        write_jsonl(outdir / "prefix_equivalence_rows.jsonl", prefix_rows)
        by_arm = {}
        for arm_id in sorted({row["arm_id"] for row in predictions}):
            rows_for_arm = [row for row in predictions if row["arm_id"] == arm_id and row["repetition"] == 0]
            correct = sum(1 for row in rows_for_arm if row["correct"])
            by_arm[arm_id] = {
                "row_count": len(rows_for_arm),
                "correct": correct,
                "accuracy": correct / max(len(rows_for_arm), 1),
                "total_output_tokens": sum(row["output_tokens"] for row in rows_for_arm),
                "tokens_per_correct": sum(row["full_tokens"] for row in rows_for_arm) / max(correct, 1),
            }
        scorecard = {
            "schema_id": "kt.stop50.runtime_scorecard.v1",
            "run_mode": RUN_MODE,
            "status": "PASS_MODEL_GENERATED_AND_SCORED",
            "row_count": len(rows),
            "arm_scorecard": by_arm,
            "prefix_equal_count": sum(1 for row in prefix_rows if row["prefix_equal"]),
            "prefix_total": len(prefix_rows),
            "claim_ceiling_status": "PRESERVED",
        }
        write_json(outdir / "runtime_stop_scorecard.json", scorecard)
        write_json(outdir / "final_summary.json", {"schema_id": "kt.stop50.final_summary.v1", "status": "PASS_MODEL_GENERATED_AND_SCORED", "scorecard": scorecard, "claim_ceiling_status": "PRESERVED"})
        upload = maybe_upload(outdir, assessment)
        write_json(outdir / "HF_UPLOAD_RECEIPT.json", upload)
        with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(outdir.glob("*")):
                zf.write(path, path.name)
    except Exception as exc:
        write_blocker(outdir, f"wrapper exception: {exc}", {"status": "WRAPPER_EXCEPTION"})
        with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(outdir.glob("*")):
                zf.write(path, path.name)


if __name__ == "__main__":
    main()
