from __future__ import annotations

import hashlib


def deterministic_arm_order(row_id: str, repetition: int, seed: str = "ktstop50-v1") -> list[str]:
    key = f"{seed}:{row_id}:{repetition}".encode("utf-8")
    digest = hashlib.sha256(key).hexdigest()
    return ["C1_TERMINATE_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP", "C0_MONITOR_FIRST_COMPLETE_FINAL_ANSWER_LINE"] if int(digest[:2], 16) % 2 else ["C0_MONITOR_FIRST_COMPLETE_FINAL_ANSWER_LINE", "C1_TERMINATE_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP"]


def protocol_receipt() -> dict:
    return {
        "schema_id": "kt.stop50.randomized_synchronized_paired_timing.v1",
        "status": "PASS_PROTOCOL_DEFINED",
        "warmup_count": 3,
        "repetitions": 3,
        "batch_size": 1,
        "same_model_instance_required": True,
        "cuda_synchronize_before_after": True,
        "cuda_events_required": True,
        "randomize_arm_order": True,
        "claim_ceiling_status": "PRESERVED",
    }
