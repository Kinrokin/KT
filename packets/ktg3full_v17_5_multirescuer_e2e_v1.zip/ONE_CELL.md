```python
import pathlib, subprocess, sys, zipfile
packet = pathlib.Path('/kaggle/input/ktg3full-v17-5-multirescuer-e2e-v1/ktg3full_v17_5_multirescuer_e2e_v1.zip')
work = pathlib.Path('/kaggle/working/ktg3full_v17_5_multirescuer_packet')
work.mkdir(parents=True, exist_ok=True)
zipfile.ZipFile(packet).extractall(work)
subprocess.check_call([sys.executable, 'KTG3FULL_V17_5_MULTIRESCUER_E2E_V1_RUNNER.py'], cwd=work)
```
