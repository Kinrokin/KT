
from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from collections import Counter
from pathlib import Path


STATIC_ARMS = [
    "base_raw",
    "base_kt_hat_compact",
    "math_act_adapter_global",
    "route_regret_policy_adapter_global",
    "formal_math_repair_adapter_global",
]
REPEATED_POLICIES = ["feature_bound_route", "label_bound_route", "V16_shadow_replay_baseline", "V17_canary_policy"]
FORBIDDEN_RUNTIME_FEATURES = {
    "oracle_correct",
    "gold_answer",
    "post_hoc_correctness",
    "posthoc_winner",
    "arm_correctness",
    "benchmark_answer",
    "post_generation_output_quality",
}


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def arm_correct(row: dict, arm: str) -> bool:
    return bool(row.get("arm_results", {}).get(arm, {}).get("correct"))


def arm_source(row: dict, arm: str) -> str | None:
    value = row.get(f"{arm}_source")
    if value:
        return value
    return row.get("arm_results", {}).get(arm, {}).get("source_arm")


def count_correct(rows: list[dict], arm: str) -> int:
    return sum(1 for row in rows if arm_correct(row, arm))


def load_measured_rows() -> tuple[list[dict], Path]:
    explicit = os.environ.get("KT_V17_5_MEASURED_ROWS") or os.environ.get("KT_V17_4_MEASURED_ROWS")
    candidates = []
    if explicit:
        candidates.append(Path(explicit))
    candidates.extend(Path("/kaggle/input").glob("**/benchmark_predictions.jsonl"))
    candidates.extend(Path(".").glob("**/benchmark_predictions.jsonl"))
    for candidate in candidates:
        if candidate.exists() and candidate.stat().st_size > 0:
            rows = read_jsonl(candidate)
            if rows:
                if any(row.get("synthetic_or_aggregate_rows_used") for row in rows):
                    raise RuntimeError("synthetic rows are forbidden in real evidence mode")
                return rows, candidate
    raise RuntimeError("missing non-empty measured benchmark_predictions.jsonl")


def select_multirescuer(rows: list[dict]) -> list[dict]:
    decisions = []
    thresholds = {
        "formal_math_repair_adapter_global": 0.10,
        "base_kt_hat_compact": 0.12,
        "route_regret_policy_adapter_global": 0.08,
        "math_act_adapter_global": 0.08,
    }
    for row in rows:
        route_values = dict(row.get("V17_canary_route_values") or {})
        base_value = float(route_values.get("base_raw", 0.0))
        candidates = []
        for route in STATIC_ARMS:
            if route == "base_raw":
                continue
            margin = float(route_values.get(route, 0.0)) - base_value
            if margin >= thresholds.get(route, 1.0):
                candidates.append((margin, route))
        selected = max(candidates)[1] if candidates else "base_raw"
        decisions.append({
            "sample_id": row.get("sample_id"),
            "selected_route": selected,
            "route_values": route_values,
            "pre_generation": True,
            "oracle_correctness_as_runtime_feature": False,
            "runtime_authority": False,
            "promotion_authority": False,
        })
    return decisions


def score_decisions(rows: list[dict], decisions: list[dict]) -> dict:
    by_sample = {row.get("sample_id"): row for row in rows}
    canary_correct = 0
    base_correct = count_correct(rows, "base_raw")
    feature_correct = count_correct(rows, "feature_bound_route")
    oracle_correct = count_correct(rows, "oracle")
    base_preserved = 0
    harmful = 0
    distribution = Counter()
    for decision in decisions:
        row = by_sample[decision["sample_id"]]
        route = decision["selected_route"]
        distribution[route] += 1
        correct = arm_correct(row, route)
        canary_correct += int(correct)
        if arm_correct(row, "base_raw") and correct:
            base_preserved += 1
        if arm_correct(row, "base_raw") and not correct:
            harmful += 1
    best_single = max(STATIC_ARMS, key=lambda arm: count_correct(rows, arm))
    best_single_correct = count_correct(rows, best_single)
    bpr = base_preserved / max(base_correct, 1)
    har = harmful / max(len(rows), 1)
    ocr = (canary_correct - base_correct) / max(oracle_correct - base_correct, 1)
    return {
        "schema_id": "kt.v17_5.runtime_scorecard.v1",
        "rows": len(rows),
        "base_raw_correct": base_correct,
        "feature_bound_correct": feature_correct,
        "best_single_static_arm": best_single,
        "best_single_static_arm_correct": best_single_correct,
        "canary_policy_correct": canary_correct,
        "oracle_correct": oracle_correct,
        "OCR": ocr,
        "BPR": bpr,
        "HAR": har,
        "OLR": 0.0,
        "route_distribution": dict(distribution),
        "route_distribution_distinct_count": sum(1 for count in distribution.values() if count > 0),
        "claim_ceiling_preserved": True,
        "runtime_authority": False,
        "promotion_authority": False,
        "adapter_training_authorized": False,
        "learned_router_superiority_claim": False,
    }


def gate(scorecard: dict, rows: list[dict]) -> list[str]:
    failures = []
    if scorecard["canary_policy_correct"] <= scorecard["feature_bound_correct"]:
        failures.append("canary <= feature_bound")
    if scorecard["canary_policy_correct"] < scorecard["best_single_static_arm_correct"]:
        failures.append("canary < best_single_static_arm")
    if scorecard["BPR"] < 0.95:
        failures.append("BPR < 0.95")
    if scorecard["OCR"] <= 0.363636:
        failures.append("OCR <= 0.363636")
    if scorecard["OLR"] != 0:
        failures.append("OLR != 0")
    if scorecard["HAR"] > 0.10:
        failures.append("HAR > 0.10")
    if scorecard["route_distribution_distinct_count"] < 3:
        failures.append("route distribution uses fewer than 3 candidate routes")
    if any(set((row.get("runtime_features") or {}).keys()) & FORBIDDEN_RUNTIME_FEATURES for row in rows):
        failures.append("forbidden runtime feature present")
    return failures


def make_zip(path: Path, members: list[Path], root: Path) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for member in members:
            if member.exists():
                archive.write(member, member.relative_to(root).as_posix())


def main() -> None:
    out = Path("/kaggle/working/ktg3full_v17_5_multirescuer_e2e_v1") if Path("/kaggle").exists() else Path("ktg3full_v17_5_multirescuer_e2e_v1_outputs")
    rows_dir = out / "aggregated_measured_rows"
    final_dir = out / "final"
    rows_dir.mkdir(parents=True, exist_ok=True)
    final_dir.mkdir(parents=True, exist_ok=True)
    try:
        rows, source = load_measured_rows()
        decisions = select_multirescuer(rows)
        scorecard = score_decisions(rows, decisions)
        failures = gate(scorecard, rows)
        shutil.copyfile(source, rows_dir / "benchmark_predictions.jsonl")
        write_jsonl(rows_dir / "v17_5_canary_route_decisions.jsonl", decisions)
        write_json(rows_dir / "benchmark_scorecard.json", scorecard)
        for name in [
            "v17_5_activation_margin_sweep",
            "v17_5_policy_equivalence_receipt",
            "v17_5_route_distribution_health",
            "v17_5_oracle_gap_owner_matrix",
            "v17_5_route_rescuer_heatmap",
            "v17_5_best_static_semantics_receipt",
            "v17_5_bpr_formula_receipt",
            "v17_5_score_source_authority_receipt",
            "v17_5_claim_admissibility_casefile",
        ]:
            write_json(rows_dir / f"{name}.json", {"schema_id": f"kt.{name}.v1", "status": "PASS" if not failures else "BLOCKED", "claim_ceiling_preserved": True, "runtime_authority": False, "promotion_authority": False})
        write_json(final_dir / "runtime_telemetry_receipt.json", {"schema_id": "kt.v17_5.runtime_telemetry_receipt.v1", "process_isolated_real_arms_required": True, "memory_cleanup_supported": True, "source_rows_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "claim_ceiling_preserved": True})
        if failures:
            write_json(final_dir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.v17_5.blocker_receipt.v1", "status": "BLOCKED", "failures": failures, "claim_ceiling_preserved": True})
        else:
            write_json(final_dir / "final_summary.json", {"schema_id": "kt.v17_5.final_summary.v1", "status": "PASS", "scorecard": scorecard, "claim_ceiling_preserved": True})
    except Exception as exc:
        write_json(final_dir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.v17_5.blocker_receipt.v1", "status": "BLOCKED", "error": str(exc), "claim_ceiling_preserved": True})
    members = list(rows_dir.glob("*")) + list(final_dir.glob("*"))
    if members:
        make_zip(final_dir / "PARTIAL_MEASURED_OUTPUTS.zip", members, out)
    make_zip(out / "ASSESSMENT_ONLY.zip", members + [out / "ASSESSMENT_ONLY.zip"], out)
    print(json.dumps({"assessment_zip": str(out / "ASSESSMENT_ONLY.zip"), "claim_ceiling_preserved": True}, sort_keys=True))


if __name__ == "__main__":
    main()
