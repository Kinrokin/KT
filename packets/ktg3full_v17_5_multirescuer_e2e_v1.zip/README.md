# KTG3FULL V17.5 multi-rescuer canary packet

No training. No promotion. No learned-router superiority claim.
