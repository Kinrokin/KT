from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
config = json.loads((root / 'runtime' / 'ktstoprt_config.json').read_text(encoding='utf-8'))
assert manifest['run_mode'] == 'RUN_STOPSEQ_RUNTIME_STOP_CRITERIA_10ROW_V1'
assert manifest['kaggle_dataset_name'] == 'ktstoprt-v1'
assert manifest['training_authority'] is False
assert manifest['production_prompt_mutation_authority'] is False
assert len(config['rows']) == 10
assert {arm['arm_id'] for arm in config['arm_manifest']['generation_arms']} == {'B0_CURRENT_PROMPT_LEGACY_GENERATION', 'B1_CURRENT_PROMPT_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP'}
assert config['arm_manifest']['offline_derived_arm']['arm_id'] == 'B2_B1_PLUS_CANONICALIZER_V2_REPLAY'
assert all('expected_answer' not in row for row in config['rows'])
