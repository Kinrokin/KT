# KTSTOPRT V1

Sandbox 10-row runtime stop-criteria confirmation packet. It uses the current prompt and compares legacy generation against generated-token-only FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP. No training, promotion, selector deployment, adapter mutation, production prompt mutation, production math-mode claim, or claim expansion.
