from __future__ import annotations

import hashlib
import json
import os
import re
import time
import zipfile
from pathlib import Path


RUN_MODE = "RUN_STOPSEQ_RUNTIME_STOP_CRITERIA_10ROW_V1"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
HF_RESULTS_REPO = os.environ.get("KT_HF_RESULTS_REPO", "Kinrokin/ktstoprt-v1-results")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def extract_answer(text: str):
    matches = re.findall(r"FINAL_ANSWER\s*:\s*([^\r\n]*)", text)
    if matches:
        target = matches[-1]
    else:
        target = text
    fractions = re.findall(r"[-+]?\d[\d,]*\s*/\s*\d[\d,]*", target)
    if fractions:
        return fractions[-1].replace(" ", "").replace(",", "")
    numbers = re.findall(r"[-+]?\$?\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?", target)
    return numbers[-1].replace("$", "").replace(",", "").strip() if numbers else None


def first_complete_line(text: str):
    marker = "FINAL_ANSWER:"
    start = text.find(marker)
    if start < 0:
        return text
    suffix = text[start:]
    line = re.match(r"[^\r\n]*(?:\r\n|\n|\r)", suffix)
    if not line:
        return text
    return text[: start + line.end()]


def score(expected: str, extracted) -> bool:
    return normalize(expected) == normalize(extracted)


def render_prompt(template: str, question: str) -> str:
    return f"{template}\n\nProblem:\n{question}\n"


def version_tuple(value: str):
    nums = []
    for part in re.split(r"[.+-]", value):
        if part.isdigit():
            nums.append(int(part))
        else:
            break
    return tuple(nums)


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    try:
        import bitsandbytes as bnb
    except Exception as exc:
        raise RuntimeError(f"bitsandbytes unavailable: {exc}") from exc
    bnb_version = getattr(bnb, "__version__", "0.0.0")
    if version_tuple(bnb_version) < (0, 46, 1):
        raise RuntimeError(f"bitsandbytes>=0.46.1 required, found {bnb_version}")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    kwargs = {"device_map": "auto", "trust_remote_code": True}
    if os.environ.get("KT_LOAD_IN_4BIT", "1") != "0":
        kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, **kwargs)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer, {"schema_id": "kt.ktstoprt.model_loader_receipt.v1", "status": "PASS", "model_repo": MODEL_REPO, "bitsandbytes_version": bnb_version, "quantization_config_used": "quantization_config" in kwargs}


def generate(model, tokenizer, prompt: str, max_new_tokens: int, use_runtime_stop: bool):
    import torch
    from transformers import StoppingCriteriaList
    from runtime.final_answer_stop import FirstCompleteFinalAnswerLineStoppingCriteria, evaluate_generated_text

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    prompt_len = int(inputs["input_ids"].shape[-1])
    criteria = None
    stop_criteria = None
    if use_runtime_stop:
        stop_criteria = FirstCompleteFinalAnswerLineStoppingCriteria(tokenizer, prompt_len, tokenizer.eos_token_id)
        criteria = StoppingCriteriaList([stop_criteria])
    start = time.time()
    with torch.no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
            stopping_criteria=criteria,
        )
    latency = time.time() - start
    generated_ids = output_ids[0][prompt_len:]
    text = tokenizer.decode(generated_ids, skip_special_tokens=True)
    stop_decision = stop_criteria.last_decision.to_json() if stop_criteria and stop_criteria.last_decision else evaluate_generated_text(text, eos=False).to_json()
    return text, generated_ids.tolist(), prompt_len, int(generated_ids.shape[-1]), latency, stop_decision


def write_blocker(outdir: Path, status: str, reason: str) -> None:
    write_json(outdir / "BLOCKER_RECEIPT.json", {
        "schema_id": "kt.ktstoprt.blocker_receipt.runtime.v1",
        "status": status,
        "reason": reason,
        "run_mode": RUN_MODE,
        "claim_ceiling_status": "PRESERVED",
        "training_authority": False,
        "promotion_authority": False,
        "selector_deployment_authority": False,
        "adapter_mutation_authority": False,
        "production_prompt_mutation_authority": False,
        "production_math_mode_claim": False,
    })


def maybe_upload(outdir: Path, assessment: Path) -> dict:
    token = os.environ.get("HF_TOKEN")
    if not token:
        return {"schema_id": "kt.ktstoprt.hf_upload_receipt.v1", "status": "SKIPPED_NO_HF_TOKEN", "repo_id": HF_RESULTS_REPO}
    try:
        from huggingface_hub import HfApi, create_repo, upload_file, upload_folder
        create_repo(HF_RESULTS_REPO, repo_type="dataset", private=False, exist_ok=True, token=token)
        upload_folder(repo_id=HF_RESULTS_REPO, repo_type="dataset", folder_path=str(outdir), path_in_repo="artifacts", token=token)
        upload_file(repo_id=HF_RESULTS_REPO, repo_type="dataset", path_or_fileobj=str(assessment), path_in_repo=assessment.name, token=token)
        info = HfApi(token=token).dataset_info(HF_RESULTS_REPO)
        return {"schema_id": "kt.ktstoprt.hf_upload_receipt.v1", "status": "PASS", "repo_id": HF_RESULTS_REPO, "url": f"https://huggingface.co/datasets/{HF_RESULTS_REPO}", "private": bool(info.private)}
    except Exception as exc:
        return {"schema_id": "kt.ktstoprt.hf_upload_receipt.v1", "status": "FAILED_NON_FATAL", "repo_id": HF_RESULTS_REPO, "error": str(exc)}


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktstoprt_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstoprt_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOPRT_V1_ASSESSMENT_ONLY.zip"))
    events = [{"event": "start", "run_mode": RUN_MODE, "row_count": len(config["rows"])}]
    try:
        write_json(outdir / "row_manifest.json", {"schema_id": "kt.ktstoprt.row_manifest.v1", "rows": config["rows"], "row_count": len(config["rows"]), "claim_ceiling_status": "PRESERVED"})
        write_json(outdir / "arm_manifest.json", config["arm_manifest"])
        write_json(outdir / "metric_definition_receipt.json", config["metric_definition_receipt"])
        write_json(outdir / "claim_boundary_receipt.json", config["claim_boundary"])
        model, tokenizer, loader = load_model()
        write_json(outdir / "model_loader_receipt.json", loader)
        predictions = []
        token_rows = []
        stop_rows = []
        prefix_rows = []
        for row in config["rows"]:
            expected = config["scorer_expected_answers"][row["row_id"]]
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            b0_text, b0_ids, b0_prompt_tokens, b0_out_tokens, b0_latency, b0_stop = generate(model, tokenizer, prompt, 512, False)
            b1_text, b1_ids, b1_prompt_tokens, b1_out_tokens, b1_latency, b1_stop = generate(model, tokenizer, prompt, 512, True)
            b0_first = first_complete_line(b0_text)
            b0_prefix_ids = tokenizer(b0_first, add_special_tokens=False)["input_ids"]
            prefix_equal = b0_prefix_ids == b1_ids
            for arm_id, text, ids, prompt_tokens, output_tokens, latency, stop in [
                ("B0_CURRENT_PROMPT_LEGACY_GENERATION", b0_text, b0_ids, b0_prompt_tokens, b0_out_tokens, b0_latency, b0_stop),
                ("B1_CURRENT_PROMPT_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP", b1_text, b1_ids, b1_prompt_tokens, b1_out_tokens, b1_latency, b1_stop),
            ]:
                extracted = extract_answer(text)
                predictions.append({
                    "schema_id": "kt.ktstoprt.prediction_row.v1",
                    "row_id": row["row_id"],
                    "arm_id": arm_id,
                    "raw_output": text,
                    "raw_output_hash": sha256_text(text),
                    "extracted_answer": extracted,
                    "correct": score(expected, extracted),
                    "output_tokens": output_tokens,
                    "latency_seconds": round(latency, 3),
                    "stop_reason": stop.get("reason"),
                    "claim_ceiling_status": "PRESERVED",
                })
                token_rows.append({"schema_id": "kt.ktstoprt.token_ledger_row.v1", "row_id": row["row_id"], "arm_id": arm_id, "prompt_tokens": prompt_tokens, "output_tokens": output_tokens})
                stop_rows.append({"schema_id": "kt.ktstoprt.stop_reason_row.v1", "row_id": row["row_id"], "arm_id": arm_id, **stop})
            b2_text = first_complete_line(b1_text)
            b2_extracted = extract_answer(b2_text)
            predictions.append({
                "schema_id": "kt.ktstoprt.prediction_row.v1",
                "row_id": row["row_id"],
                "arm_id": "B2_B1_PLUS_CANONICALIZER_V2_REPLAY",
                "raw_output": b2_text,
                "raw_output_hash": sha256_text(b2_text),
                "extracted_answer": b2_extracted,
                "correct": score(expected, b2_extracted),
                "output_tokens": len(tokenizer(b2_text, add_special_tokens=False)["input_ids"]),
                "latency_seconds": 0.0,
                "stop_reason": "OFFLINE_REPLAY",
                "claim_ceiling_status": "PRESERVED",
            })
            prefix_rows.append({
                "schema_id": "kt.ktstoprt.prefix_equivalence_row.v1",
                "row_id": row["row_id"],
                "baseline_prefix_hash": sha256_text(json.dumps(b0_prefix_ids)),
                "runtime_stop_sequence_hash": sha256_text(json.dumps(b1_ids)),
                "prefix_equal": prefix_equal,
                "first_complete_line_token_count": len(b0_prefix_ids),
                "prompt_boundary_token_index": b0_prompt_tokens,
                "stop_token_index": b1_prompt_tokens + len(b1_ids),
            })
        write_jsonl(outdir / "predictions.jsonl", predictions)
        write_jsonl(outdir / "token_ledger.jsonl", token_rows)
        write_jsonl(outdir / "stop_reason_ledger.jsonl", stop_rows)
        b0 = [r for r in predictions if r["arm_id"] == "B0_CURRENT_PROMPT_LEGACY_GENERATION"]
        b1 = [r for r in predictions if r["arm_id"] == "B1_CURRENT_PROMPT_FIRST_COMPLETE_FINAL_ANSWER_LINE_STOP"]
        prefix_pass = sum(1 for row in prefix_rows if row["prefix_equal"])
        b1_trailer_count = sum(1 for r in b1 if r["stop_reason"] not in {"FINAL_ANSWER_LINE_COMPLETE", "EOS"})
        scorecard = {
            "schema_id": "kt.ktstoprt.runtime_stop_scorecard.v1",
            "b0_correct": sum(1 for r in b0 if r["correct"]),
            "b1_correct": sum(1 for r in b1 if r["correct"]),
            "correctness_delta": sum(1 for r in b1 if r["correct"]) - sum(1 for r in b0 if r["correct"]),
            "prefix_equivalence": f"{prefix_pass}/10",
            "semantic_trailer_rate": b1_trailer_count / max(len(b1), 1),
            "b0_total_output_tokens": sum(r["output_tokens"] for r in b0),
            "b1_total_output_tokens": sum(r["output_tokens"] for r in b1),
            "pass_gate": prefix_pass == 10 and sum(1 for r in b1 if r["correct"]) >= sum(1 for r in b0 if r["correct"]) and sum(r["output_tokens"] for r in b1) < sum(r["output_tokens"] for r in b0),
            "claim_ceiling_status": "PRESERVED",
        }
        write_json(outdir / "runtime_stop_scorecard.json", scorecard)
        write_json(outdir / "prefix_equivalence_receipt.json", {"schema_id": "kt.ktstoprt.prefix_equivalence_receipt.v1", "rows": prefix_rows, "prefix_equal_count": prefix_pass, "claim_ceiling_status": "PRESERVED"})
        write_json(outdir / "first_last_final_audit.json", config["first_last_final_audit"])
        write_json(outdir / "final_summary.json", {"schema_id": "kt.ktstoprt.final_summary.v1", "status": "PASS_MODEL_GENERATED_AND_SCORED", "run_mode": RUN_MODE, "row_count": len(config["rows"]), "pass_gate": scorecard["pass_gate"], "claim_ceiling_status": "PRESERVED"})
        events.append({"event": "completed", "pass_gate": scorecard["pass_gate"]})
    except Exception as exc:
        write_blocker(outdir, "KT_STOPRT_RUNTIME_BLOCKED", str(exc))
        events.append({"event": "blocked", "reason": str(exc)})
        assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOPRT_V1_BLOCKER_ASSESSMENT_ONLY.zip"))
    write_jsonl(outdir / "run_events.jsonl", events)
    with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(outdir.iterdir()):
            zf.write(path, path.name)
    upload = maybe_upload(outdir, assessment)
    write_json(outdir / "HF_UPLOAD_RECEIPT.json", upload)
    with zipfile.ZipFile(assessment, "a", zipfile.ZIP_DEFLATED) as zf:
        zf.write(outdir / "HF_UPLOAD_RECEIPT.json", "HF_UPLOAD_RECEIPT.json")
    print(str(assessment))


if __name__ == "__main__":
    main()
