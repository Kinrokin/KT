from __future__ import annotations

import json
import math
from pathlib import Path


def exact_zero_event_upper_bound(n: int, alpha: float = 0.05) -> float:
    return 1 - alpha ** (1 / max(n, 1))


def _rows(records):
    return records if isinstance(records, list) else [json.loads(line) for line in Path(records).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def execute_result_court(records, config: dict, publication_status: str = "PASS_HF_FINAL_ASSESSMENT_UPLOADED") -> dict:
    rows = _rows(records)
    natural = [r for r in rows if r.get("phase") == "natural"]
    timing = [r for r in rows if r.get("phase") == "timing"]
    edge = [r for r in rows if r.get("phase") == "edge"]
    by_row = {}
    for r in natural:
        by_row.setdefault(r["row_id"], {})[r["arm_id"]] = r
    damage = 0
    first_wrong_later_correct = 0
    prefix_mismatch = 0
    disagreement = 0
    unsafe = 0
    negative_savings = 0
    savings = []
    rescans = 0
    for row_id, arms in by_row.items():
        l0 = arms.get("L0_LEGACY_NO_DETECTOR")
        s1 = arms.get("S1_STREAMING_DETECTOR_RUNTIME_TERMINATE")
        if not l0 or not s1:
            continue
        if bool(l0.get("correct")) and not bool(s1.get("correct")):
            damage += 1
        if s1.get("first_wrong_later_correct"):
            first_wrong_later_correct += 1
        if not s1.get("prefix_equivalence", True):
            prefix_mismatch += 1
        if not s1.get("runtime_reference_agree", True):
            disagreement += 1
        if s1.get("unsafe_stop"):
            unsafe += 1
        delta = int(l0.get("raw_generated_token_count", 0)) - int(s1.get("preserved_generated_token_count", 0))
        savings.append(delta)
        if delta < 0:
            negative_savings += 1
        rescans += int(s1.get("detector_telemetry", {}).get("full_sequence_rescan_count", 0))
    status = "PASS_TOKEN_ONLY__LATENCY_NOT_ESTABLISHED__SHADOW_PACKET_AUTHORING_EARNED"
    if damage:
        status = "BLOCK_CORRECTNESS_DAMAGE"
    elif first_wrong_later_correct:
        status = "BLOCK_FIRST_ANSWER_CORRECTION_CUT"
    elif prefix_mismatch:
        status = "BLOCK_PREFIX_EQUIVALENCE"
    elif disagreement:
        status = "BLOCK_RUNTIME_REFERENCE_DISAGREEMENT"
    elif unsafe:
        status = "BLOCK_UNSAFE_STOP"
    elif negative_savings or not savings or sorted(savings)[len(savings)//2] <= 0:
        status = "BLOCK_TOKEN_ECONOMICS"
    elif rescans:
        status = "BLOCK_TIMING_PROTOCOL_VIOLATION"
    elif publication_status != "PASS_HF_FINAL_ASSESSMENT_UPLOADED":
        status = "BLOCK_ARTIFACT_PUBLICATION_FAILURE"
    if len({r["row_id"] for r in natural}) < 300 or len(timing) < 540 or len(edge) < 36:
        status = "PARTIAL_WALL_TIME_CHECKPOINTED"
    return {"schema_id": "kt.stop300.v3.final_summary.v1", "status": status, "independent_n": len(by_row), "observed_damage": damage, "alpha": 0.05, "exact_upper_bound": exact_zero_event_upper_bound(len(by_row), 0.05), "natural_generation_rows": len(natural), "timing_generation_rows": len(timing), "edge_generation_rows": len(edge), "claim_ceiling_status": "PRESERVED"}


def synthetic_mutation_suite() -> dict:
    base = []
    for i in range(300):
        base.append({"phase": "natural", "row_id": f"r{i}", "arm_id": "L0_LEGACY_NO_DETECTOR", "correct": True, "raw_generated_token_count": 20, "preserved_generated_token_count": 20})
        base.append({"phase": "natural", "row_id": f"r{i}", "arm_id": "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE", "correct": True, "raw_generated_token_count": 20, "preserved_generated_token_count": 10, "prefix_equivalence": True, "runtime_reference_agree": True, "detector_telemetry": {"full_sequence_rescan_count": 0}})
    for i in range(60):
        for rep in range(3):
            for arm in ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
                base.append({"phase": "timing", "row_id": f"t{i}", "repetition": rep, "arm_id": arm})
    for i in range(12):
        for arm in ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
            base.append({"phase": "edge", "row_id": f"e{i}", "arm_id": arm})
    cases = {}
    mutations = {
        "correctness_damage": ("BLOCK_CORRECTNESS_DAMAGE", lambda rows: rows.__setitem__(1, {**rows[1], "correct": False})),
        "late_correction_cut": ("BLOCK_FIRST_ANSWER_CORRECTION_CUT", lambda rows: rows.__setitem__(1, {**rows[1], "first_wrong_later_correct": True})),
        "prefix_mismatch": ("BLOCK_PREFIX_EQUIVALENCE", lambda rows: rows.__setitem__(1, {**rows[1], "prefix_equivalence": False})),
        "unsafe_stop": ("BLOCK_UNSAFE_STOP", lambda rows: rows.__setitem__(1, {**rows[1], "unsafe_stop": True})),
        "runtime_reference_disagreement": ("BLOCK_RUNTIME_REFERENCE_DISAGREEMENT", lambda rows: rows.__setitem__(1, {**rows[1], "runtime_reference_agree": False})),
        "zero_token_savings": ("BLOCK_TOKEN_ECONOMICS", lambda rows: [rows.__setitem__(idx, {**rows[idx], "preserved_generated_token_count": 20}) for idx in range(1, 600, 2)]),
        "negative_savings": ("BLOCK_TOKEN_ECONOMICS", lambda rows: rows.__setitem__(1, {**rows[1], "preserved_generated_token_count": 30})),
        "publication_failure": ("BLOCK_ARTIFACT_PUBLICATION_FAILURE", lambda rows: None),
        "timing_protocol_failure": ("PARTIAL_WALL_TIME_CHECKPOINTED", lambda rows: rows.pop()),
    }
    for name, (expected, mutate) in mutations.items():
        rows = [dict(r) for r in base]
        mutate(rows)
        pub = "FAIL" if name == "publication_failure" else "PASS_HF_FINAL_ASSESSMENT_UPLOADED"
        status = execute_result_court(rows, {}, publication_status=pub)["status"]
        cases[name] = {"expected": expected, "actual": status, "pass": status == expected}
    return {"schema_id": "kt.stop300.v3.synthetic_court_mutation_suite.v1", "status": "PASS_FAIL_CLOSED_SYNTHETIC_MUTATION_SUITE" if all(v["pass"] for v in cases.values()) else "FAIL", "cases": cases, "claim_ceiling_status": "PRESERVED"}
