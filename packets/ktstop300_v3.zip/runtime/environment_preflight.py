from __future__ import annotations

import importlib.metadata
import subprocess


def environment_preflight() -> dict:
    import torch
    try:
        bnb = importlib.metadata.version("bitsandbytes")
    except Exception:
        bnb = None
    before = subprocess.run(["python", "-m", "pip", "check"], text=True, capture_output=True, timeout=120)
    return {"schema_id": "kt.stop300.v3.environment_preflight.v1", "status": "PASS_PREFLIGHT_READY_FOR_MODEL_ATTESTATION" if bnb == "0.49.2" and before.returncode == 0 else "KT_STOP300_V3_ENVIRONMENT_BLOCKED", "bitsandbytes": bnb, "python": __import__("sys").version, "torch": torch.__version__, "cuda_available": torch.cuda.is_available(), "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None, "cuda_compute_capability": torch.cuda.get_device_capability(0) if torch.cuda.is_available() else None, "pip_check_before": before.returncode, "claim_ceiling_status": "PRESERVED"}
