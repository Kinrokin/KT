from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path


def work_key(scope_hash: str, phase: str, row_id: str, repetition: int, arm: str) -> str:
    return f"{scope_hash}/{phase}/{row_id}/{repetition}/{arm}"


def key_hash(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


class AtomicRecordStore:
    def __init__(self, root: Path, scope_hash: str):
        self.root = Path(root)
        self.records = self.root / "records"
        self.records.mkdir(parents=True, exist_ok=True)
        self.scope_hash = scope_hash

    def path_for(self, key: str) -> Path:
        return self.records / f"{key_hash(key)}.json"

    def completed_keys(self) -> set[str]:
        out = set()
        for path in self.records.glob("*.json"):
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            key = data["work_key"]
            if data.get("work_key_sha256") != key_hash(key):
                raise SystemExit("BLOCK_SCOPE_MISMATCH")
            out.add(key)
        return out

    def write_once(self, key: str, payload: dict) -> bool:
        path = self.path_for(key)
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            if data.get("work_key_sha256") != key_hash(key):
                raise SystemExit("record hash mismatch")
            return False
        payload = dict(payload)
        payload["work_key"] = key
        payload["work_key_sha256"] = key_hash(key)
        fd, tmp = tempfile.mkstemp(dir=self.records, prefix=path.name, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(json.dumps(payload, sort_keys=True) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        return True

    def assemble_jsonl(self, target: Path) -> None:
        rows = []
        for path in sorted(self.records.glob("*.json")):
            rows.append(json.loads(path.read_text(encoding="utf-8-sig")))
        target.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8", newline="\n")
