from __future__ import annotations

import json
import zipfile
from pathlib import Path

DEFAULT_WRAPPER_NAME = "KT_STOP300_V3_WRAPPER_COLLECTION.zip"

class CheckpointManager:
    def __init__(self, outdir: Path, scope_hash: str):
        self.outdir = Path(outdir)
        self.scope_hash = scope_hash
        self.index = []

    def write_zip(self, target: Path, names: list[str] | None = None) -> Path:
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(self.outdir.rglob("*")):
                if not path.is_file() or path.suffix == ".zip":
                    continue
                rel = path.relative_to(self.outdir).as_posix()
                if names is None or rel in names or rel.startswith("records/"):
                    zf.write(path, rel)
        return target

    def checkpoint(self, reason: str) -> Path:
        path = self.outdir / "PARTIAL_MEASURED_OUTPUTS.zip"
        self.write_zip(path)
        self.index.append({"reason": reason, "path": str(path), "scope_hash": self.scope_hash})
        (self.outdir / "RESUME_RECEIPT.json").write_text(json.dumps({"schema_id": "kt.stop300.v3.resume_receipt.v1", "status": "PARTIAL_EXTERNAL_INTERRUPTION_RECOVERABLE", "checkpoints": self.index, "claim_ceiling_status": "PRESERVED"}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return path

    def final_zips(self, assessment: Path, wrapper: Path) -> None:
        self.write_zip(assessment)
        with zipfile.ZipFile(wrapper, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(assessment, assessment.name)
            for name in ["HF_FINAL_ASSESSMENT_UPLOAD_RECEIPT.json", "RESUME_RECEIPT.json"]:
                path = self.outdir / name
                if path.exists():
                    zf.write(path, name)
