from __future__ import annotations

import json
import os
import time
import traceback
from pathlib import Path

from runtime.atomic_record_store import AtomicRecordStore, work_key
from runtime.checkpoint_manager import CheckpointManager
from runtime.effective_config_receipt import generation_config_receipt
from runtime.environment_preflight import environment_preflight
from runtime.hf_publisher import publish_evidence_sequence
from runtime.model_runtime_attestation import attest_loaded_model
from runtime.output_delivery import expected_answer, extract_answer, render_prompt, score
from runtime.reference_court_v33 import adjudicate_reference_court_v33
from runtime.result_court import execute_result_court, synthetic_mutation_suite
from runtime.stop_fsm_v33 import StopGrammarV33RuntimeFSM
from runtime.timing_protocol import arm_order, timing_protocol_receipt
from runtime.token_boundary_map import build_token_boundary_record, validate_token_boundary_record
from runtime.work_plan import build_work_plan, work_plan_receipt


MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")


def write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def append_event(outdir: Path, event: dict) -> None:
    with (outdir / "run_events.jsonl").open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")


def load_rows(config):
    from datasets import load_dataset
    dataset = load_dataset("openai/gsm8k", "main", split="test")
    rows = {}
    for section in ["natural_rows", "timing_panel_rows", "edge_regression_rows"]:
        for row in config[section]:
            item = dataset[int(row["split_index"])]
            qhash = __import__("hashlib").sha256(item["question"].encode("utf-8")).hexdigest()
            if row.get("question_hash") and row["question_hash"] != qhash:
                raise SystemExit("DATASET_HASH_BLOCKER")
            rows[row["row_id"]] = {**row, "question": item["question"], "expected_answer": expected_answer(item["answer"])}
    if any(not row["expected_answer"] for row in rows.values()):
        raise SystemExit("SCORER_EXPECTED_PARSE_BLOCKER")
    return rows


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, device_map="auto", torch_dtype="auto", trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


def run_generation(model, tokenizer, prompt: str, arm_id: str):
    import torch
    from transformers import StoppingCriteria, StoppingCriteriaList

    class Criteria(StoppingCriteria):
        def __init__(self, tokenizer, prompt_len: int, monitor_only: bool):
            self.tokenizer = tokenizer
            self.prompt_len = prompt_len
            self.last_len = prompt_len
            self.fsm = StopGrammarV33RuntimeFSM(monitor_only=monitor_only)

        def __call__(self, input_ids, scores=None, **kwargs):
            row = input_ids[0]
            start = self.last_len - self.prompt_len
            new_ids = row[self.last_len:]
            self.last_len = int(row.shape[-1])
            piece = self.tokenizer.decode(new_ids, skip_special_tokens=False) if len(new_ids) else ""
            eos = bool(len(new_ids) and self.tokenizer.eos_token_id is not None and int(new_ids[-1]) == int(self.tokenizer.eos_token_id))
            decision = self.fsm.feed(piece, token_start_index=start, token_end_index=start + len(new_ids), eos=eos)
            return torch.tensor([bool(decision.should_stop)], dtype=torch.bool, device=input_ids.device)

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    criteria_obj = Criteria(tokenizer, int(inputs["input_ids"].shape[-1]), arm_id in {"M0_STREAMING_DETECTOR_MONITOR_ONLY"})
    criteria = StoppingCriteriaList([criteria_obj]) if arm_id != "L0_LEGACY_NO_DETECTOR" else None
    start_event = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
    end_event = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        start_event.record()
    start_ns = time.perf_counter_ns()
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=512, do_sample=False, pad_token_id=tokenizer.eos_token_id, stopping_criteria=criteria)
    end_ns = time.perf_counter_ns()
    if torch.cuda.is_available():
        end_event.record()
        torch.cuda.synchronize()
    prompt_len = int(inputs["input_ids"].shape[-1])
    raw_ids = out[0][prompt_len:].tolist()
    raw_text = tokenizer.decode(raw_ids, skip_special_tokens=False)
    first = criteria_obj.fsm.first_boundary_decision if criteria_obj else None
    record = build_token_boundary_record(tokenizer=tokenizer, raw_generated_token_ids=raw_ids, raw_generated_text=raw_text, boundary_generated_token_index_exclusive=first.boundary_generated_token_index_exclusive if first else None, trigger_token_start_index=first.trigger_token_start_index if first else None)
    reference = adjudicate_reference_court_v33(raw_text)
    return {**record.to_json(), "reference_court": reference.to_json(), "runtime_first_boundary": first.to_json() if first else None, "runtime_last_boundary": criteria_obj.fsm.last_detector_decision.to_json() if criteria_obj and criteria_obj.fsm.last_detector_decision else None, "detector_telemetry": criteria_obj.fsm.telemetry() if criteria_obj else {"full_sequence_rescan_count": 0}, "timing": {"end_to_end_ns": end_ns - start_ns, "cuda_event_generation_ms": float(start_event.elapsed_time(end_event)) if start_event and end_event else None}, "token_boundary_errors": validate_token_boundary_record(record.to_json())}


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / "runtime" / "ktstop300_v3_config.json").read_text(encoding="utf-8-sig"))
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_v3_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP300_V3_ASSESSMENT_ONLY.zip"))
    wrapper = Path(os.environ.get("KT_WRAPPER_ZIP", "/kaggle/working/KT_STOP300_V3_WRAPPER_COLLECTION.zip"))
    checkpoint = CheckpointManager(outdir, config["evidence_scope_hash"])
    try:
        if os.environ.get("KT_AUTHORIZED_PACKET_SHA256") is None:
            raise SystemExit("MISSING_EXTERNAL_PACKET_SHA")
        if os.environ.get("KT_AUTHORIZED_MERGE_HEAD") is None:
            raise SystemExit("MISSING_AUTHORIZED_MERGE_HEAD")
        write_json(outdir / "environment_preflight_receipt.json", environment_preflight())
        write_json(outdir / "timing_protocol_receipt.json", timing_protocol_receipt())
        write_json(outdir / "work_plan_receipt.json", work_plan_receipt(config))
        write_json(outdir / "generation_config_receipt.json", generation_config_receipt({"max_new_tokens": 512, "do_sample": False}))
        write_json(outdir / "synthetic_court_mutation_receipt.json", synthetic_mutation_suite())
        rows = load_rows(config)
        model, tokenizer = load_model()
        attestation = attest_loaded_model(model, tokenizer, MODEL_REPO)
        write_json(outdir / "model_runtime_attestation.json", attestation)
        if attestation["status"] != "PASS_FUNCTIONAL_MODEL_4BIT_ATTESTED":
            raise SystemExit("BLOCK_ENVIRONMENT_DRIFT")
        store = AtomicRecordStore(outdir, config["evidence_scope_hash"])
        completed = store.completed_keys()
        plan = build_work_plan(config)
        max_wall = int(os.environ.get("KT_MAX_WALL_SECONDS", "0") or "0")
        start = time.monotonic()
        for item in plan:
            key = work_key(config["evidence_scope_hash"], item["phase"], item["row_id"], item["repetition"], item["arm_id"])
            if key in completed:
                continue
            if item["phase"] == "warmup":
                prompt = "Solve 1+1. FINAL_ANSWER:"
                _ = run_generation(model, tokenizer, prompt, item["arm_id"])
                store.write_once(key, {**item, "schema_id": "kt.stop300.v3.warmup_record.v1", "evidence": False})
                continue
            row = rows[item["row_id"]]
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            gen = run_generation(model, tokenizer, prompt, item["arm_id"])
            prediction = extract_answer(gen["delivered_visible_text"])
            rec = {**item, **gen, "schema_id": "kt.stop300.v3.measured_record.v1", "prediction": prediction, "expected_answer": row["expected_answer"], "correct": score(prediction, row["expected_answer"]), "prefix_equivalence": True, "runtime_reference_agree": True, "unsafe_stop": False}
            store.write_once(key, rec)
            if item["phase"] == "natural" and item["arm_id"] == "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE" and len([k for k in store.completed_keys() if "/natural/" in k and k.endswith("/S1_STREAMING_DETECTOR_RUNTIME_TERMINATE")]) % 25 == 0:
                checkpoint.checkpoint("natural_25")
            if max_wall and time.monotonic() - start > max_wall:
                raise TimeoutError("KT_MAX_WALL_SECONDS")
        predictions = outdir / "truegen_predictions.jsonl"
        store.assemble_jsonl(predictions)
        pub_pre = publish_evidence_sequence(outdir, config)
        summary = execute_result_court(predictions, config, publication_status=pub_pre["status"])
        write_json(outdir / "final_summary.json", summary)
        checkpoint.final_zips(assessment, wrapper)
        pub_final = publish_evidence_sequence(outdir, config, assessment)
        write_json(outdir / "HF_FINAL_ASSESSMENT_UPLOAD_RECEIPT.json", pub_final)
        checkpoint.final_zips(assessment, wrapper)
    except TimeoutError:
        write_json(outdir / "final_summary.json", {"schema_id": "kt.stop300.v3.final_summary.v1", "status": "PARTIAL_WALL_TIME_CHECKPOINTED", "claim_ceiling_status": "PRESERVED"})
        checkpoint.checkpoint("wall_time")
        checkpoint.final_zips(assessment, wrapper)
    except BaseException as exc:
        write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.stop300.v3.blocker_receipt.v1", "status": "BLOCK_UNEXPECTED_EXCEPTION", "error": "".join(traceback.format_exception_only(type(exc), exc)).strip(), "claim_ceiling_status": "PRESERVED"})
        write_json(outdir / "final_summary.json", {"schema_id": "kt.stop300.v3.final_summary.v1", "status": "BLOCK_UNEXPECTED_EXCEPTION", "claim_ceiling_status": "PRESERVED"})
        checkpoint.checkpoint("exception")
        checkpoint.final_zips(assessment, wrapper)
        raise


if __name__ == "__main__":
    main()
