from __future__ import annotations

from decimal import Decimal, InvalidOperation
from fractions import Fraction
import re


def normalize_number(text: str) -> str:
    raw = str(text).strip().replace(",", "")
    raw = raw.replace("$", "")
    percent = raw.endswith("%")
    if percent:
        raw = raw[:-1]
    try:
        value = Decimal(raw)
    except InvalidOperation:
        try:
            value = Decimal(Fraction(raw))
        except Exception:
            match = re.findall(r"-?\$?\d[\d,]*(?:\.\d+)?(?:e[-+]?\d+)?%?|-?\d+\s*/\s*\d+", raw, re.I)
            if not match:
                return ""
            return normalize_number(match[-1])
    if percent:
        value = value / Decimal(100)
    return format(value.normalize(), "f").rstrip("0").rstrip(".") if "." in format(value.normalize(), "f") else format(value.normalize(), "f")


def expected_answer(answer: str) -> str:
    if "####" in answer:
        answer = answer.split("####")[-1]
    return normalize_number(answer)


def extract_answer(text: str) -> str:
    marker = re.search(r"FINAL_ANSWER:\s*([^\n\r]+)", text or "")
    payload = marker.group(1) if marker else text
    return normalize_number(payload)


def score(prediction: str, expected: str) -> bool:
    return normalize_number(prediction) == normalize_number(expected)


def render_prompt(template: str, question: str) -> str:
    return template.replace("{question}", question)
