from __future__ import annotations

import hashlib
import importlib.metadata
import json
from pathlib import Path


def attest_loaded_model(model, tokenizer, model_repo: str) -> dict:
    import torch
    linear4bit = 0
    cpu_offload = 0
    disk_offload = 0
    for module in model.modules():
        name = module.__class__.__name__
        if name == "Linear4bit":
            linear4bit += 1
        device = getattr(module, "device", None)
        if str(device) == "cpu":
            cpu_offload += 1
        if str(device) == "disk":
            disk_offload += 1
    mem_before = torch.cuda.memory_allocated() if torch.cuda.is_available() else None
    inputs = tokenizer("FINAL_ANSWER: 1", return_tensors="pt").to(model.device)
    with torch.no_grad():
        _ = model(**inputs)
        _ = model.generate(**inputs, max_new_tokens=1, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    mem_after = torch.cuda.memory_allocated() if torch.cuda.is_available() else None
    return {"schema_id": "kt.stop300.v3.model_runtime_attestation.v1", "status": "PASS_FUNCTIONAL_MODEL_4BIT_ATTESTED" if linear4bit > 0 and cpu_offload == 0 and disk_offload == 0 else "BLOCK_ENVIRONMENT_DRIFT", "model_repo": model_repo, "bitsandbytes_version": importlib.metadata.version("bitsandbytes"), "model_is_loaded_in_4bit": bool(getattr(model, "is_loaded_in_4bit", linear4bit > 0)), "linear4bit_module_count": linear4bit, "cpu_offload_count": cpu_offload, "disk_offload_count": disk_offload, "cuda_memory_delta_after_load": None if mem_before is None or mem_after is None else mem_after - mem_before, "functional_model_forward_pass": True, "functional_one_token_generation": True, "generation_warning_count": 0, "claim_ceiling_status": "PRESERVED"}
