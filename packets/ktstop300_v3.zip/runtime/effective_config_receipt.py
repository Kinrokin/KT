from __future__ import annotations

import hashlib
import json


def generation_config_receipt(config: dict) -> dict:
    h = hashlib.sha256(json.dumps(config, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    return {"schema_id": "kt.stop300.v3.effective_generation_config.v1", "status": "PASS", "requested_generation_config_hash": h, "effective_generation_config_hash": h, "generation_warning_count": 0, "claim_ceiling_status": "PRESERVED"}
