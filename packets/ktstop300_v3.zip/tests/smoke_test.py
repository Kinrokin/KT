from runtime.stop_fsm_v33 import StopGrammarV33RuntimeFSM
from runtime.reference_court_v33 import adjudicate_reference_court_v33
from runtime.result_court import synthetic_mutation_suite
from runtime.work_plan import work_plan_receipt


def test_stop300_v3_smoke():
    fsm = StopGrammarV33RuntimeFSM()
    d1 = fsm.feed('FINAL_ANSWER: 42\n', token_start_index=0, token_end_index=1)
    d2 = fsm.feed('FINAL_ANSWER: 99\n', token_start_index=1, token_end_index=2)
    assert fsm.first_boundary_decision.semantic_boundary_type.value == 'FINAL_LINE_CLOSE'
    assert d1.semantic_boundary_type.value == 'FINAL_LINE_CLOSE'
    assert d2.semantic_boundary_type.value == 'FINAL_LINE_CLOSE'
    assert adjudicate_reference_court_v33('FINAL_ANSWER: 42\n').semantic_boundary_type == 'FINAL_LINE_CLOSE'
    assert synthetic_mutation_suite()['status'] == 'PASS_FAIL_CLOSED_SYNTHETIC_MUTATION_SUITE'
