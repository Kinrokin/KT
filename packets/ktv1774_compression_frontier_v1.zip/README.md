# KTV1774 Compression Frontier True-Generation Mini-Furnace V1

This packet preserves the V17.7.4 real-arm model-load repair and adds compression-frontier measurement. It binds the truegen runner to the intended Qwen 7B substrate and real adapter-source paths. The model loader uses `AutoModelForCausalLM.from_pretrained` and places 4-bit loading inside `BitsAndBytesConfig(..., load_in_4bit=True)` via `quantization_config`. It never forwards `load_in_4bit` as a raw Qwen constructor/from_pretrained kwarg. It performs fresh generation or fails closed. It measures token economics, ablation-ladder performance, bloat attribution, parser drift, and compression frontier status. It does not train, promote, authorize V18, or claim learned-router superiority.

Set `KT_TRUEGEN_ADAPTER_ROOT` if the Kaggle adapter dataset path differs from the bundled default.
