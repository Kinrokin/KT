from runtime.stop_fsm_v34 import StopGrammarV34RuntimeFSM
from runtime.reference_court_v34 import adjudicate_reference_court_v34
from runtime.result_court import synthetic_mutation_suite
from runtime.boundary_evidence import build_physical_token_ledger, validate_physical_token_ledger


def test_stop300_v4_smoke():
    fsm = StopGrammarV34RuntimeFSM()
    decision = fsm.feed('FINAL_ANSWER: 42\n', token_start_index=0, token_end_index=1)
    assert decision.should_stop
    assert fsm.first_boundary_decision.semantic_boundary_type.value == 'FINAL_LINE_CLOSE'
    assert adjudicate_reference_court_v34('FINAL_ANSWER: 42', terminal_token_id=2, effective_eos_token_ids={2}).semantic_boundary_type == 'SAFE_EOS_CLOSURE'
    ledger = build_physical_token_ledger(prompt_token_ids=[10], raw_generated_token_ids=[1,2,3], semantic_visible_text='FINAL_ANSWER: 4', canonical_extracted_answer='4', generator_termination_source='CUSTOM_STOP_CRITERION', boundary_token_index_floor=1, boundary_token_index_ceil=2)
    assert validate_physical_token_ledger(ledger.to_json()) == []
    assert synthetic_mutation_suite()['status'] == 'PASS_CONJUNCTIVE_FAIL_CLOSED_MUTATION_SUITE'
