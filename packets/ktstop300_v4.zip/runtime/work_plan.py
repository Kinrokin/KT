from __future__ import annotations

from runtime.timing_protocol import ARMS, arm_order


def build_work_plan(config: dict) -> list[dict]:
    plan = []
    for arm in ARMS:
        for warmup_index in range(3):
            plan.append({"phase": "warmup", "row_id": f"warmup_{arm}_{warmup_index}", "repetition": warmup_index, "arm_id": arm, "evidence": False})
    for row in config["edge_regression_rows"]:
        for arm in arm_order(row["row_id"], 0):
            plan.append({"phase": "edge", "row_id": row["row_id"], "repetition": 0, "arm_id": arm, "evidence": True})
    for row in config["natural_rows"]:
        for arm in ["L0_LEGACY_NO_DETECTOR", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
            plan.append({"phase": "natural", "row_id": row["row_id"], "repetition": 0, "arm_id": arm, "evidence": True})
    for row in config["timing_panel_rows"]:
        for repetition in range(3):
            for arm in arm_order(row["row_id"], repetition):
                plan.append({"phase": "timing", "row_id": row["row_id"], "repetition": repetition, "arm_id": arm, "evidence": True})
    return plan


def work_plan_receipt(config: dict) -> dict:
    plan = build_work_plan(config)
    measured = [item for item in plan if item["evidence"]]
    warmups = [item for item in plan if not item["evidence"]]
    return {
        "schema_id": "kt.stop300.v4.work_plan.v1",
        "status": "PASS_1176_MEASURED_PLUS_9_WARMUPS",
        "measured_work_units": len(measured),
        "warmup_units": len(warmups),
        "edge": 36,
        "natural": 600,
        "timing": 540,
        "claim_ceiling_status": "PRESERVED",
    }
