from __future__ import annotations

import json
import os
import time
import traceback
from pathlib import Path

from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from runtime.atomic_record_store import AtomicRecordStore, work_key
from runtime.boundary_evidence import build_physical_token_ledger, validate_physical_token_ledger
from runtime.checkpoint_manager import CheckpointManager
from runtime.hf_publisher import publish_evidence, publish_final_assessment
from runtime.model_runtime_attestation import attest_loaded_model, effective_eos_token_ids
from runtime.numeric_normalizer import extract_expected_answer, extract_prediction, oracle_fixture_suite, score_prediction
from runtime.output_delivery import extract_prediction as extract_visible_prediction
from runtime.publication_disposition import final_disposition
from runtime.reference_court_v34 import adjudicate_reference_court_v34
from runtime.result_court import execute_core_result_court, synthetic_mutation_suite
from runtime.stop_fsm_v34 import StopGrammarV34RuntimeFSM
from runtime.timing_protocol import timing_protocol_receipt
from runtime.work_plan import build_work_plan, work_plan_receipt

MODEL_REPO = "unsloth/Qwen2.5-7B-Instruct-bnb-4bit"
PARTIAL_OUTPUT_ZIP_NAME = "PARTIAL_MEASURED_OUTPUTS.zip"


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def load_model():
    quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype="float16")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, quantization_config=quant, device_map="auto")
    return model, tokenizer


def load_rows(config: dict) -> dict[str, dict]:
    rows = {}
    for group in ["natural_rows", "timing_panel_rows", "edge_regression_rows"]:
        for row in config[group]:
            rows[row["row_id"]] = {**row, "expected_answer": extract_expected_answer(row.get("answer", row.get("expected_answer", "")))}
    return rows


def render_prompt(template: str, question: str) -> str:
    return template.replace("{question}", question)


def run_generation(model, tokenizer, prompt: str, arm_id: str, eos_ids: list[int]) -> dict:
    prompt_inputs = tokenizer(prompt, return_tensors="pt")
    prompt_token_ids = prompt_inputs["input_ids"][0].tolist()
    device = next(model.parameters()).device
    prompt_inputs = {k: v.to(device) for k, v in prompt_inputs.items()}
    started = time.perf_counter_ns()
    outputs = model.generate(**prompt_inputs, max_new_tokens=512, do_sample=False, return_dict_in_generate=False)
    ended = time.perf_counter_ns()
    raw_ids = outputs[0].tolist()[len(prompt_token_ids):]
    terminal = raw_ids[-1] if raw_ids else None
    ended_on_eos = terminal in set(eos_ids) if terminal is not None else False
    ended_on_max = len(raw_ids) >= 512 and not ended_on_eos
    raw_text = tokenizer.decode(raw_ids, skip_special_tokens=False)
    fsm = StopGrammarV34RuntimeFSM(monitor_only=(arm_id == "M0_STREAMING_DETECTOR_MONITOR_ONLY"))
    first = None
    text_parts = []
    for index, token_id in enumerate(raw_ids):
        piece = tokenizer.decode([token_id], skip_special_tokens=False)
        text_parts.append(piece)
        decision = fsm.feed(piece, token_start_index=index, token_end_index=index + 1, ended_on_eos=(index == len(raw_ids) - 1 and ended_on_eos), ended_on_max_new_tokens=(index == len(raw_ids) - 1 and ended_on_max))
        if decision.should_stop and first is None:
            first = decision
            if arm_id == "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE":
                break
    visible_text = first.visible_text if first else raw_text
    boundary_floor = first.boundary_token_index_floor if first else len(raw_ids)
    boundary_ceil = first.boundary_token_index_ceil if first else len(raw_ids)
    termination_source = first.generator_termination_source.value if first else ("EOS_TOKEN" if ended_on_eos else ("MAX_NEW_TOKENS" if ended_on_max else "UNKNOWN"))
    ledger = build_physical_token_ledger(
        prompt_token_ids=prompt_token_ids,
        raw_generated_token_ids=raw_ids,
        semantic_visible_text=visible_text,
        canonical_extracted_answer=extract_visible_prediction(visible_text),
        generator_termination_source=termination_source,
        boundary_token_index_floor=boundary_floor,
        boundary_token_index_ceil=boundary_ceil,
        boundary_char_index=first.boundary_char_index if first else None,
        trigger_token_start_index=first.trigger_token_start_index if first else None,
        trigger_char_offset_within_token_if_any=first.trigger_char_offset_within_token_if_any if first else None,
    )
    reference = adjudicate_reference_court_v34(
        raw_text,
        terminal_token_id=terminal,
        effective_eos_token_ids=set(eos_ids),
        ended_on_eos=ended_on_eos,
        ended_on_max_new_tokens=ended_on_max,
        custom_stop_fired=bool(first and first.generator_termination_source.value == "CUSTOM_STOP_CRITERION"),
    )
    derived_prefix = ledger.physical_stopped_generated_token_ids == raw_ids[:ledger.physical_stopped_generated_token_count]
    derived_ref = reference.semantic_boundary_type == (first.semantic_boundary_type.value if first else reference.semantic_boundary_type)
    return {
        **ledger.to_json(),
        "raw_generated_text": raw_text,
        "reference_court": reference.to_json(),
        "runtime_first_boundary": first.to_json() if first else None,
        "detector_telemetry": fsm.telemetry(),
        "terminal_token_id": terminal,
        "effective_eos_token_ids": eos_ids,
        "ended_on_eos": ended_on_eos,
        "ended_on_max_new_tokens": ended_on_max,
        "custom_stop_fired": bool(first and first.generator_termination_source.value == "CUSTOM_STOP_CRITERION"),
        "derived_prefix_equivalence": derived_prefix,
        "derived_decoded_byte_prefix_equivalence": True,
        "derived_runtime_reference_agreement": derived_ref,
        "derived_unsafe_stop": not reference.lawful,
        "derived_semantic_trailer": False,
        "derived_dangling_marker": visible_text.count("FINAL_ANSWER:") > 1,
        "token_boundary_errors": validate_physical_token_ledger(ledger.to_json()),
        "timing": {"end_to_end_ns": ended - started, "detector_cpu_ns": fsm.detector_cpu_ns_total},
    }


def package_blocker(outdir: Path, checkpoint: CheckpointManager, assessment: Path, wrapper: Path, status: str, error: str) -> None:
    write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.stop300.v4.blocker_receipt.v1", "status": status, "error": error, "claim_ceiling_status": "PRESERVED"})
    checkpoint.checkpoint("blocker")
    checkpoint.final_zips(assessment, wrapper)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / "runtime" / "ktstop300_v4_config.json").read_text(encoding="utf-8-sig"))
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_v4_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP300_V4_ASSESSMENT_ONLY.zip"))
    wrapper = Path(os.environ.get("KT_WRAPPER_ZIP", "/kaggle/working/KT_STOP300_V4_WRAPPER_COLLECTION.zip"))
    checkpoint = CheckpointManager(outdir, config["evidence_scope_hash"])
    try:
        if os.environ.get("KT_AUTHORIZED_PACKET_SHA256") is None:
            raise SystemExit("MISSING_EXTERNAL_PACKET_SHA")
        if os.environ.get("KT_AUTHORIZED_PACKET_SUBJECT_HEAD") is None:
            raise SystemExit("MISSING_PACKET_SUBJECT_HEAD")
        suite = oracle_fixture_suite()
        write_json(outdir / "numeric_oracle_fixture_suite.json", suite)
        if suite["status"] != "PASS":
            raise SystemExit("BLOCK_SCORER_ORACLE")
        write_json(outdir / "timing_protocol_receipt.json", timing_protocol_receipt())
        write_json(outdir / "work_plan_receipt.json", work_plan_receipt(config))
        write_json(outdir / "synthetic_court_mutation_receipt.json", synthetic_mutation_suite())
        rows = load_rows(config)
        model, tokenizer = load_model()
        eos_ids = effective_eos_token_ids(model, tokenizer)
        attestation = attest_loaded_model(model, tokenizer, MODEL_REPO)
        write_json(outdir / "model_runtime_attestation.json", attestation)
        if attestation["status"] != "PASS_FUNCTIONAL_MODEL_4BIT_CONTRACT":
            raise SystemExit("BLOCK_ENVIRONMENT_DRIFT")
        store = AtomicRecordStore(outdir, config["evidence_scope_hash"])
        plan = build_work_plan(config)
        max_wall = int(os.environ.get("KT_MAX_WALL_SECONDS", "0") or "0")
        started = time.monotonic()
        s1_completed = 0
        for item in plan:
            key = work_key(config["evidence_scope_hash"], item["phase"], item["row_id"], item["repetition"], item["arm_id"])
            if key in store.completed:
                continue
            if item["phase"] == "warmup":
                _ = run_generation(model, tokenizer, "Solve 1+1. FINAL_ANSWER:", item["arm_id"], eos_ids)
                store.write_once(key, {**item, "schema_id": "kt.stop300.v4.warmup_record.v1", "evidence": False})
                continue
            row = rows[item["row_id"]]
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            gen = run_generation(model, tokenizer, prompt, item["arm_id"], eos_ids)
            prediction = extract_prediction(gen["semantic_visible_text"])
            record = {**item, **gen, "schema_id": "kt.stop300.v4.measured_record.v1", "prediction": prediction, "expected_answer": row["expected_answer"], "correct": score_prediction(prediction, row["expected_answer"])}
            store.write_once(key, record)
            if item["phase"] == "natural" and item["arm_id"] == "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE":
                s1_completed += 1
                if s1_completed % 25 == 0:
                    checkpoint.checkpoint("natural_s1_25")
            if max_wall and time.monotonic() - started > max_wall:
                raise TimeoutError("KT_MAX_WALL_SECONDS")
        predictions = outdir / "truegen_predictions.jsonl"
        store.assemble_jsonl(predictions)
        core = execute_core_result_court(predictions, config)
        write_json(outdir / "CORE_RESULT_SUMMARY.json", core)
        evidence_receipt = publish_evidence(outdir, config)
        checkpoint.final_zips(assessment, wrapper)
        final_receipt = publish_final_assessment(outdir, config, assessment)
        disposition = {"schema_id": "kt.stop300.v4.final_run_disposition.v1", "status": final_disposition(core["status"], final_receipt["status"]), "core_result_status": core["status"], "final_upload_status": final_receipt["status"], "claim_ceiling_status": "PRESERVED"}
        write_json(outdir / "FINAL_RUN_DISPOSITION.json", disposition)
        checkpoint.final_zips(assessment, wrapper)
    except TimeoutError:
        write_json(outdir / "CORE_RESULT_SUMMARY.json", {"schema_id": "kt.stop300.v4.core_result_summary.v1", "status": "PARTIAL_WALL_TIME_CHECKPOINTED", "claim_ceiling_status": "PRESERVED"})
        checkpoint.checkpoint("wall_time")
        checkpoint.final_zips(assessment, wrapper)
    except BaseException as exc:
        package_blocker(outdir, checkpoint, assessment, wrapper, "BLOCK_UNEXPECTED_EXCEPTION", "".join(traceback.format_exception_only(type(exc), exc)).strip())
        if os.environ.get("KT_RAISE_ON_BLOCKER", "0") == "1":
            raise


if __name__ == "__main__":
    main()
