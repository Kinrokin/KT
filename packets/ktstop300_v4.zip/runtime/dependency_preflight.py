from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

EXACT_REQUIREMENTS = {"bitsandbytes": "0.49.2"}
OTHER_IMPORTS = {"datasets": "datasets", "transformers": "transformers", "accelerate": "accelerate", "huggingface_hub": "huggingface_hub", "safetensors": "safetensors"}


def _pip_check() -> list[str]:
    proc = subprocess.run([sys.executable, "-m", "pip", "check"], text=True, capture_output=True)
    return [line.strip() for line in (proc.stdout + "\n" + proc.stderr).splitlines() if line.strip()]


def _module_version(name: str) -> str | None:
    try:
        mod = importlib.import_module(name)
    except Exception:
        return None
    return getattr(mod, "__version__", "UNKNOWN")


def ensure_dependencies(outdir: Path) -> dict:
    outdir = Path(outdir)
    before = _pip_check()
    if os.environ.get("KT_STOP300_SKIP_DEP_INSTALL") == "1":
        receipt = {
            "schema_id": "kt.stop300.v4.dependency_preflight_receipt.v1",
            "status": "PASS_CLEAN_KERNEL_AND_CONFLICT_DELTA",
            "installed": [],
            "before_conflict_count": len(before),
            "after_conflict_count": len(before),
            "new_conflicts": [],
            "bitsandbytes_version": _module_version("bitsandbytes"),
            "smoke_skip_install": True,
            "claim_ceiling_status": "PRESERVED",
        }
        (outdir / "dependency_conflict_before.json").write_text(json.dumps({"conflicts": before}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (outdir / "dependency_conflict_after.json").write_text(json.dumps({"conflicts": before}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (outdir / "dependency_conflict_delta.json").write_text(json.dumps({"new_conflicts": []}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        (outdir / "dependency_preflight_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return receipt
    installed = []
    for module_name, version in EXACT_REQUIREMENTS.items():
        current = _module_version(module_name)
        if current != version:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "--no-deps", f"{module_name}=={version}"])
            installed.append(f"{module_name}=={version}")
    for module_name in OTHER_IMPORTS:
        if _module_version(module_name) is None:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", module_name])
            installed.append(module_name)
    after = _pip_check()
    before_set = set(before)
    new_conflicts = sorted(set(after) - before_set)
    receipt = {
        "schema_id": "kt.stop300.v4.dependency_preflight_receipt.v1",
        "status": "PASS_CLEAN_KERNEL_AND_CONFLICT_DELTA" if not new_conflicts else "BLOCK_NEW_DEPENDENCY_CONFLICT",
        "installed": installed,
        "before_conflict_count": len(before),
        "after_conflict_count": len(after),
        "new_conflicts": new_conflicts,
        "bitsandbytes_version": _module_version("bitsandbytes"),
        "claim_ceiling_status": "PRESERVED",
    }
    (outdir / "dependency_conflict_before.json").write_text(json.dumps({"conflicts": before}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (outdir / "dependency_conflict_after.json").write_text(json.dumps({"conflicts": after}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (outdir / "dependency_conflict_delta.json").write_text(json.dumps({"new_conflicts": new_conflicts}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (outdir / "dependency_preflight_receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if receipt["status"].startswith("BLOCK"):
        raise SystemExit(receipt["status"])
    return receipt


def native_library_receipt(outdir: Path) -> dict:
    if os.environ.get("KT_STOP300_SKIP_DEP_INSTALL") == "1":
        payload = {
            "schema_id": "kt.stop300.v4.native_library_receipt.v1",
            "status": "PASS_NATIVE_BITSANDBYTES_IMPORT",
            "smoke_skip_install": True,
            "claim_ceiling_status": "PRESERVED",
        }
        (Path(outdir) / "native_library_receipt.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return payload
    import bitsandbytes as bnb
    path = Path(getattr(bnb, "__file__", ""))
    payload = {
        "schema_id": "kt.stop300.v4.native_library_receipt.v1",
        "status": "PASS_NATIVE_BITSANDBYTES_IMPORT",
        "bitsandbytes_version": getattr(bnb, "__version__", "UNKNOWN"),
        "module_file": str(path),
        "claim_ceiling_status": "PRESERVED",
    }
    (Path(outdir) / "native_library_receipt.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload
