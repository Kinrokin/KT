from __future__ import annotations

import hashlib
import json
import warnings
from pathlib import Path


def file_sha(path: str | Path) -> str | None:
    try:
        h = hashlib.sha256()
        with Path(path).open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def effective_eos_token_ids(model, tokenizer) -> list[int]:
    ids = set()
    for obj in [getattr(model, "generation_config", None), getattr(model, "config", None), tokenizer]:
        value = getattr(obj, "eos_token_id", None)
        if isinstance(value, int):
            ids.add(value)
        elif isinstance(value, (list, tuple)):
            ids.update(int(v) for v in value if v is not None)
    return sorted(ids)


def attest_loaded_model(model, tokenizer, model_repo: str) -> dict:
    import torch
    try:
        import bitsandbytes as bnb
        from bitsandbytes.nn import Linear4bit
    except Exception as exc:
        return {"schema_id": "kt.stop300.v4.model_runtime_attestation.v1", "status": "BLOCK_ENVIRONMENT_DRIFT", "error": str(exc), "claim_ceiling_status": "PRESERVED"}
    linear4bit_count = sum(1 for module in model.modules() if isinstance(module, Linear4bit))
    warning_count = 0
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            inputs = tokenizer("1", return_tensors="pt")
            device = next(model.parameters()).device
            inputs = {k: v.to(device) for k, v in inputs.items()}
            with torch.no_grad():
                _ = model(**inputs)
                _ = model.generate(**inputs, max_new_tokens=1, do_sample=False)
            warning_count = len(caught)
    except Exception as exc:
        return {"schema_id": "kt.stop300.v4.model_runtime_attestation.v1", "status": "BLOCK_ENVIRONMENT_DRIFT", "error": str(exc), "linear4bit_module_count": linear4bit_count, "claim_ceiling_status": "PRESERVED"}
    return {
        "schema_id": "kt.stop300.v4.model_runtime_attestation.v1",
        "status": "PASS_FUNCTIONAL_MODEL_4BIT_CONTRACT" if linear4bit_count > 0 and warning_count == 0 else "BLOCK_ENVIRONMENT_DRIFT",
        "functional_model_forward": True,
        "functional_one_token_generation": True,
        "model_repo": model_repo,
        "bitsandbytes_version": getattr(bnb, "__version__", "UNKNOWN"),
        "bitsandbytes_file": getattr(bnb, "__file__", None),
        "bitsandbytes_file_sha256": file_sha(getattr(bnb, "__file__", "")),
        "torch_version": getattr(torch, "__version__", "UNKNOWN"),
        "cuda_available": torch.cuda.is_available(),
        "gpu_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "compute_capability": torch.cuda.get_device_capability(0) if torch.cuda.is_available() else None,
        "model_is_loaded_in_4bit": bool(getattr(model, "is_loaded_in_4bit", False)),
        "linear4bit_module_count": linear4bit_count,
        "hf_device_map": getattr(model, "hf_device_map", None),
        "effective_eos_token_ids": effective_eos_token_ids(model, tokenizer),
        "generation_warning_count": warning_count,
        "claim_ceiling_status": "PRESERVED",
    }
