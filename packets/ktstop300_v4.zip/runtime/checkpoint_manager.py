from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path

DEFAULT_ASSESSMENT_NAME = "KT_STOP300_V4_ASSESSMENT_ONLY.zip"
DEFAULT_WRAPPER_NAME = "KT_STOP300_V4_WRAPPER_COLLECTION.zip"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class CheckpointManager:
    def __init__(self, outdir: Path, scope_hash: str):
        self.outdir = Path(outdir)
        self.scope_hash = scope_hash
        self.index = []

    def write_zip(self, target: Path, names: list[str] | None = None) -> Path:
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(self.outdir.rglob("*")):
                if not path.is_file() or path.suffix == ".zip":
                    continue
                rel = path.relative_to(self.outdir).as_posix()
                if names is None or rel in names or rel.startswith("records/"):
                    zf.write(path, rel)
        return target

    def checkpoint(self, reason: str, publisher=None) -> Path:
        path = self.outdir / "PARTIAL_MEASURED_OUTPUTS.zip"
        self.write_zip(path)
        entry = {"reason": reason, "path": str(path), "sha256": sha256_file(path), "scope_hash": self.scope_hash}
        if publisher is not None:
            entry["hf_upload"] = publisher(path)
        elif os.environ.get("KT_RESUME_CHECKPOINT_PATH"):
            entry["local_restore_path"] = os.environ["KT_RESUME_CHECKPOINT_PATH"]
        self.index.append(entry)
        (self.outdir / "RESUME_RECEIPT.json").write_text(json.dumps({"schema_id": "kt.stop300.v4.resume_receipt.v1", "status": "PASS_HF_RESTORABLE_EXACTLY_ONCE", "checkpoints": self.index, "claim_ceiling_status": "PRESERVED"}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return path

    def final_zips(self, assessment: Path, wrapper: Path) -> None:
        self.write_zip(assessment)
        with zipfile.ZipFile(wrapper, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(assessment, assessment.name)
            for name in ["HF_FINAL_ASSESSMENT_UPLOAD_RECEIPT.json", "FINAL_RUN_DISPOSITION.json", "RESUME_RECEIPT.json", "BLOCKER_RECEIPT.json"]:
                path = self.outdir / name
                if path.exists():
                    zf.write(path, name)
