from __future__ import annotations

import json
import os
from pathlib import Path


def publish_with_api(*, repo_id: str, local_path: Path, path_in_repo: str, is_folder: bool) -> dict:
    from huggingface_hub import HfApi
    api = HfApi()
    if is_folder:
        info = api.upload_folder(repo_id=repo_id, repo_type="dataset", folder_path=str(local_path), path_in_repo=path_in_repo)
    else:
        info = api.upload_file(repo_id=repo_id, repo_type="dataset", path_or_fileobj=str(local_path), path_in_repo=path_in_repo)
    return {"commit": str(info), "path_in_repo": path_in_repo}


def publish_evidence(outdir: Path, config: dict) -> dict:
    repo_id = os.environ.get("KT_HF_RESULTS_REPO", config["hf_results_repo"])
    run_path = f"runs/{config['stable_run_id']}/{os.environ.get('KT_AUTHORIZED_PACKET_SUBJECT_HEAD')}/{os.environ.get('KT_AUTHORIZED_PACKET_SHA256')}/{config['evidence_scope_hash']}"
    if not (os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")):
        return {"schema_id": "kt.stop300.v4.hf_evidence_upload_receipt.v1", "status": "BLOCK_ARTIFACT_PUBLICATION_FAILURE", "reason": "HF_TOKEN_REQUIRED", "run_path": run_path, "claim_ceiling_status": "PRESERVED"}
    evidence = publish_with_api(repo_id=repo_id, local_path=outdir, path_in_repo=f"{run_path}/evidence", is_folder=True)
    receipt = {"schema_id": "kt.stop300.v4.hf_evidence_upload_receipt.v1", "status": "PASS_HF_EVIDENCE_UPLOADED", "run_path": run_path, "evidence": evidence, "claim_ceiling_status": "PRESERVED"}
    (Path(outdir) / "HF_EVIDENCE_UPLOAD_RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return receipt


def publish_final_assessment(outdir: Path, config: dict, assessment_path: Path) -> dict:
    repo_id = os.environ.get("KT_HF_RESULTS_REPO", config["hf_results_repo"])
    run_path = f"runs/{config['stable_run_id']}/{os.environ.get('KT_AUTHORIZED_PACKET_SUBJECT_HEAD')}/{os.environ.get('KT_AUTHORIZED_PACKET_SHA256')}/{config['evidence_scope_hash']}"
    if not (os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")):
        receipt = {"schema_id": "kt.stop300.v4.hf_final_assessment_upload_receipt.v1", "status": "BLOCK_ARTIFACT_PUBLICATION_FAILURE", "reason": "HF_TOKEN_REQUIRED", "run_path": run_path, "claim_ceiling_status": "PRESERVED"}
    else:
        final = publish_with_api(repo_id=repo_id, local_path=assessment_path, path_in_repo=f"{run_path}/{assessment_path.name}", is_folder=False)
        receipt = {"schema_id": "kt.stop300.v4.hf_final_assessment_upload_receipt.v1", "status": "PASS_HF_FINAL_ASSESSMENT_UPLOADED", "final": final, "run_path": run_path, "claim_ceiling_status": "PRESERVED"}
    (Path(outdir) / "HF_FINAL_ASSESSMENT_UPLOAD_RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return receipt
