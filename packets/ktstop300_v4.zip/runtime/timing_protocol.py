from __future__ import annotations

import hashlib

ARMS = ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]


def arm_order(row_id: str, repetition: int) -> list[str]:
    digest = hashlib.sha256(f"ktstop300-v4:{row_id}:{repetition}".encode()).hexdigest()
    start = int(digest[:2], 16) % len(ARMS)
    return ARMS[start:] + ARMS[:start]


def timing_protocol_receipt() -> dict:
    return {
        "schema_id": "kt.stop300.v4.timing_protocol.v1",
        "status": "PASS_60_X_3_X_3",
        "global_warmups_per_arm": 3,
        "warmup_count": 9,
        "timing_records": 540,
        "cuda_events_required": True,
        "perf_counter_ns_required": True,
        "detector_cpu_ns_required": True,
        "tokenization_ns_required": True,
        "row_clustered_paired_bootstrap_required": True,
        "claim_ceiling_status": "PRESERVED",
    }
