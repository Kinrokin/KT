from __future__ import annotations


def final_disposition(core_status: str, final_upload_status: str) -> str:
    if final_upload_status != "PASS_HF_FINAL_ASSESSMENT_UPLOADED":
        return "BLOCK_ARTIFACT_PUBLICATION_FAILURE"
    return core_status
