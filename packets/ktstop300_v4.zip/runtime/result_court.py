from __future__ import annotations

import json
import math
from pathlib import Path

PASS_STATUS = "PASS_CORE_RESULT__PUBLICATION_DISPOSITION_SEPARATE"

PRECEDENCE = [
    "BLOCK_CORRECTNESS_DAMAGE",
    "BLOCK_FIRST_ANSWER_CORRECTION_CUT",
    "BLOCK_PREFIX_EQUIVALENCE",
    "BLOCK_RUNTIME_REFERENCE_DISAGREEMENT",
    "BLOCK_UNSAFE_STOP",
    "BLOCK_SCOPE_MISMATCH",
    "BLOCK_ENVIRONMENT_DRIFT",
    "PARTIAL_WALL_TIME_CHECKPOINTED",
    "BLOCK_TOKEN_ECONOMICS",
    "BLOCK_TIMING_PROTOCOL_VIOLATION",
    "BLOCK_ARTIFACT_PUBLICATION_FAILURE",
]


def exact_zero_event_upper_bound(n: int, alpha: float = 0.05) -> float:
    return 1 - alpha ** (1 / max(n, 1))


def _rows(records):
    return records if isinstance(records, list) else [json.loads(line) for line in Path(records).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def _primary(active: set[str]) -> str:
    for status in PRECEDENCE:
        if status in active:
            return status
    return PASS_STATUS


def _median(values: list[float]) -> float:
    if not values:
        return 0
    ordered = sorted(values)
    return ordered[len(ordered) // 2]


def _trimmed_mean(values: list[float], trim: float = 0.10) -> float:
    if not values:
        return 0
    ordered = sorted(values)
    cut = int(len(ordered) * trim)
    body = ordered[cut: len(ordered) - cut] if len(ordered) - (2 * cut) > 0 else ordered
    return sum(body) / len(body)


def derive_predicates(records, config: dict) -> dict:
    rows = _rows(records)
    natural = [r for r in rows if r.get("phase") == "natural"]
    timing = [r for r in rows if r.get("phase") == "timing"]
    edge = [r for r in rows if r.get("phase") == "edge"]
    warmups = [r for r in rows if r.get("phase") == "warmup"]
    work_keys = [r.get("work_key") for r in rows if r.get("work_key")]
    duplicate_work_keys = len(work_keys) - len(set(work_keys))
    by_row = {}
    for row in natural:
        by_row.setdefault(row["row_id"], {})[row["arm_id"]] = row

    physical_savings = []
    full_savings = []
    correctness_damage = 0
    correction_cut = 0
    prefix_mismatch = 0
    decoded_byte_mismatch = 0
    reference_disagreement = 0
    unsafe = 0
    token_boundary_errors = 0
    semantic_trailers = 0
    dangling_markers = 0
    negative_savings = 0
    rescans = 0
    full_tpc_l0_tokens = 0
    full_tpc_s1_tokens = 0
    correct_count = 0

    for row_id, arms in by_row.items():
        l0 = arms.get("L0_LEGACY_NO_DETECTOR")
        s1 = arms.get("S1_STREAMING_DETECTOR_RUNTIME_TERMINATE")
        if not l0 or not s1:
            continue
        if bool(l0.get("correct")) and not bool(s1.get("correct")):
            correctness_damage += 1
        if s1.get("first_wrong_later_correct") or s1.get("reference_court", {}).get("correction_present"):
            correction_cut += 1
        if s1.get("derived_prefix_equivalence") is False:
            prefix_mismatch += 1
        if s1.get("derived_decoded_byte_prefix_equivalence") is False:
            decoded_byte_mismatch += 1
        if s1.get("derived_runtime_reference_agreement") is False:
            reference_disagreement += 1
        if s1.get("derived_unsafe_stop"):
            unsafe += 1
        token_boundary_errors += len(s1.get("token_boundary_errors", []))
        semantic_trailers += int(bool(s1.get("derived_semantic_trailer")))
        dangling_markers += int(bool(s1.get("derived_dangling_marker")))
        l0_raw = int(l0.get("raw_generated_token_count", 0))
        s1_raw = int(s1.get("raw_generated_token_count", 0))
        l0_prompt = int(l0.get("prompt_token_count", 0))
        s1_prompt = int(s1.get("prompt_token_count", 0))
        physical_delta = l0_raw - s1_raw
        full_delta = (l0_prompt + l0_raw) - (s1_prompt + s1_raw)
        physical_savings.append(physical_delta)
        full_savings.append(full_delta)
        if physical_delta < 0:
            negative_savings += 1
        if bool(l0.get("correct")):
            full_tpc_l0_tokens += l0_prompt + l0_raw
            correct_count += 1
        if bool(s1.get("correct")):
            full_tpc_s1_tokens += s1_prompt + s1_raw
        rescans += int(s1.get("detector_telemetry", {}).get("full_sequence_rescan_count", 0))

    predicate_vector = {
        "natural_pair_matrix_complete": len(by_row) == 300 and len(natural) == 600,
        "timing_matrix_complete": len(timing) == 540,
        "edge_matrix_complete": len(edge) == 36,
        "warmup_matrix_complete": len(warmups) == 9,
        "duplicate_work_key_count": duplicate_work_keys,
        "paired_correctness_damage": correctness_damage,
        "first_wrong_later_corrected_cuts": correction_cut,
        "raw_token_prefix_mismatches": prefix_mismatch,
        "decoded_byte_prefix_mismatches": decoded_byte_mismatch,
        "runtime_reference_disagreements": reference_disagreement,
        "unsafe_stops": unsafe,
        "token_boundary_invariant_errors": token_boundary_errors,
        "semantic_post_boundary_trailers": semantic_trailers,
        "dangling_repeated_markers": dangling_markers,
        "negative_physical_token_savings_rows": negative_savings,
        "median_physical_output_token_savings": _median(physical_savings),
        "trimmed_mean_physical_output_token_savings": _trimmed_mean(physical_savings),
        "aggregate_physical_output_token_reduction": sum(physical_savings),
        "aggregate_full_token_reduction": sum(full_savings),
        "s1_full_tokens_per_correct_lt_l0": (full_tpc_s1_tokens / max(correct_count, 1)) < (full_tpc_l0_tokens / max(correct_count, 1)),
        "full_sequence_rescans": rescans,
    }
    active = set()
    if correctness_damage:
        active.add("BLOCK_CORRECTNESS_DAMAGE")
    if correction_cut:
        active.add("BLOCK_FIRST_ANSWER_CORRECTION_CUT")
    if prefix_mismatch or decoded_byte_mismatch:
        active.add("BLOCK_PREFIX_EQUIVALENCE")
    if reference_disagreement:
        active.add("BLOCK_RUNTIME_REFERENCE_DISAGREEMENT")
    if unsafe or token_boundary_errors or semantic_trailers or dangling_markers:
        active.add("BLOCK_UNSAFE_STOP")
    if duplicate_work_keys:
        active.add("BLOCK_SCOPE_MISMATCH")
    if not predicate_vector["natural_pair_matrix_complete"] or not predicate_vector["timing_matrix_complete"] or not predicate_vector["edge_matrix_complete"] or not predicate_vector["warmup_matrix_complete"]:
        active.add("PARTIAL_WALL_TIME_CHECKPOINTED")
    if negative_savings or predicate_vector["median_physical_output_token_savings"] <= 0 or predicate_vector["trimmed_mean_physical_output_token_savings"] <= 0 or predicate_vector["aggregate_full_token_reduction"] <= 0 or not predicate_vector["s1_full_tokens_per_correct_lt_l0"]:
        active.add("BLOCK_TOKEN_ECONOMICS")
    if rescans:
        active.add("BLOCK_TIMING_PROTOCOL_VIOLATION")
    return {"predicate_vector": predicate_vector, "active_statuses": sorted(active), "primary_status": _primary(active)}


def execute_core_result_court(records, config: dict) -> dict:
    derived = derive_predicates(records, config)
    rows = _rows(records)
    natural_n = len({r["row_id"] for r in rows if r.get("phase") == "natural"})
    return {
        "schema_id": "kt.stop300.v4.core_result_summary.v1",
        "status": derived["primary_status"],
        "active_statuses": derived["active_statuses"],
        "predicate_vector": derived["predicate_vector"],
        "independent_n": natural_n,
        "exact_zero_event_upper_bound": exact_zero_event_upper_bound(natural_n),
        "claim_ceiling_status": "PRESERVED",
    }


def _base_rows() -> list[dict]:
    rows = []
    for i in range(300):
        rows.append({"phase": "natural", "row_id": f"r{i}", "arm_id": "L0_LEGACY_NO_DETECTOR", "correct": True, "prompt_token_count": 100, "raw_generated_token_count": 40, "work_key": f"l0-{i}"})
        rows.append({"phase": "natural", "row_id": f"r{i}", "arm_id": "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE", "correct": True, "prompt_token_count": 100, "raw_generated_token_count": 20, "derived_prefix_equivalence": True, "derived_decoded_byte_prefix_equivalence": True, "derived_runtime_reference_agreement": True, "derived_unsafe_stop": False, "derived_semantic_trailer": False, "derived_dangling_marker": False, "token_boundary_errors": [], "detector_telemetry": {"full_sequence_rescan_count": 0}, "work_key": f"s1-{i}"})
    for i in range(60):
        for rep in range(3):
            for arm in ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
                rows.append({"phase": "timing", "row_id": f"t{i}", "repetition": rep, "arm_id": arm, "work_key": f"t-{i}-{rep}-{arm}"})
    for i in range(12):
        for arm in ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
            rows.append({"phase": "edge", "row_id": f"e{i}", "arm_id": arm, "work_key": f"e-{i}-{arm}"})
    for arm in ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
        for i in range(3):
            rows.append({"phase": "warmup", "row_id": f"w{i}", "arm_id": arm, "work_key": f"w-{arm}-{i}"})
    return rows


def synthetic_mutation_suite() -> dict:
    mutations = {
        "correctness_damage": ("BLOCK_CORRECTNESS_DAMAGE", lambda rows: rows.__setitem__(1, {**rows[1], "correct": False})),
        "first_wrong_later_corrected_cut": ("BLOCK_FIRST_ANSWER_CORRECTION_CUT", lambda rows: rows.__setitem__(1, {**rows[1], "first_wrong_later_correct": True})),
        "raw_token_prefix_mismatch": ("BLOCK_PREFIX_EQUIVALENCE", lambda rows: rows.__setitem__(1, {**rows[1], "derived_prefix_equivalence": False})),
        "decoded_byte_mismatch": ("BLOCK_PREFIX_EQUIVALENCE", lambda rows: rows.__setitem__(1, {**rows[1], "derived_decoded_byte_prefix_equivalence": False})),
        "runtime_reference_mismatch": ("BLOCK_RUNTIME_REFERENCE_DISAGREEMENT", lambda rows: rows.__setitem__(1, {**rows[1], "derived_runtime_reference_agreement": False})),
        "unsafe_stop": ("BLOCK_UNSAFE_STOP", lambda rows: rows.__setitem__(1, {**rows[1], "derived_unsafe_stop": True})),
        "token_boundary_error": ("BLOCK_UNSAFE_STOP", lambda rows: rows.__setitem__(1, {**rows[1], "token_boundary_errors": ["bad"]})),
        "semantic_trailer": ("BLOCK_UNSAFE_STOP", lambda rows: rows.__setitem__(1, {**rows[1], "derived_semantic_trailer": True})),
        "dangling_marker": ("BLOCK_UNSAFE_STOP", lambda rows: rows.__setitem__(1, {**rows[1], "derived_dangling_marker": True})),
        "negative_physical_savings": ("BLOCK_TOKEN_ECONOMICS", lambda rows: rows.__setitem__(1, {**rows[1], "raw_generated_token_count": 50})),
        "zero_median_savings": ("BLOCK_TOKEN_ECONOMICS", lambda rows: [rows.__setitem__(idx, {**rows[idx], "raw_generated_token_count": 40}) for idx in range(1, 600, 2)]),
        "failed_trimmed_mean": ("BLOCK_TOKEN_ECONOMICS", lambda rows: [rows.__setitem__(idx, {**rows[idx], "raw_generated_token_count": 41}) for idx in range(1, 80, 2)]),
        "failed_full_tpc": ("BLOCK_TOKEN_ECONOMICS", lambda rows: [rows.__setitem__(idx, {**rows[idx], "prompt_token_count": 200}) for idx in range(1, 600, 2)]),
        "missing_warmup": ("PARTIAL_WALL_TIME_CHECKPOINTED", lambda rows: rows.pop()),
        "missing_timing_arm": ("PARTIAL_WALL_TIME_CHECKPOINTED", lambda rows: [rows.pop(i) for i in range(len(rows)-1, -1, -1) if rows[i].get("phase") == "timing"][:1]),
        "duplicate_work_key": ("BLOCK_SCOPE_MISMATCH", lambda rows: rows.__setitem__(1, {**rows[1], "work_key": "l0-0"})),
        "partial_with_correctness_damage": ("BLOCK_CORRECTNESS_DAMAGE", lambda rows: (rows.__setitem__(1, {**rows[1], "correct": False}), rows.pop())),
    }
    cases = {}
    for name, (expected, mutate) in mutations.items():
        rows = _base_rows()
        mutate(rows)
        actual = execute_core_result_court(rows, {})["status"]
        cases[name] = {"expected": expected, "actual": actual, "pass": actual == expected}
    return {
        "schema_id": "kt.stop300.v4.synthetic_mutation_suite.v1",
        "status": "PASS_CONJUNCTIVE_FAIL_CLOSED_MUTATION_SUITE" if all(case["pass"] for case in cases.values()) else "FAIL",
        "cases": cases,
    }
