from __future__ import annotations

import hashlib
import json
import os
import re
import time
import zipfile
from collections import defaultdict
from pathlib import Path


RUN_MODE = "RUN_KTPARETO_COUNTERFACTUAL_MICROFURNACE_V1"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
HF_RESULTS_REPO = os.environ.get("KT_HF_RESULTS_REPO", "Kinrokin/ktcf-v1-results")


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def extract_answer(text: str):
    patterns = [
        r"FINAL_ANSWER\s*:\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"####\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"final answer\s*(?:is|:)?\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"answer\s*(?:is|:)?\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return match.group(1).replace("$", "").replace(",", "").strip()
    numbers = re.findall(r"[-+]?\$?[\d,]+(?:\.\d+)?", text)
    return numbers[-1].replace("$", "").replace(",", "").strip() if numbers else None


def alternate_extract_answer(text: str):
    final = extract_answer(text)
    numbers = re.findall(r"[-+]?\$?[\d,]+(?:\.\d+)?", text)
    candidates = []
    if final is not None:
        candidates.append(final)
    if numbers:
        candidates.extend(num.replace("$", "").replace(",", "").strip() for num in numbers[-3:])
    seen = []
    for item in candidates:
        if item not in seen:
            seen.append(item)
    return seen


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def score_answer(output: str, expected: str) -> bool:
    return normalize(extract_answer(output)) == normalize(expected)


def score_candidate(candidate: str, expected: str) -> bool:
    return normalize(candidate) == normalize(expected)


def render_prompt(template: str, question: str) -> str:
    return f"{template}\n\nProblem:\n{question}\n"


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    use_4bit = os.environ.get("KT_LOAD_IN_4BIT", "1") != "0"
    kwargs = {"device_map": "auto", "trust_remote_code": True}
    if use_4bit:
        kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, **kwargs)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


def generate(model, tokenizer, prompt: str, max_new_tokens: int):
    import torch

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    start = time.time()
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    latency_ms = int((time.time() - start) * 1000)
    new_tokens = out[0][inputs["input_ids"].shape[-1]:]
    output = tokenizer.decode(new_tokens, skip_special_tokens=True)
    return output, int(inputs["input_ids"].shape[-1]), int(new_tokens.shape[-1]), latency_ms


def load_checkpoint(path: Path):
    if not path.exists():
        return {}
    return read_json(path)


def save_checkpoint(path: Path, records: dict) -> None:
    write_json(path, records)


def write_blocker(outdir: Path, status: str, reason: str) -> Path:
    write_json(
        outdir / "BLOCKER_RECEIPT.json",
        {
            "schema_id": "kt.ktcf.blocker_receipt.runtime.v1",
            "status": status,
            "reason": reason,
            "run_mode": RUN_MODE,
            "training_authority": False,
            "promotion_authority": False,
            "selector_deployment_authority": False,
            "claim_ceiling_status": "PRESERVED",
        },
    )
    return outdir / "BLOCKER_RECEIPT.json"


def maybe_upload_to_hf(outdir: Path, assessment_zip: Path) -> dict:
    token = os.environ.get("HF_TOKEN")
    if not token:
        return {"schema_id": "kt.ktcf.hf_upload_receipt.v1", "status": "SKIPPED_NO_HF_TOKEN", "repo_id": HF_RESULTS_REPO}
    try:
        from huggingface_hub import HfApi, create_repo, upload_file, upload_folder

        create_repo(HF_RESULTS_REPO, repo_type="dataset", private=False, exist_ok=True, token=token)
        upload_folder(repo_id=HF_RESULTS_REPO, repo_type="dataset", folder_path=str(outdir), path_in_repo="artifacts", token=token)
        upload_file(repo_id=HF_RESULTS_REPO, repo_type="dataset", path_or_fileobj=str(assessment_zip), path_in_repo=assessment_zip.name, token=token)
        info = HfApi(token=token).dataset_info(HF_RESULTS_REPO)
        return {"schema_id": "kt.ktcf.hf_upload_receipt.v1", "status": "PASS", "repo_id": HF_RESULTS_REPO, "url": f"https://huggingface.co/datasets/{HF_RESULTS_REPO}", "private": bool(info.private)}
    except Exception as exc:  # noqa: BLE001
        return {"schema_id": "kt.ktcf.hf_upload_receipt.v1", "status": "FAILED_NON_FATAL", "repo_id": HF_RESULTS_REPO, "error": str(exc)}


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktcf_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktcf_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = outdir / "checkpoint_state.json"
    checkpoint = load_checkpoint(checkpoint_path)

    events = [{"event": "start", "run_mode": RUN_MODE, "row_count": len(config["rows"])}]
    write_json(outdir / "arm_manifest.json", {"schema_id": "kt.ktcf.runtime_arm_manifest.v1", "arms": config["arms"], "run_mode": RUN_MODE})
    write_json(outdir / "prompt_template_manifest.json", {"schema_id": "kt.ktcf.runtime_prompt_template_manifest.v1", "templates": config["prompt_templates"]})
    write_json(outdir / "row_manifest.json", {"schema_id": "kt.ktcf.runtime_row_manifest.v1", "rows": [row for row in config["rows"] if row["role"] == "TARGET"]})
    write_json(outdir / "control_manifest.json", {"schema_id": "kt.ktcf.runtime_control_manifest.v1", "rows": [row for row in config["rows"] if row["role"] != "TARGET"]})
    write_json(outdir / "benchmark_audit_manifest.json", config["benchmark_audit"])
    write_json(outdir / "claim_boundary_receipt.json", config["claim_boundary"])
    write_json(outdir / "safetensors_hash_manifest.json", {"schema_id": "kt.ktcf.safetensors_hash_manifest.v1", "status": "NO_ADAPTERS_USED"})

    try:
        generation_arms = [arm for arm in config["arms"] if arm["arm_type"] == "generation"]
        model, tokenizer = load_model()
        write_json(outdir / "model_loader_receipt.json", {"schema_id": "kt.ktcf.model_loader_receipt.v1", "status": "PASS", "model_repo": MODEL_REPO, "load_in_4bit_via_quantization_config": os.environ.get("KT_LOAD_IN_4BIT", "1") != "0"})

        matrix = list(checkpoint.values())
        completed = set(checkpoint)
        for row in config["rows"]:
            expected = config["scorer_expected_answers"][row["row_id"]]
            for arm in generation_arms:
                key = f"{row['row_id']}::{arm['arm_id']}"
                if key in completed:
                    continue
                template = config["prompt_templates"][arm["prompt_template_id"]]
                prompt = render_prompt(template, row["question"])
                if expected and expected in prompt and config.get("strict_native_answer_literal_block", False):
                    raise RuntimeError(f"expected answer literal appeared in rendered prompt for {key}")
                output, prompt_tokens, output_tokens, latency_ms = generate(model, tokenizer, prompt, int(arm["max_new_tokens"]))
                extracted = extract_answer(output)
                record = {
                    "schema_id": "kt.ktcf.counterfactual_trial_row.v1",
                    "run_mode": RUN_MODE,
                    "row_id": row["row_id"],
                    "global_row": row["global_row"],
                    "role": row["role"],
                    "source_classes": row.get("source_classes", []),
                    "arm_id": arm["arm_id"],
                    "arm_type": arm["arm_type"],
                    "max_new_tokens": arm["max_new_tokens"],
                    "correct": score_candidate(extracted, expected),
                    "extracted_answer": extracted,
                    "expected_answer_hash": row["expected_answer_hash"],
                    "prompt_hash": sha256_text(prompt),
                    "output_hash": sha256_text(output),
                    "output_preview": output[:1000],
                    "prompt_tokens": prompt_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": prompt_tokens + output_tokens,
                    "latency_ms": latency_ms,
                    "training_authority": False,
                    "promotion_authority": False,
                    "selector_deployment_authority": False,
                }
                matrix.append(record)
                checkpoint[key] = record
                completed.add(key)
                save_checkpoint(checkpoint_path, checkpoint)
                events.append({"event": "trial_complete", "key": key, "correct": record["correct"]})

        by_row = defaultdict(list)
        for record in matrix:
            if record.get("arm_type") == "generation":
                by_row[record["row_id"]].append(record)

        finalizer_rows = []
        for row in config["rows"]:
            expected = config["scorer_expected_answers"][row["row_id"]]
            fixed512 = next((item for item in by_row[row["row_id"]] if item["arm_id"] == "A0_FIXED512_BASELINE"), None)
            recovered = False
            candidates = []
            if fixed512:
                candidates = alternate_extract_answer(fixed512.get("output_preview", ""))
                recovered = any(score_candidate(candidate, expected) for candidate in candidates)
            finalizer_rows.append({
                "schema_id": "kt.ktcf.finalizer_replay_row.v1",
                "row_id": row["row_id"],
                "role": row["role"],
                "source_classes": row.get("source_classes", []),
                "source_arm_id": "A0_FIXED512_BASELINE",
                "candidate_answers": candidates,
                "rescored_correct": recovered,
                "interpretation": "FINALIZER_SCORER_OWNED_IF_TRUE",
            })

        oracle_rows = []
        causal_rows = []
        for row in config["rows"]:
            trials = by_row[row["row_id"]]
            correct_trials = [trial for trial in trials if trial["correct"]]
            cheapest = min(correct_trials, key=lambda trial: trial["total_tokens"]) if correct_trials else None
            oracle_rows.append({
                "schema_id": "kt.ktcf.oracle_diagnostic_row.v1",
                "row_id": row["row_id"],
                "role": row["role"],
                "source_classes": row.get("source_classes", []),
                "any_generated_arm_correct": bool(correct_trials),
                "cheapest_correct_arm": cheapest["arm_id"] if cheapest else None,
                "cheapest_correct_tokens": cheapest["total_tokens"] if cheapest else None,
                "hindsight_only_not_deployable": True,
            })
            causal_rows.append({
                "schema_id": "kt.ktcf.causal_verdict_candidate.v1",
                "row_id": row["row_id"],
                "role": row["role"],
                "source_classes": row.get("source_classes", []),
                "candidate_owner": "PENDING_COUNTERFACTUAL_SCORECARD",
                "oracle_generated_any_correct": bool(correct_trials),
                "hindsight_only_not_deployable": True,
            })

        scorecard = []
        for arm in generation_arms:
            rows = [record for record in matrix if record.get("arm_id") == arm["arm_id"]]
            correct = sum(1 for record in rows if record["correct"])
            target_rows = [record for record in rows if record["role"] == "TARGET"]
            control_rows = [record for record in rows if record["role"] != "TARGET"]
            target_correct = sum(1 for record in target_rows if record["correct"])
            control_correct = sum(1 for record in control_rows if record["correct"])
            tokens = sum(int(record["total_tokens"]) for record in rows)
            scorecard.append({
                "schema_id": "kt.ktcf.counterfactual_arm_score.v1",
                "arm_id": arm["arm_id"],
                "row_count": len(rows),
                "correct": correct,
                "accuracy": correct / len(rows) if rows else 0,
                "target_correct": target_correct,
                "target_accuracy": target_correct / len(target_rows) if target_rows else 0,
                "control_correct": control_correct,
                "control_accuracy": control_correct / len(control_rows) if control_rows else 0,
                "full_tokens_per_correct": tokens / correct if correct else None,
                "total_tokens": tokens,
                "claim_bound": arm["claim_bound"],
            })

        finalizer_recovered = sum(1 for row in finalizer_rows if row["rescored_correct"])
        final_summary = {
            "schema_id": "kt.ktcf.final_summary.v1",
            "run_mode": RUN_MODE,
            "status": "PASS_MODEL_GENERATED_AND_SCORED",
            "row_count": len(config["rows"]),
            "target_rows": sum(1 for row in config["rows"] if row["role"] == "TARGET"),
            "control_rows": sum(1 for row in config["rows"] if row["role"] != "TARGET"),
            "generation_trials": len(matrix),
            "finalizer_recovered_count": finalizer_recovered,
            "oracle_any_correct_rows": sum(1 for row in oracle_rows if row["any_generated_arm_correct"]),
            "next_lawful_move": "IMPORT_KTCF_ASSESSMENT_AND_ADJUDICATE_CAUSAL_OWNERSHIP",
            "training_authority": False,
            "promotion_authority": False,
            "selector_deployment_authority": False,
            "claim_ceiling_status": "PRESERVED",
        }

        write_jsonl(outdir / "counterfactual_row_trial_matrix.jsonl", matrix)
        write_json(outdir / "counterfactual_scorecard.json", {"schema_id": "kt.ktcf.counterfactual_scorecard.v1", "scorecard": scorecard})
        write_json(outdir / "finalizer_replay_report.json", {"schema_id": "kt.ktcf.finalizer_replay_report.v1", "rows": finalizer_rows, "recovered_count": finalizer_recovered})
        write_json(outdir / "oracle_diagnostic_receipt.json", {"schema_id": "kt.ktcf.oracle_diagnostic_receipt.v1", "status": "HINDSIGHT_ONLY_NOT_DEPLOYABLE", "rows": oracle_rows})
        write_jsonl(outdir / "causal_verdict_candidates.jsonl", causal_rows)
        write_json(outdir / "final_summary.json", final_summary)
        events.append({"event": "completed", "status": final_summary["status"]})
    except Exception as exc:  # noqa: BLE001
        write_blocker(outdir, "KT_CF_RUNTIME_BLOCKED", str(exc))
        events.append({"event": "blocked", "reason": str(exc)})

    write_jsonl(outdir / "run_events.jsonl", events)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_CF_V1_ASSESSMENT_ONLY.zip"))
    with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(outdir.iterdir()):
            if path.name == "checkpoint_state.json":
                continue
            zf.write(path, path.name)
    upload_receipt = maybe_upload_to_hf(outdir, assessment)
    write_json(outdir / "HF_UPLOAD_RECEIPT.json", upload_receipt)
    with zipfile.ZipFile(assessment, "a", zipfile.ZIP_DEFLATED) as zf:
        zf.write(outdir / "HF_UPLOAD_RECEIPT.json", "HF_UPLOAD_RECEIPT.json")
    print(str(assessment))


if __name__ == "__main__":
    main()
