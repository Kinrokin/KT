# KTCF V1

Targeted counterfactual microfurnace packet for G32S/Pareto hard rows. Expected answers are scorer-side only and never prompt-side. Oracle diagnostics are hindsight-only and not deployable.
