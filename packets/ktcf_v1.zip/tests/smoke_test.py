from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
config = json.loads((root / 'runtime' / 'ktcf_config.json').read_text(encoding='utf-8'))
manifest = json.loads((root / 'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
assert manifest['run_mode'] == 'RUN_KTPARETO_COUNTERFACTUAL_MICROFURNACE_V1'
assert manifest['training_authority'] is False
assert manifest['promotion_authority'] is False
assert manifest['selector_deployment_authority'] is False
assert len([row for row in config['rows'] if row['role'] == 'TARGET']) == 26
assert len([row for row in config['rows'] if row['role'] != 'TARGET']) == 14
assert 'A9_ORACLE_DIAGNOSTIC' in {arm['arm_id'] for arm in config['arms']}
