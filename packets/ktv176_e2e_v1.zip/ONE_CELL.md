# V17.6 Oracle-Autopsy Patched Canary One-Cell

Dataset: `ktv176-e2e-v1`

Packet: `ktv176_e2e_v1.zip`

```python
import pathlib, subprocess, sys, zipfile
packet = pathlib.Path('/kaggle/input/ktv176-e2e-v1/ktv176_e2e_v1.zip')
work = pathlib.Path('/kaggle/working/ktv176_e2e_v1')
work.mkdir(parents=True, exist_ok=True)
zipfile.ZipFile(packet).extractall(work)
subprocess.check_call([sys.executable, 'KTG3FULL_V17_6_ORACLE_AUTOPSY_E2E_V1_RUNNER.py'], cwd=work)
```
