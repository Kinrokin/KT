from __future__ import annotations

import json
import re
import time
import zipfile
from collections import defaultdict
from pathlib import Path


RUN_MODE = "RUN_KTCF_FINALIZER_STOP_SEQUENCE_CANONICALIZER_REPAIR_V1"


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_jsonl(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def score_candidate(candidate, expected) -> bool:
    return normalize(candidate) == normalize(expected)


def final_marker_candidates(text: str) -> list[str]:
    patterns = [
        r"FINAL_ANSWER\s*:\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"####\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
        r"(?:therefore,?\s+)?(?:the\s+)?final answer\s*(?:is|:)?\s*([-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?)",
    ]
    candidates: list[str] = []
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.I):
            candidates.append(match.group(1).replace("$", "").replace(",", "").strip())
    numbers = re.findall(r"[-+]?\$?[\d,]+(?:\.\d+)?", text)
    candidates.extend(num.replace("$", "").replace(",", "").strip() for num in numbers[-3:])
    seen = []
    for candidate in candidates:
        if candidate and candidate not in seen:
            seen.append(candidate)
    return seen


def trailer_after_final_marker(text: str) -> str:
    match = re.search(r"FINAL_ANSWER\s*:\s*[-+]?\$?[\d,]+(?:\.\d+)?(?:/\d+)?", text, re.I)
    if not match:
        return ""
    return text[match.end():].strip()


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktcffix_config.json")
    matrix = read_jsonl(packet_root / "data" / "counterfactual_row_trial_matrix.jsonl")
    outdir = Path("/kaggle/working/ktcffix_outputs")
    outdir.mkdir(parents=True, exist_ok=True)

    start = time.time()
    rows_by_id = {row["row_id"]: row for row in config["rows"]}
    fixed512 = {
        row["row_id"]: row for row in matrix
        if row.get("arm_id") == "A0_FIXED512_BASELINE" and row.get("arm_type") == "generation"
    }

    replay_rows = []
    for row_id, row in rows_by_id.items():
        source = fixed512.get(row_id)
        expected = config["scorer_expected_answers"][row_id]
        output = ""
        if source:
            output = source.get("output_tail") or source.get("output_preview") or ""
        candidates = source.get("finalizer_candidates") if source else []
        candidates = list(dict.fromkeys([*(candidates or []), *final_marker_candidates(output)]))
        v2_correct = any(score_candidate(candidate, expected) for candidate in candidates)
        old_correct = bool(source.get("correct")) if source else False
        trailer = trailer_after_final_marker(output)
        replay_rows.append({
            "schema_id": "kt.ktcffix.finalizer_replay_row.v1",
            "row_id": row_id,
            "role": row.get("role"),
            "source_classes": row.get("source_classes", []),
            "source_arm_id": "A0_FIXED512_BASELINE",
            "legacy_extracted_answer": source.get("extracted_answer") if source else None,
            "legacy_correct": old_correct,
            "canonicalizer_v2_candidates": candidates,
            "canonicalizer_v2_correct": v2_correct,
            "recovered_by_canonicalizer_v2": (not old_correct) and v2_correct,
            "post_final_marker_trailer_present": bool(trailer),
            "post_final_marker_trailer_preview": trailer[:160],
            "stop_sequence_recommended": bool(trailer),
            "claim_ceiling_status": "PRESERVED",
        })

    target_no_correct = [
        row for row in replay_rows
        if row["role"] == "TARGET" and "NO_CORRECT_ARM" in row.get("source_classes", [])
    ]
    recovered = [row for row in target_no_correct if row["canonicalizer_v2_correct"]]
    control_rows = [row for row in replay_rows if row["role"] != "TARGET"]
    control_damage = [row for row in control_rows if row["legacy_correct"] and not row["canonicalizer_v2_correct"]]
    trailer_rows = [row for row in replay_rows if row["post_final_marker_trailer_present"]]

    scorecard = {
        "schema_id": "kt.ktcffix.finalizer_stop_sequence_scorecard.v1",
        "status": "PASS" if len(recovered) >= 4 and not control_damage else "BLOCKED",
        "run_mode": RUN_MODE,
        "model_generation_invoked": False,
        "training_authority": False,
        "promotion_authority": False,
        "selector_deployment_authority": False,
        "target_no_correct_rows": len(target_no_correct),
        "target_no_correct_canonicalizer_v2_correct": len(recovered),
        "control_damage_count": len(control_damage),
        "post_final_marker_trailer_count": len(trailer_rows),
        "stop_sequence_policy": {
            "enabled_for_next_generation_lane": False,
            "recommended_stop_sequences": ["\nYou are an AI assistant", "\nUser will", "\nProblem:"],
            "authority": "DIAGNOSTIC_ONLY_NOT_PRODUCTION_PROMPT_MUTATION",
        },
        "claim_ceiling_status": "PRESERVED",
    }

    run_manifest = {
        "schema_id": "kt.ktcffix.run_manifest.v1",
        "status": "PASS_OFFLINE_CANONICALIZER_REPLAY" if scorecard["status"] == "PASS" else "BLOCKED_CANONICALIZER_REPLAY",
        "run_mode": RUN_MODE,
        "source_assessment_sha256": config["source_assessment_sha256"],
        "row_count": len(replay_rows),
        "elapsed_seconds": round(time.time() - start, 3),
        "no_training": True,
        "no_promotion": True,
        "no_selector_deployment": True,
        "no_adapter_mutation": True,
        "no_production_prompt_mutation": True,
        "claim_ceiling_status": "PRESERVED",
    }

    write_jsonl(outdir / "canonicalizer_repair_predictions.jsonl", replay_rows)
    write_json(outdir / "finalizer_stop_sequence_scorecard.json", scorecard)
    write_json(outdir / "run_manifest.json", run_manifest)
    write_json(outdir / "claim_boundary_receipt.json", config["claim_boundary"])
    write_json(outdir / "source_assessment_import_receipt.json", config["source_assessment_import_receipt"])
    write_json(outdir / "operator_summary.json", {
        "schema_id": "kt.ktcffix.operator_summary.v1",
        "status": scorecard["status"],
        "decision": "CANONICALIZER_REPAIR_SIGNAL_CONFIRMED" if scorecard["status"] == "PASS" else "CANONICALIZER_REPAIR_SIGNAL_BLOCKED",
        "next_lawful_move": "IMPORT_KTCFFIX_ASSESSMENT_AND_DECIDE_REPO_PATCH_OR_PROMPT_CONFIRMATION",
        "claim_ceiling_status": "PRESERVED",
    })

    assessment_zip = outdir / "KTCFFIX_V1_ASSESSMENT_ONLY.zip"
    with zipfile.ZipFile(assessment_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in [
            "canonicalizer_repair_predictions.jsonl",
            "finalizer_stop_sequence_scorecard.json",
            "run_manifest.json",
            "claim_boundary_receipt.json",
            "source_assessment_import_receipt.json",
            "operator_summary.json",
        ]:
            zf.write(outdir / name, arcname=name)
    print(json.dumps({"status": scorecard["status"], "assessment_zip": str(assessment_zip), "claim_ceiling_status": "PRESERVED"}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
