from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'PACKET_MANIFEST.json').read_text(encoding='utf-8'))
config = json.loads((root / 'runtime' / 'ktcffix_config.json').read_text(encoding='utf-8'))
assert manifest['run_mode'] == 'RUN_KTCF_FINALIZER_STOP_SEQUENCE_CANONICALIZER_REPAIR_V1'
assert manifest['training_authority'] is False
assert manifest['promotion_authority'] is False
assert manifest['selector_deployment_authority'] is False
assert len(config['rows']) == 40
assert config['expected_answers_are_scorer_side_only'] is True
