from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

from KT_V1774_TRUEGEN_ARM_CORE import run_truegen_runtime, write_json


EXTRA_ASSESSMENT_FILES = [
    "v17_7_4_control_only_gsm8k_extension_runtime_receipt.json",
    "v17_7_4_control_only_gsm8k_extension_prompt_identity_receipt.json",
    "v17_7_4_control_only_gsm8k_extension_no_parser_runtime_receipt.json",
    "v17_7_4_control_only_gsm8k_extension_answer_leakage_scan_receipt.json",
]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8-sig")) if path.exists() else {}


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()] if path.exists() else []


def authority(**extra):
    payload = {
        "claim_ceiling_preserved": True,
        "runtime_authority": False,
        "promotion_authority": False,
        "adapter_training_authorized": False,
        "router_training_authorized": False,
        "policy_optimization_authorized": False,
        "learned_router_superiority_claim": False,
        "v18_runtime_authority": False,
        "commercial_claim": False,
        "external_validation_claim": False,
        "frontier_claim": False,
        "g2_recovered_claim": False,
        "multi_lobe_superiority_claim": False,
        "production_readiness_claim": False,
        "router_superiority_claim": False,
        "s_tier_claim": False,
        "seven_b_claim": False,
    }
    payload.update(extra)
    return payload


def write_extended_assessment(out: Path) -> None:
    assessment = out / "KTV1774_TRUEGEN_MINIFURNACE_ASSESSMENT_ONLY.zip"
    with zipfile.ZipFile(assessment, "a", compression=zipfile.ZIP_DEFLATED) as archive:
        existing = set(archive.namelist())
        for name in EXTRA_ASSESSMENT_FILES:
            path = out / name
            if path.exists() and name not in existing:
                archive.write(path, name)


def write_control_receipts(runtime_root: Path, out: Path, summary: dict) -> None:
    row_manifest = read_json(runtime_root / "runtime_inputs" / "truegen_row_manifest.json")
    prompt_rows = read_jsonl(out / "truegen_prompt_manifest.jsonl")
    forbidden_hits = []
    for row in prompt_rows:
        prompt = str(row.get("prompt", ""))
        for token in ["expected_answer", "expected_answer_hash", "gold_answer", "gold_label", "oracle_answer"]:
            if token in prompt:
                forbidden_hits.append({"sample_id": row.get("sample_id"), "arm_id": row.get("arm_id"), "token": token})
    write_json(
        out / "v17_7_4_control_only_gsm8k_extension_runtime_receipt.json",
        authority(
            schema_id="kt.v17_7_4.control_only_gsm8k_extension_runtime_receipt.v1",
            status="PASS",
            run_mode=os.environ.get("KT_RUN_MODE"),
            row_count=row_manifest.get("row_count"),
            dataset_mix=row_manifest.get("dataset_mix"),
            evidence_acquisition_only=True,
            parser_repair_runtime=False,
            scratchpad_runtime=False,
            kt_hat_runtime=False,
            route_admission_changes=False,
            no_training=True,
            no_promotion=True,
            no_v18=True,
        ),
    )
    write_json(
        out / "v17_7_4_control_only_gsm8k_extension_prompt_identity_receipt.json",
        authority(
            schema_id="kt.v17_7_4.control_only_gsm8k_extension_prompt_identity_receipt.v1",
            status="PASS" if len(prompt_rows) == row_manifest.get("row_count") else "BLOCKED",
            prompt_rows=len(prompt_rows),
            expected_prompt_rows=row_manifest.get("row_count"),
            known_good_math_act_first_pass_path=True,
            prompt_template_mutation=False,
            finalizer_intervention=False,
            route_admission_changes=False,
            kt_hat_runtime=False,
        ),
    )
    write_json(
        out / "v17_7_4_control_only_gsm8k_extension_no_parser_runtime_receipt.json",
        authority(
            schema_id="kt.v17_7_4.control_only_gsm8k_extension_no_parser_runtime_receipt.v1",
            status="PASS",
            parser_canonicalizer_runtime=False,
            final_answer_contract_v2_runtime=False,
            answer_surface_audit_offline_post_run_only=True,
            no_runtime_candidate_substitution=True,
        ),
    )
    write_json(
        out / "v17_7_4_control_only_gsm8k_extension_answer_leakage_scan_receipt.json",
        authority(
            schema_id="kt.v17_7_4.control_only_gsm8k_extension_answer_leakage_scan_receipt.v1",
            status="PASS" if not forbidden_hits else "BLOCKED",
            forbidden_hits=forbidden_hits,
            expected_answer_model_visible=False,
        ),
    )
    write_extended_assessment(out)


def main() -> int:
    if os.environ.get("KT_RUN_MODE") != "RUN_KTV1774_CONTROL_ONLY_GSM8K_EXTENSION_100":
        raise RuntimeError("KT_BLOCKED__WRAPPER_LANE_IDENTITY_DEFECT")
    runtime_root = Path(__file__).resolve().parent
    out = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktv1774_truegen_outputs"))
    if not out.parent.exists():
        out = Path("ktv1774_truegen_outputs")
    summary = run_truegen_runtime(runtime_root, out=out)
    if summary.get("status") == "PASS":
        write_control_receipts(runtime_root, out, summary)
    return 0 if summary.get("status") == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
