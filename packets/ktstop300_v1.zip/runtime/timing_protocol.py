from __future__ import annotations

import hashlib


ARMS = ["L0_LEGACY_NO_DETECTOR", "M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]


def arm_order(row_id: str, repetition: int) -> list[str]:
    seed = hashlib.sha256(f"ktstop300-v1:{row_id}:{repetition}".encode()).hexdigest()
    start = int(seed[:2], 16) % len(ARMS)
    return ARMS[start:] + ARMS[:start]


def timing_protocol_receipt() -> dict:
    return {"schema_id": "kt.stop300.timing_protocol.v1", "status": "PASS_THREE_ARM_IDENTIFIABLE_TIMING_DEFINED", "arms": ARMS, "warmups_per_arm": 3, "batch_size": 1, "cuda_synchronize": True, "cuda_events_required": True, "claim_ceiling_status": "PRESERVED"}
