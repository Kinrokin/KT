from __future__ import annotations

import re


def normalize(value):
    if value is None:
        return None
    text = str(value).replace(",", "").replace("$", "").strip()
    if not text:
        return None
    try:
        number = float(text)
    except Exception:
        return text.lower()
    return str(int(number)) if number.is_integer() else str(number)


def extract_answer(text: str):
    matches = re.findall(r"(?m)^[ \t]*FINAL_ANSWER\s*:\s*([^\r\n]*)", text)
    target = matches[-1] if matches else text
    fractions = re.findall(r"[-+]?\d[\d,]*\s*/\s*\d[\d,]*", target)
    if fractions:
        return normalize(fractions[-1].replace(" ", ""))
    numbers = re.findall(r"[-+]?\$?\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?", target)
    return normalize(numbers[-1]) if numbers else None


def expected_answer(answer_text: str):
    return answer_text.split("####")[-1].strip() if "####" in answer_text else extract_answer(answer_text)


def score(expected, extracted) -> bool:
    return normalize(expected) == normalize(extracted)


def render_prompt(template: str, question: str) -> str:
    return f"{template}\n\nProblem:\n{question}\n"
