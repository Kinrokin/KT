from __future__ import annotations


def environment_preflight() -> dict:
    receipt = {"schema_id": "kt.stop300.environment_preflight.runtime.v1", "cuda_required": True, "bitsandbytes_version_required": "0.49.2"}
    try:
        import torch
        import bitsandbytes as bnb
        receipt["torch_version"] = getattr(torch, "__version__", "unknown")
        receipt["bitsandbytes_version"] = getattr(bnb, "__version__", "unknown")
        receipt["cuda_available"] = bool(torch.cuda.is_available())
        receipt["status"] = "PASS_FUNCTIONAL_FOR_THIS_EXACT_RUN" if receipt["cuda_available"] and receipt["bitsandbytes_version"] == "0.49.2" else "FAIL_ENVIRONMENT_DRIFT"
    except Exception as exc:
        receipt["status"] = "FAIL_ENVIRONMENT_DRIFT"
        receipt["error"] = str(exc)
    receipt["claim_ceiling_status"] = "PRESERVED"
    return receipt
