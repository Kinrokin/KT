from __future__ import annotations

import json
import os
import time
import zipfile
from pathlib import Path

from runtime.stop_fsm_v31 import StopGrammarV31RuntimeFSM
from runtime.reference_court_v31 import adjudicate_reference_court_v31
from runtime.resume_ledger import ResumeLedger
from runtime.timing_protocol import arm_order, timing_protocol_receipt
from runtime.environment_preflight import environment_preflight
from runtime.effective_config_receipt import generation_config_receipt, quantization_authority_receipt
from runtime.output_delivery import extract_answer, expected_answer, render_prompt, score


RUN_MODE = "RUN_KTSTOP_RUNTIME_STOP_PAIRED300_V1"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")
HF_RESULTS_REPO = os.environ.get("KT_HF_RESULTS_REPO", "Kinrokin/ktstop300-v1-results")


def write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def append_jsonl(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load_rows(config):
    from datasets import load_dataset
    dataset = load_dataset("openai/gsm8k", "main", split="test")
    rows = []
    for row in config["natural_rows"]:
        item = dataset[int(row["split_index"])]
        rows.append({**row, "question": item["question"], "expected_answer": expected_answer(item["answer"])})
    return rows


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, device_map="auto", torch_dtype="auto", trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


def generate(model, tokenizer, prompt: str, *, arm_id: str, max_new_tokens: int = 512):
    import torch
    from transformers import StoppingCriteria, StoppingCriteriaList

    class Stop300Criteria(StoppingCriteria):
        def __init__(self, tokenizer, prompt_len: int, monitor_only: bool):
            self.tokenizer = tokenizer
            self.prompt_len = prompt_len
            self.fsm = StopGrammarV31RuntimeFSM(monitor_only=monitor_only)
            self.last_len = prompt_len
            self.last_decision = None

        def __call__(self, input_ids, scores=None, **kwargs):
            if getattr(input_ids, "shape", [1])[0] != 1:
                raise ValueError("STOP300 batch-size-one only")
            row = input_ids[0]
            new_ids = row[self.last_len:]
            self.last_len = int(row.shape[-1])
            piece = self.tokenizer.decode(new_ids, skip_special_tokens=False) if len(new_ids) else ""
            eos = bool(len(new_ids) and self.tokenizer.eos_token_id is not None and int(new_ids[-1]) == int(self.tokenizer.eos_token_id))
            self.last_decision = self.fsm.feed(piece, eos=eos, token_count=max(len(new_ids), 1))
            try:
                return torch.tensor([bool(self.last_decision.should_stop)], dtype=torch.bool, device=input_ids.device)
            except Exception:
                return bool(self.last_decision.should_stop)

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    prompt_len = int(inputs["input_ids"].shape[-1])
    monitor = arm_id == "M0_STREAMING_DETECTOR_MONITOR_ONLY"
    terminate = arm_id == "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"
    criteria_obj = Stop300Criteria(tokenizer, prompt_len, monitor_only=monitor) if (monitor or terminate) else None
    criteria = StoppingCriteriaList([criteria_obj]) if criteria_obj else None
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    start = time.perf_counter_ns()
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id, stopping_criteria=criteria)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    end = time.perf_counter_ns()
    generated_ids = out[0][prompt_len:].tolist()
    text = tokenizer.decode(generated_ids, skip_special_tokens=True)
    court = adjudicate_reference_court_v31(text)
    telemetry = criteria_obj.fsm.telemetry() if criteria_obj else {"full_sequence_rescan_count": 0}
    decision = criteria_obj.last_decision.to_json() if criteria_obj and criteria_obj.last_decision else None
    return text, generated_ids, prompt_len, end - start, court.to_json(), decision, telemetry


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktstop300_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP300_V1_ASSESSMENT_ONLY.zip"))
    env = environment_preflight()
    write_json(outdir / "environment_contract_receipt.json", env)
    write_json(outdir / "quantization_authority_receipt.json", quantization_authority_receipt(MODEL_REPO))
    gen_cfg = {"max_new_tokens": 512, "do_sample": False}
    write_json(outdir / "generation_config_authority_receipt.json", generation_config_receipt(gen_cfg))
    write_json(outdir / "timing_protocol_receipt.json", timing_protocol_receipt())
    if env["status"] != "PASS_FUNCTIONAL_FOR_THIS_EXACT_RUN":
        write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.stop300.blocker.v1", "status": "BLOCK_ENVIRONMENT_DRIFT", "environment": env, "claim_ceiling_status": "PRESERVED"})
        with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(outdir.glob("*")):
                zf.write(path, path.name)
        return
    model, tokenizer = load_model()
    rows = load_rows(config)
    scope_hash = config["evidence_scope_hash"]
    ledger = ResumeLedger(outdir / "RUN_STATE.json", scope_hash)
    write_json(outdir / "row_manifest.json", {"schema_id": "kt.stop300.row_manifest.runtime.v1", "rows": config["natural_rows"], "row_count": len(config["natural_rows"]), "claim_ceiling_status": "PRESERVED"})
    for row in rows:
        for arm_id in ["L0_LEGACY_NO_DETECTOR", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
            key = ledger.key(row["row_id"], 0, arm_id)
            if key in ledger.completed:
                continue
            prompt = render_prompt(config["base_prompt_template"], row["question"])
            text, ids, prompt_len, ns, court, decision, telemetry = generate(model, tokenizer, prompt, arm_id=arm_id)
            extracted = extract_answer(court["visible_text"] or text)
            rec = {"schema_id": "kt.stop300.prediction_row.v1", "row_id": row["row_id"], "arm_id": arm_id, "repetition": 0, "correct": score(row["expected_answer"], extracted), "extracted_answer": extracted, "raw_generated_token_ids": ids, "raw_generated_text": text, "reference_court": court, "runtime_decision": decision, "detector_telemetry": telemetry, "latency_ns": ns, "claim_ceiling_status": "PRESERVED"}
            append_jsonl(outdir / "predictions.jsonl", rec)
            ledger.mark(row["row_id"], 0, arm_id)
    write_json(outdir / "RESUME_RECEIPT.json", {"schema_id": "kt.stop300.resume_receipt.v1", "status": "PASS", "completed_keys": sorted(ledger.completed), "claim_ceiling_status": "PRESERVED"})
    write_json(outdir / "final_summary.json", {"schema_id": "kt.stop300.final_summary.v1", "status": "MEASURED_OUTPUTS_EMITTED_PENDING_COURT", "run_mode": RUN_MODE, "claim_ceiling_status": "PRESERVED"})
    with zipfile.ZipFile(assessment, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(outdir.glob("*")):
            zf.write(path, path.name)


if __name__ == "__main__":
    main()
