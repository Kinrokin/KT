from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


class ResumeLedger:
    def __init__(self, path: Path, scope_hash: str):
        self.path = Path(path)
        self.scope_hash = scope_hash
        self.completed = set()
        self._load()

    def _load(self):
        if self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8-sig"))
            if data["evidence_scope_hash"] != self.scope_hash:
                raise ValueError("scope hash mismatch")
            self.completed = set(data.get("completed_keys", []))

    def key(self, row_id: str, repetition: int, arm: str) -> str:
        return f"{self.scope_hash}/{row_id}/{repetition}/{arm}"

    def mark(self, row_id: str, repetition: int, arm: str) -> None:
        self.completed.add(self.key(row_id, repetition, arm))
        self.flush()

    def flush(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {"schema_id": "kt.stop300.run_state.v1", "evidence_scope_hash": self.scope_hash, "completed_keys": sorted(self.completed), "resume_safe": True}
        fd, tmp = tempfile.mkstemp(dir=self.path.parent, prefix=self.path.name + ".", suffix=".tmp")
        os.close(fd)
        Path(tmp).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, self.path)
