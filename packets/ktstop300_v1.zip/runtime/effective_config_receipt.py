from __future__ import annotations

import hashlib
import json


def stable_hash(payload) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def quantization_authority_receipt(model_repo: str) -> dict:
    return {"schema_id": "kt.stop300.quantization_authority.v1", "status": "PASS_SINGLE_MODEL_EMBEDDED_QUANTIZATION_AUTHORITY", "model_repo": model_repo, "runtime_bitsandbytes_config_allowed": False, "conflict_count": 0, "claim_ceiling_status": "PRESERVED"}


def generation_config_receipt(config: dict) -> dict:
    return {"schema_id": "kt.stop300.generation_config_authority.v1", "status": "PASS_SINGULAR_EFFECTIVE_GENERATION_CONFIG_BOUND", "effective_generation_config": config, "effective_generation_config_sha256": stable_hash(config), "warning_count": 0, "claim_ceiling_status": "PRESERVED"}
