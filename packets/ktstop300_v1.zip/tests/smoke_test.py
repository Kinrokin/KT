from runtime.stop_fsm_v31 import StopGrammarV31RuntimeFSM
from runtime.reference_court_v31 import adjudicate_reference_court_v31


def test_stop300_fsm_reference_smoke():
    text = 'FINAL_ANSWER: 42\ntrailer'
    runtime = StopGrammarV31RuntimeFSM()
    decision = runtime.feed(text)
    court = adjudicate_reference_court_v31(text)
    assert decision.semantic_boundary_type.value == court.semantic_boundary_type == 'FINAL_LINE_CLOSE'
    assert runtime.full_sequence_rescan_count == 0
