from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path


AUTHORITY_FALSE = {
    "claim_ceiling_preserved": True,
    "runtime_authority": False,
    "promotion_authority": False,
    "adapter_training_authorized": False,
    "learned_router_superiority_claim": False,
    "v18_runtime_authority": False,
}


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def main() -> int:
    root = Path(__file__).resolve().parent
    out = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktv1773_outputs"))
    if not out.parent.exists():
        out = Path("ktv1773_outputs")
    manifest = json.loads((root / "runtime_inputs" / "targeted_boundary_row_manifest.json").read_text(encoding="utf-8"))
    arm_plan = json.loads((root / "runtime_inputs" / "arm_execution_plan.json").read_text(encoding="utf-8"))
    rows = manifest["rows"]
    arms = arm_plan["arms"]
    predictions = [
        {
            "schema_id": "kt.v17_7_3.runtime_prediction_row.v1",
            "sample_id": row["acquisition_row_id"],
            "source_seed_sample_id": row["source_seed_sample_id"],
            "measurement_status": "ACQUISITION_ROW_EMITTED_NOT_MODEL_SCORED",
            "oracle_label_required": row["oracle_label_required"],
            "state_diff_required": row["state_diff_required"],
            **AUTHORITY_FALSE,
        }
        for row in rows
    ]
    arm_results = [
        {
            "schema_id": "kt.v17_7_3.arm_result_row.v1",
            "sample_id": row["acquisition_row_id"],
            "arm_id": arm,
            "measurement_status": "PENDING_KAGGLE_ARM_EXECUTION",
            "score_authority": "NONE_UNTIL_MEASURED",
            **AUTHORITY_FALSE,
        }
        for row in rows
        for arm in arms
    ]
    write_jsonl(out / "benchmark_predictions.jsonl", predictions)
    write_jsonl(out / "arm_result_matrix.jsonl", arm_results)
    common = {
        "schema_id": "kt.v17_7_3.runtime_receipt.v1",
        "status": "ACQUISITION_PACKET_EXECUTED_NOT_EVALUATED",
        "runtime_mode": "RUN_TARGETED_BOUNDARY_ROW_FURNACE",
        "row_count": len(rows),
        "arm_count": len(arms),
        "kaggle_dataset_name": "ktv1773-evidence-v1",
        **AUTHORITY_FALSE,
    }
    for name in [
        "benchmark_scorecard.json",
        "evidence_gap_closure_scorecard.json",
        "conformal_uncertainty_update.json",
        "ope_support_update.json",
        "pfail_calibration_rows.json",
        "do_nothing_counterfactual_update.json",
        "route_boundary_matrix.json",
        "holdout_quarantine_receipt.json",
        "state_diff_contract_receipt.json",
        "oracle_label_integrity_receipt.json",
        "evidence_only_authority_receipt.json",
    ]:
        write_json(out / name, common | {"artifact_name": name})
    assessment = out / "KTV1773_ASSESSMENT_ONLY.zip"
    with zipfile.ZipFile(assessment, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(out.glob("*")):
            if path.name != assessment.name:
                archive.write(path, path.name)
    print(json.dumps(common | {"assessment_zip": assessment.as_posix()}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
