# KT V17.7.3 Evidence Acquisition Micro-Furnace

Dataset: `ktv1773-evidence-v1`
Runtime: `RUN_TARGETED_BOUNDARY_ROW_FURNACE`
Authority: evidence-only; no policy optimization, no training, no promotion.
