# KT V17.7.3 Evidence Acquisition One-Cell
import os, subprocess, sys, zipfile
from pathlib import Path

PACKET = Path("/kaggle/input/ktv1773-evidence-v1/ktv1773_evidence_acquisition_e2e_v1.zip")
if not PACKET.exists():
    PACKET = Path("/kaggle/working/ktv1773_evidence_acquisition_e2e_v1.zip")
assert PACKET.exists(), f"Missing packet: {PACKET}"

work = Path("/kaggle/working/ktv1773_packet")
work.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(PACKET) as z:
    z.extractall(work)

os.environ["KT_RUNTIME_MODE"] = "RUN_TARGETED_BOUNDARY_ROW_FURNACE"
subprocess.check_call([sys.executable, str(work / "KTV1773_MICRO_FURNACE_MASTER_RUNNER.py")])
