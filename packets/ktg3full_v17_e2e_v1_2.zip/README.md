# KTG3FULL V17.1 repaired canary route-value packet

No training. No promotion. Assessment-only output mode.
