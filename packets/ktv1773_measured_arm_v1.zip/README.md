# KTV1773 measured-arm runtime packet

Runtime mode: `RUN_TARGETED_BOUNDARY_ROW_FURNACE_MEASURED_ARMS`
Dataset: `ktv1773-arm-v1`

This packet is evidence-only. It measures/scoring arms from source route-outcome evidence, writes `MODEL_SCORED` rows, recomputes scorecards from row-level artifacts, and fails closed on placeholder statuses.

No training, no policy optimization, no route or adapter promotion, no V18 authority, no learned-router superiority claim.
