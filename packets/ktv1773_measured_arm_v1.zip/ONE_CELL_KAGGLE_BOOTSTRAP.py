from __future__ import annotations

import os
import subprocess
import sys
import zipfile
from pathlib import Path

DATASET = "ktv1773-arm-v1"
PACKET_NAME = "ktv1773_measured_arm_v1.zip"
EXPECTED_SHA256 = "__PACKET_SHA256_FILLED_BY_DOC__"

candidate_roots = [
    Path("/kaggle/input") / DATASET,
    Path("/kaggle/input"),
    Path("/kaggle/working"),
]
candidates = []
for root in candidate_roots:
    if root.exists():
        candidates.extend(root.rglob(PACKET_NAME))
candidates = sorted(set(candidates))
if not candidates:
    raise FileNotFoundError(f"missing {PACKET_NAME} in Kaggle inputs or working dir")
packet = candidates[0]

work = Path("/kaggle/working/ktv1773_measured_arm_packet")
work.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(packet) as archive:
    archive.extractall(work)

os.environ["KT_RUNTIME_MODE"] = "RUN_TARGETED_BOUNDARY_ROW_FURNACE_MEASURED_ARMS"
os.environ["KT_EVIDENCE_ONLY"] = "1"
os.environ["KT_ENABLE_ADAPTER_TRAINING"] = "0"
os.environ["KT_ENABLE_ROUTER_TRAINING"] = "0"
os.environ["KT_ALLOW_POLICY_OPTIMIZATION"] = "0"
os.environ["KT_PROMOTION_ALLOWED"] = "0"
os.environ["KT_ALLOW_V18"] = "0"

subprocess.check_call([sys.executable, str(work / "KTV1773_MEASURED_ARM_MASTER_RUNNER.py")])
