# KTV1774 Real-Arm True-Generation Mini-Furnace

This packet binds the V17.7.4 truegen runner to the intended Qwen 7B substrate and real adapter-source paths. It performs fresh generation or fails closed. It does not train, promote, authorize V18, or claim learned-router superiority.

Set `KT_TRUEGEN_ADAPTER_ROOT` if the Kaggle adapter dataset path differs from the bundled default.
