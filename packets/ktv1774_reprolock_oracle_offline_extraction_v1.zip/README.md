KT V17.7.4 ReproLock/Oracle offline extraction replay bundle. Offline evidence only unless EPC separately authorizes a micro-furnace.
