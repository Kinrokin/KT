from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

AUTHORITY_FALSE = {
    "claim_ceiling_preserved": True,
    "runtime_authority": False,
    "promotion_authority": False,
    "adapter_training_authorized": False,
    "router_training_authorized": False,
    "policy_optimization_authorized": False,
    "learned_router_superiority_claim": False,
    "v18_runtime_authority": False,
}


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    out = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktv1774_truegen_minifurnace_outputs"))
    out.mkdir(parents=True, exist_ok=True)
    config = Path(os.environ.get("KT_TRUEGEN_ARM_MODEL_CONFIG", "/kaggle/input/ktv1774-truegen-config/arm_model_config.json"))
    if not config.exists():
        blocker = dict(
            AUTHORITY_FALSE,
            schema_id="kt.v17_7_4.truegen_minifurnace_blocker.v1",
            status="BLOCKED",
            reason="missing arm_model_config.json with fresh-generation model/adapter bindings",
            required_input=str(config),
            no_fake_pass=True,
            next_lawful_move="SUPPLY_TRUEGEN_ARM_MODEL_CONFIG_AND_RERUN_MINIFURNACE",
        )
        write_json(out / "BLOCKER_RECEIPT.json", blocker)
        with zipfile.ZipFile(out / "KTV1774_TRUEGEN_MINIFURNACE_ASSESSMENT_ONLY.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.write(out / "BLOCKER_RECEIPT.json", "BLOCKER_RECEIPT.json")
        return 2
    manifest = dict(
        AUTHORITY_FALSE,
        schema_id="kt.v17_7_4.truegen_minifurnace_runtime_manifest.v1",
        status="CONFIG_BOUND_NOT_EXECUTED_BY_REPO_SIDE_LANE",
        config_path=str(config),
        no_training=True,
        no_v18=True,
        no_promotion=True,
    )
    write_json(out / "runtime_manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
