# KTV1774 Real-Arm True-Generation Mini-Furnace V1.1

This repaired packet binds the V17.7.4 truegen runner to the intended Qwen 7B substrate and real adapter-source paths. The model loader uses `AutoModelForCausalLM.from_pretrained` and places 4-bit loading inside `BitsAndBytesConfig(..., load_in_4bit=True)` via `quantization_config`. It never forwards `load_in_4bit` as a raw Qwen constructor/from_pretrained kwarg. It performs fresh generation or fails closed. It does not train, promote, authorize V18, or claim learned-router superiority.

Set `KT_TRUEGEN_ADAPTER_ROOT` if the Kaggle adapter dataset path differs from the bundled default.
