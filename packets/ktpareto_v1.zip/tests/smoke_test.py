from pathlib import Path
import json, zipfile
root = Path(__file__).resolve().parents[1]
assert (root / 'runtime' / 'KT_CANONICAL_RUNNER.py').exists()
manifest = json.loads((root / 'PACKET_MANIFEST.json').read_text())
assert manifest['run_mode'] == 'RUN_KT_BUDGET_PARETO_SWEEP_GSM8K_100'
assert manifest['training_authority'] is False
