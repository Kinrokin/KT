# KT Pareto V1

Internal GSM8K Budget Pareto Sweep runtime packet. No training, promotion, selector deployment, adapter mutation, or claim expansion.
