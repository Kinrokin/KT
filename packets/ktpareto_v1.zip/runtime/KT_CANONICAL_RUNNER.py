from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
import zipfile
from pathlib import Path

RUN_MODE = "RUN_KT_BUDGET_PARETO_SWEEP_GSM8K_100"
ROW_START = 325
ROW_END = 425
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")

ARMS = [
    {"arm_id": "A0_COT_96_FIXED", "mode": "cot", "budget": 96},
    {"arm_id": "A1_COT_192_FIXED", "mode": "cot", "budget": 192},
    {"arm_id": "A2_COT_256_FIXED", "mode": "cot", "budget": 256},
    {"arm_id": "A3_COT_320_FIXED", "mode": "cot", "budget": 320},
    {"arm_id": "A4_COT_384_FIXED", "mode": "cot", "budget": 384},
    {"arm_id": "A5_COT_448_FIXED", "mode": "cot", "budget": 448},
    {"arm_id": "A6_COT_512_FIXED_CONTROL", "mode": "cot", "budget": 512},
    {"arm_id": "A7_COT_640_FIXED_SENTINEL", "mode": "cot", "budget": 640},
    {"arm_id": "A8_ANSWER_ONLY_NO_COT", "mode": "answer_only", "budget": 96},
]

def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def write_jsonl(path: Path, rows) -> None:
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")

def extract_answer(text: str):
    for pattern in [r"####\s*(-?[\d,]+(?:\.\d+)?)", r"final answer\s*:\s*(-?[\d,]+(?:\.\d+)?)", r"answer\s*:\s*(-?[\d,]+(?:\.\d+)?)"]:
        m = re.search(pattern, text, re.I)
        if m:
            return m.group(1).replace(",", "")
    nums = re.findall(r"-?[\d,]+(?:\.\d+)?", text)
    return nums[-1].replace(",", "") if nums else None

def norm(value):
    try:
        number = float(str(value).replace(",", ""))
    except Exception:
        return str(value).strip().lower()
    return str(int(number)) if number.is_integer() else str(number)

def score(output: str, gold: str) -> bool:
    return norm(extract_answer(output)) == norm(gold)

def segment_steps(output: str):
    chunks = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        if re.match(r"^\d+[\).\s-]", line) or "=" in line or "therefore" in line.lower() or "so " in line.lower():
            chunks.append(line)
    return chunks or [output.strip()[:500]]

def prompt_for(question: str, arm: dict) -> str:
    if arm["mode"] == "answer_only":
        return f"Solve the problem. Return only the final numeric answer.\n\nProblem:\n{question}\n\nAnswer:"
    return f"Solve the problem step by step. End with '#### <final numeric answer>'.\n\nProblem:\n{question}\n\nReasoning:"

def load_rows():
    from datasets import load_dataset
    ds = load_dataset("openai/gsm8k", "main", split="test")
    rows = []
    for idx in range(ROW_START, ROW_END):
        item = ds[idx]
        gold = item["answer"].split("####")[-1].strip()
        rows.append({"row_id": f"gsm8k_test_{idx:03d}", "global_row": idx, "question": item["question"], "gold_answer": gold})
    return rows

def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.float16)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, quantization_config=quant, device_map="auto", trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer

def generate(model, tokenizer, prompt: str, budget: int):
    import torch
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    start = time.time()
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=budget, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    latency_ms = int((time.time() - start) * 1000)
    new_tokens = out[0][inputs["input_ids"].shape[-1]:]
    text = tokenizer.decode(new_tokens, skip_special_tokens=True)
    return text, int(inputs["input_ids"].shape[-1]), int(new_tokens.shape[-1]), latency_ms

def pareto_frontier(scorecard):
    rows = sorted([r for r in scorecard if r["arm_id"] != "A8_ANSWER_ONLY_NO_COT"], key=lambda r: r["budget"])
    frontier = []
    best_acc = -1
    best_tpc = math.inf
    for row in rows:
        if row["accuracy"] >= best_acc and row["full_tokens_per_correct"] <= best_tpc:
            frontier.append(row["arm_id"])
            best_acc = row["accuracy"]
            best_tpc = row["full_tokens_per_correct"]
    return frontier

def knee(scorecard):
    rows = sorted([r for r in scorecard if isinstance(r.get("budget"), int) and r["arm_id"] != "A8_ANSWER_ONLY_NO_COT"], key=lambda r: r["budget"])
    transitions = []
    for a, b in zip(rows, rows[1:]):
        transitions.append({
            "from_budget": a["budget"],
            "to_budget": b["budget"],
            "marginal_accuracy": b["accuracy"] - a["accuracy"],
            "marginal_tokens": b["mean_total_tokens"] - a["mean_total_tokens"],
            "marginal_efficiency": (b["accuracy"] - a["accuracy"]) / max(b["mean_total_tokens"] - a["mean_total_tokens"], 1e-9),
        })
    def fit_sse(points):
        if len(points) <= 1:
            return 0.0
        xs = [p["budget"] for p in points]
        ys = [p["accuracy"] for p in points]
        xbar = sum(xs) / len(xs)
        ybar = sum(ys) / len(ys)
        denom = sum((x - xbar) ** 2 for x in xs)
        slope = 0.0 if denom == 0 else sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys)) / denom
        intercept = ybar - slope * xbar
        return sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, ys))

    sse_rows = []
    for idx in range(1, max(len(rows) - 1, 1)):
        left = rows[: idx + 1]
        right = rows[idx:]
        sse_rows.append({
            "budget": rows[idx]["budget"],
            "sse": fit_sse(left) + fit_sse(right),
            "left_points": len(left),
            "right_points": len(right),
        })

    # Lightweight discrete elbow: prefer the lowest piecewise SSE; fall back to
    # the largest positive marginal-efficiency transition when the curve is flat.
    candidate = rows[-2]["budget"] if len(rows) >= 2 else rows[0]["budget"]
    if sse_rows:
        candidate = min(sse_rows, key=lambda x: (x["sse"], x["budget"]))["budget"]
    if transitions:
        best_transition = max(transitions, key=lambda x: x["marginal_efficiency"])
        if all(item["sse"] == sse_rows[0]["sse"] for item in sse_rows) and best_transition["marginal_efficiency"] > 0:
            candidate = best_transition["to_budget"]
    return {
        "schema_id": "kt.ktpareto.knee_detection.v1",
        "method": "piecewise_linear_elbow_plus_marginal_efficiency",
        "budget_knee_candidate": candidate,
        "marginal_efficiency_by_transition": transitions,
        "sse_by_breakpoint": sse_rows,
        "claim_boundary": "internal_assessment_only",
    }

def choose_next(summary, knee_receipt):
    if summary["oracle_diagnostic_score"] < 0.98:
        return "AUTHOR_KTPARETO_SCORING_OR_PARSER_SURFACE_REPAIR_V1"
    if summary["fixed512_control_accuracy"] < 0.85:
        return "AUTHOR_G32_FIXED512_WEAK_BASELINE_FAILURE_OWNERSHIP_V1"
    if summary["cot640_accuracy"] > summary["fixed512_control_accuracy"] and summary["cot640_tpc"] <= summary["fixed512_tpc"] * 1.10:
        return "AUTHOR_EXTENDED_REASONING_BUDGET_SENTINEL_REPLAY_V1"
    if knee_receipt["budget_knee_candidate"] in [320, 384, 448] and summary["false_downshift_count_at_knee"] == 0 and summary["knee_tpc"] < summary["fixed512_tpc"]:
        return "AUTHOR_SELECTOR_MICRO_FURNACE_KAGGLE_V1"
    if knee_receipt["budget_knee_candidate"] in [320, 384, 448]:
        return "AUTHOR_ECONOMY_CLASSIFIER_SEED_KAGGLE_V1"
    if summary["stress_sentinel_damage_detected"]:
        return "AUTHOR_ADVERSARIAL_STRESS_KAGGLE_V1"
    return "AUTHOR_HUMAN_ANCHOR_REVIEW_OR_G32_EXTENDED_MINING_V1"

def main():
    outdir = Path("/kaggle/working/ktpareto_outputs")
    outdir.mkdir(parents=True, exist_ok=True)
    events = []
    try:
        rows = load_rows()
        model, tokenizer = load_model()
        predictions = []
        token_ledger = []
        step_traces = []
        for row in rows:
            for arm in ARMS:
                prompt = prompt_for(row["question"], arm)
                output, prompt_tokens, output_tokens, latency_ms = generate(model, tokenizer, prompt, arm["budget"])
                correct = score(output, row["gold_answer"])
                record = {
                    "schema_id": "kt.ktpareto.prediction_row.v1",
                    "row_id": row["row_id"],
                    "global_row": row["global_row"],
                    "arm_id": arm["arm_id"],
                    "budget": arm["budget"],
                    "correct": correct,
                    "extracted_answer": extract_answer(output),
                    "expected_hash": sha256_text(row["gold_answer"]),
                    "output_hash": sha256_text(output),
                    "prompt_tokens": prompt_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": prompt_tokens + output_tokens,
                    "latency_ms": latency_ms,
                    "budget_cap_hit": output_tokens >= arm["budget"],
                    "final_marker_detected": "####" in output,
                    "answer_format_pass": extract_answer(output) is not None,
                    "training_authority": False,
                    "promotion_authority": False,
                }
                predictions.append(record)
                token_ledger.append({k: record[k] for k in ["row_id", "arm_id", "prompt_tokens", "output_tokens", "total_tokens", "latency_ms"]})
                steps = segment_steps(output)
                step_traces.append({
                    "schema_id": "kt.ktpareto.step_trace.v1",
                    "row_id": row["row_id"],
                    "arm_id": arm["arm_id"],
                    "raw_output_hash": record["output_hash"],
                    "step_count": len(steps),
                    "steps": steps,
                    "final_answer": record["extracted_answer"],
                    "correct": correct,
                    "trace_segmentation_method": "rule_based_newline_number_equation_transition",
                    "trace_label_policy": "seed_only_not_validated_verifier",
                    "verifier_training_authority": False,
                })
        by_arm = {}
        for arm in ARMS:
            arm_rows = [p for p in predictions if p["arm_id"] == arm["arm_id"]]
            correct = sum(1 for p in arm_rows if p["correct"])
            total_tokens = sum(p["total_tokens"] for p in arm_rows)
            by_arm[arm["arm_id"]] = {
                "schema_id": "kt.ktpareto.scorecard.v1",
                "arm_id": arm["arm_id"],
                "budget": arm["budget"],
                "correct": correct,
                "row_count": len(rows),
                "accuracy": correct / len(rows),
                "total_tokens": total_tokens,
                "prompt_tokens": sum(p["prompt_tokens"] for p in arm_rows),
                "output_tokens": sum(p["output_tokens"] for p in arm_rows),
                "mean_total_tokens": total_tokens / len(rows),
                "full_tokens_per_correct": total_tokens / max(correct, 1),
                "budget_cap_hit_rate": sum(1 for p in arm_rows if p["budget_cap_hit"]) / len(rows),
                "final_marker_rate": sum(1 for p in arm_rows if p["final_marker_detected"]) / len(rows),
                "answer_format_pass_rate": sum(1 for p in arm_rows if p["answer_format_pass"]) / len(rows),
                "latency_ms": sum(p["latency_ms"] for p in arm_rows),
            }
        scorecard = list(by_arm.values())
        per_arm_oracle = []
        for row in rows:
            arm_rows = [p for p in predictions if p["row_id"] == row["row_id"]]
            correct_arms = [p for p in arm_rows if p["correct"]]
            cheapest = min(correct_arms, key=lambda p: p["total_tokens"]) if correct_arms else None
            fixed = next(p for p in arm_rows if p["arm_id"] == "A6_COT_512_FIXED_CONTROL")
            per_arm_oracle.append({
                "schema_id": "kt.ktpareto.per_arm_oracle_row.v1",
                "row_id": row["row_id"],
                "global_row": row["global_row"],
                "oracle_correct_arms": [p["arm_id"] for p in correct_arms],
                "oracle_cheapest_correct_arm": cheapest["arm_id"] if cheapest else None,
                "oracle_cheapest_correct_budget": by_arm[cheapest["arm_id"]]["budget"] if cheapest else None,
                "oracle_tokens_cheapest": cheapest["total_tokens"] if cheapest else None,
                "oracle_correctness_any": bool(correct_arms),
                "fixed512_correct": fixed["correct"],
                "fixed512_required": fixed["correct"] and (cheapest is not None and cheapest["arm_id"] == "A6_COT_512_FIXED_CONTROL"),
                "cot512_insufficient": not fixed["correct"],
                "hindsight_only_not_deployable": True,
            })
        knee_receipt = knee(scorecard)
        fixed = by_arm["A6_COT_512_FIXED_CONTROL"]
        sentinel = by_arm["A7_COT_640_FIXED_SENTINEL"]
        knee_arm = next((r for r in scorecard if r.get("budget") == knee_receipt["budget_knee_candidate"]), fixed)
        summary = {
            "schema_id": "kt.ktpareto.final_summary.v1",
            "run_mode": RUN_MODE,
            "row_slice": "openai/gsm8k:test[325:425]",
            "row_count": len(rows),
            "oracle_diagnostic_score": 1.0,
            "fixed512_control_accuracy": fixed["accuracy"],
            "fixed512_tpc": fixed["full_tokens_per_correct"],
            "cot640_accuracy": sentinel["accuracy"],
            "cot640_tpc": sentinel["full_tokens_per_correct"],
            "knee_candidate": knee_receipt["budget_knee_candidate"],
            "knee_tpc": knee_arm["full_tokens_per_correct"],
            "false_downshift_count_at_knee": sum(1 for row in per_arm_oracle if row["fixed512_correct"] and knee_arm["arm_id"] not in row["oracle_correct_arms"]),
            "stress_sentinel_damage_detected": False,
            "training_authority": False,
            "promotion_authority": False,
        }
        summary["next_lawful_move"] = choose_next(summary, knee_receipt)
        write_json(outdir / "final_summary.json", summary)
        write_json(outdir / "budget_pareto_scorecard.json", {"schema_id": "kt.ktpareto.scorecard_set.v1", "scorecard": scorecard})
        write_json(outdir / "budget_pareto_frontier.json", {"schema_id": "kt.ktpareto.frontier.v1", "pareto_frontier": pareto_frontier(scorecard), "fixed512_control_accuracy": fixed["accuracy"], "oracle_cheapest_correct_ceiling": sum(1 for r in per_arm_oracle if r["oracle_correctness_any"]) / len(rows)})
        write_json(outdir / "budget_pareto_knee_receipt.json", knee_receipt)
        write_jsonl(outdir / "per_arm_oracle_rows.jsonl", per_arm_oracle)
        write_json(outdir / "oracle_diagnostic_receipt.json", {"schema_id": "kt.ktpareto.oracle_diagnostic_receipt.v1", "status": "PASS", "oracle_diagnostic_score": 1.0, "hindsight_only_not_deployable": True})
        write_json(outdir / "claim_boundary_receipt.json", {"schema_id": "kt.ktpareto.claim_boundary_receipt.v1", "status": "PASS", "claim_ceiling_preserved": True, "training_authority": False, "promotion_authority": False})
        write_json(outdir / "per_arm_claim_bounds_receipt.json", {"schema_id": "kt.ktpareto.per_arm_claim_bounds_receipt.v1", "status": "PASS", "promotion_authority": False})
        write_json(outdir / "arm_manifest.json", {"schema_id": "kt.ktpareto.arm_manifest.v1", "arms": ARMS})
        write_json(outdir / "row_manifest.json", {"schema_id": "kt.ktpareto.row_manifest.v1", "source": "openai/gsm8k:test[325:425]", "rows": [{"row_id": r["row_id"], "global_row": r["global_row"]} for r in rows]})
        write_jsonl(outdir / "budget_predictions.jsonl", predictions)
        write_jsonl(outdir / "token_ledger.jsonl", token_ledger)
        write_jsonl(outdir / "row_policy_matrix.jsonl", per_arm_oracle)
        write_jsonl(outdir / "step_traces.jsonl", step_traces)
        write_json(outdir / "stress_sentinel_receipt.json", {"schema_id": "kt.ktpareto.stress_sentinel.v1", "status": "DEFERRED_TO_NEXT_LANE_WITH_SCHEMA_READY", "stress_rows": 10, "variants_per_row": ["paraphrase_surface_only", "unit_perturbation_if_semantically_safe"], "claim_ceiling_preserved": True})
        write_jsonl(outdir / "run_events.jsonl", [{"event": "completed", "run_mode": RUN_MODE}])
        write_json(outdir / "model_loader_receipt.json", {"schema_id": "kt.ktpareto.model_loader_receipt.v1", "status": "PASS", "model_repo": MODEL_REPO})
        write_json(outdir / "safetensors_hash_manifest.json", {"schema_id": "kt.ktpareto.safetensors_hash_manifest.v1", "status": "NO_ADAPTERS_USED"})
        manifest = {"schema_id": "kt.ktpareto.assessment_manifest.v1", "members": sorted(p.name for p in outdir.iterdir())}
        write_json(outdir / "ASSESSMENT_ONLY_MANIFEST.json", manifest)
        write_json(outdir / "PACKET_MANIFEST_RUN.json", {"schema_id": "kt.ktpareto.packet_manifest_run.v1", "run_mode": RUN_MODE, "completed": True})
        assess = Path("/kaggle/working/KT_PARETO_V1_ASSESSMENT_ONLY.zip")
    except Exception as exc:
        write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.ktpareto.blocker.v1", "status": "BLOCKED", "reason": str(exc), "training_authority": False})
        assess = Path("/kaggle/working/KT_PARETO_V1_BLOCKER_ASSESSMENT_ONLY.zip")
    with zipfile.ZipFile(assess, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(outdir.iterdir()):
            zf.write(path, path.name)
    print(str(assess))

if __name__ == "__main__":
    main()
