# KTV1774 RealBench Compact V1

Runs the same RealBench 50 gauge with compact final-answer contract enabled. It measures full prompt+output tokens separately from visible final-answer tokens, emits an oracle route table, specialist admission atlas, token accounting ledger, finalizer receipt, and G2 compact-path gap analysis. No training, promotion, V18, router-superiority, commercial, frontier, S-tier, 7B, or multi-lobe claim is authorized.
