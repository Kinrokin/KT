from runtime.stop_fsm_v32 import StopGrammarV32RuntimeFSM
from runtime.reference_court_v32 import adjudicate_reference_court_v32
from runtime.timing_protocol import arm_order


def test_stop300_v2_smoke():
    fsm = StopGrammarV32RuntimeFSM()
    decision = fsm.feed('FINAL_ANSWER: 42\ntrailer')
    court = adjudicate_reference_court_v32('FINAL_ANSWER: 42\ntrailer')
    assert decision.semantic_boundary_type.value == court.semantic_boundary_type == 'FINAL_LINE_CLOSE'
    assert fsm.full_sequence_rescan_count == 0
    assert len(arm_order('gsm8k_test_999', 1)) == 3
