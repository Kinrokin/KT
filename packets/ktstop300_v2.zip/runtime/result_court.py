from __future__ import annotations

import json
from pathlib import Path


def execute_result_court(predictions_path: Path, config: dict) -> dict:
    rows = [json.loads(line) for line in predictions_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    natural = [row for row in rows if row["phase"] == "natural"]
    edge = [row for row in rows if row["phase"] == "edge"]
    timing = [row for row in rows if row["phase"] == "timing"]
    full_rescans = sum(int(row.get("detector_telemetry", {}).get("full_sequence_rescan_count", 0)) for row in rows)
    runtime_reference_agree = all(
        not row.get("runtime_decision") or row["runtime_decision"].get("semantic_boundary_type") == row["reference_court"].get("semantic_boundary_type")
        for row in rows
        if row["arm_id"] != "L0_LEGACY_NO_DETECTOR"
    )
    status = "PASS_TOKEN_ONLY__LATENCY_NOT_ESTABLISHED__SHADOW_PACKET_AUTHORING_EARNED"
    if len(natural) < 600 or len(edge) < 36 or len(timing) < 420:
        status = "PARTIAL_WALL_TIME_CHECKPOINTED"
    if not runtime_reference_agree:
        status = "BLOCK_RUNTIME_REFERENCE_DISAGREEMENT"
    if full_rescans != 0:
        status = "BLOCK_TIMING_PROTOCOL_VIOLATION"
    return {
        "schema_id": "kt.stop300.v2.final_summary.v1",
        "status": status,
        "natural_rows": len({row["row_id"] for row in natural}),
        "natural_generation_rows": len(natural),
        "edge_generation_rows": len(edge),
        "timing_generation_rows": len(timing),
        "full_sequence_rescans": full_rescans,
        "runtime_reference_agreement": runtime_reference_agree,
        "claim_ceiling_status": "PRESERVED",
    }
