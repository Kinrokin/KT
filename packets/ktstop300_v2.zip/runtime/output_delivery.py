from __future__ import annotations

import re


def expected_answer(answer: str) -> str:
    if "####" in answer:
        answer = answer.split("####")[-1]
    return re.sub(r"[^0-9.\-]", "", answer).strip()


def extract_answer(text: str) -> str:
    marker = re.search(r"FINAL_ANSWER:\s*([^\n\r]+)", text or "")
    payload = marker.group(1) if marker else text
    numbers = re.findall(r"-?\d+(?:\.\d+)?", payload or "")
    return numbers[-1] if numbers else ""


def score(prediction: str, expected: str) -> bool:
    return str(prediction).strip() == str(expected).strip()


def render_prompt(template: str, question: str) -> str:
    return template.replace("{question}", question)
