from __future__ import annotations

import hashlib
import importlib.metadata
import json
import subprocess
from pathlib import Path


def _sha(path: Path) -> str | None:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception:
        return None


def environment_preflight(model_repo: str) -> dict:
    status = "PASS_FUNCTIONAL_FOR_THIS_EXACT_RUN"
    errors = []
    try:
        import torch
        import bitsandbytes as bnb
        bnb_version = importlib.metadata.version("bitsandbytes")
        if bnb_version != "0.49.2":
            errors.append(f"bitsandbytes_version={bnb_version}")
        cuda_available = torch.cuda.is_available()
        if not cuda_available:
            errors.append("cuda_unavailable")
        wheel_path = Path(getattr(bnb, "__file__", ""))
        native_candidates = list(wheel_path.parent.glob("*bitsandbytes*")) if wheel_path.exists() else []
        if cuda_available:
            device = torch.cuda.get_device_name(0)
            capability = torch.cuda.get_device_capability(0)
        else:
            device = None
            capability = None
        import torch.nn as nn
        smoke = nn.Linear(2, 2).cuda() if cuda_available else None
        if smoke is not None:
            _ = smoke(torch.ones(1, 2, device="cuda"))
    except Exception as exc:
        errors.append(str(exc))
        bnb_version = None
        wheel_path = Path("")
        native_candidates = []
        cuda_available = False
        device = None
        capability = None
    if errors:
        status = "KT_STOP300_V2_ENVIRONMENT_BLOCKED"
    try:
        pip_check = subprocess.run(["python", "-m", "pip", "check"], text=True, capture_output=True, timeout=120)
        pip_check_status = "PASS" if pip_check.returncode == 0 else "FAIL"
    except Exception as exc:
        pip_check_status = f"FAIL:{exc}"
    return {
        "schema_id": "kt.stop300.v2.environment_preflight.v1",
        "status": status,
        "model_repo": model_repo,
        "bitsandbytes_required": "0.49.2",
        "bitsandbytes_version": bnb_version,
        "wheel_path": str(wheel_path) if wheel_path else None,
        "wheel_sha256": _sha(wheel_path) if wheel_path else None,
        "native_library_paths": [str(path) for path in native_candidates],
        "native_library_sha256": {str(path): _sha(path) for path in native_candidates},
        "pip_check_status": pip_check_status,
        "cuda_available": cuda_available,
        "cuda_device": device,
        "cuda_compute_capability": capability,
        "model_loaded_in_4bit_required": True,
        "linear4bit_module_count_gt_zero_required": True,
        "cpu_offload_count_required": 0,
        "disk_offload_count_required": 0,
        "functional_cuda_forward_smoke": not errors,
        "functional_cuda_generation_smoke_required": True,
        "claim_ceiling_status": "PRESERVED",
        "errors": errors,
    }
