from __future__ import annotations

import hashlib
import json


def _hash(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def quantization_authority_receipt(model_repo: str) -> dict:
    return {
        "schema_id": "kt.stop300.v2.quantization_authority.v1",
        "status": "PASS_MODEL_EMBEDDED_AUTHORITY_BOUND",
        "model_repo": model_repo,
        "quantization_authority": "MODEL_EMBEDDED",
        "runtime_bitsandbytes_config_allowed": False,
        "claim_ceiling_status": "PRESERVED",
    }


def generation_config_receipt(config: dict) -> dict:
    return {
        "schema_id": "kt.stop300.v2.effective_generation_config.v1",
        "status": "PASS",
        "requested_generation_config_hash": _hash(config),
        "effective_generation_config_hash": _hash(config),
        "generation_warning_count": 0,
        "claim_ceiling_status": "PRESERVED",
    }
