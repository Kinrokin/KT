from __future__ import annotations

import json
import os
import time
import zipfile
from pathlib import Path

from runtime.checkpoint_manager import CheckpointManager
from runtime.effective_config_receipt import generation_config_receipt, quantization_authority_receipt
from runtime.environment_preflight import environment_preflight
from runtime.hf_publisher import publish_evidence
from runtime.output_delivery import expected_answer, extract_answer, render_prompt, score
from runtime.reference_court_v32 import adjudicate_reference_court_v32
from runtime.result_court import execute_result_court
from runtime.resume_ledger import ResumeLedger
from runtime.stop_fsm_v32 import StopGrammarV32RuntimeFSM
from runtime.timing_protocol import arm_order, timing_protocol_receipt


RUN_MODE = "RUN_KTSTOP_RUNTIME_STOP_PAIRED300_V2"
MODEL_REPO = os.environ.get("KT_MODEL_REPO", "unsloth/Qwen2.5-7B-Instruct-bnb-4bit")


def write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def append_jsonl(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def load_model():
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL_REPO, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(MODEL_REPO, device_map="auto", torch_dtype="auto", trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    return model, tokenizer


def load_dataset_rows(config):
    from datasets import load_dataset
    dataset = load_dataset("openai/gsm8k", "main", split="test")
    out = {}
    for section in ["natural_rows", "timing_panel_rows", "edge_regression_rows"]:
        for row in config.get(section, []):
            idx = int(row["split_index"])
            item = dataset[idx]
            qhash = __import__("hashlib").sha256(item["question"].encode("utf-8")).hexdigest()
            if row.get("question_hash") and row["question_hash"] != qhash:
                raise SystemExit(f"question hash mismatch before model load: {row['row_id']}")
            out[row["row_id"]] = {**row, "question": item["question"], "expected_answer": expected_answer(item["answer"])}
    return out


def generate(model, tokenizer, prompt: str, *, arm_id: str, max_new_tokens: int = 512):
    import torch
    from transformers import StoppingCriteria, StoppingCriteriaList

    class Stop300Criteria(StoppingCriteria):
        def __init__(self, tokenizer, prompt_len: int, monitor_only: bool):
            self.tokenizer = tokenizer
            self.prompt_len = prompt_len
            self.fsm = StopGrammarV32RuntimeFSM(monitor_only=monitor_only)
            self.last_len = prompt_len
            self.last_decision = None

        def __call__(self, input_ids, scores=None, **kwargs):
            if getattr(input_ids, "shape", [1])[0] != 1:
                raise ValueError("STOP300 V2 batch-size-one only")
            row = input_ids[0]
            new_ids = row[self.last_len:]
            self.last_len = int(row.shape[-1])
            piece = self.tokenizer.decode(new_ids, skip_special_tokens=False) if len(new_ids) else ""
            eos = bool(len(new_ids) and self.tokenizer.eos_token_id is not None and int(new_ids[-1]) == int(self.tokenizer.eos_token_id))
            self.last_decision = self.fsm.feed(piece, eos=eos, token_count=max(len(new_ids), 1))
            return torch.tensor([bool(self.last_decision.should_stop)], dtype=torch.bool, device=input_ids.device)

    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    prompt_len = int(inputs["input_ids"].shape[-1])
    monitor_or_stop = arm_id in {"M0_STREAMING_DETECTOR_MONITOR_ONLY", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"}
    criteria_obj = Stop300Criteria(tokenizer, prompt_len, monitor_only=(arm_id == "M0_STREAMING_DETECTOR_MONITOR_ONLY")) if monitor_or_stop else None
    criteria = StoppingCriteriaList([criteria_obj]) if criteria_obj else None
    start_event = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
    end_event = torch.cuda.Event(enable_timing=True) if torch.cuda.is_available() else None
    if torch.cuda.is_available():
        torch.cuda.synchronize()
        start_event.record()
    start_ns = time.perf_counter_ns()
    with torch.no_grad():
        out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id, stopping_criteria=criteria)
    end_ns = time.perf_counter_ns()
    if torch.cuda.is_available():
        end_event.record()
        torch.cuda.synchronize()
    device_ms = float(start_event.elapsed_time(end_event)) if start_event and end_event else None
    generated_ids = out[0][prompt_len:].tolist()
    raw_text = tokenizer.decode(generated_ids, skip_special_tokens=False)
    ref = adjudicate_reference_court_v32(raw_text, ended_on_eos=bool(generated_ids and tokenizer.eos_token_id in generated_ids))
    visible = ref.visible_text
    decision = criteria_obj.last_decision.to_json() if criteria_obj and criteria_obj.last_decision else None
    telemetry = criteria_obj.fsm.telemetry() if criteria_obj else {"full_sequence_rescan_count": 0, "detector_calls": 0, "detector_cpu_ns_total": 0}
    return {
        "raw_generated_token_ids": generated_ids,
        "raw_generated_text": raw_text,
        "authoritative_preserved_token_ids": generated_ids[: len(generated_ids) - max(0, int((decision or {}).get("dropped_trigger_char_count", 0) > 0))],
        "delivered_visible_text": visible,
        "raw_generated_token_count": len(generated_ids),
        "preserved_generated_token_count": len(generated_ids),
        "dropped_trigger_token_count": 0,
        "reference_court": ref.to_json(),
        "runtime_decision": decision,
        "detector_telemetry": telemetry,
        "timing": {"end_to_end_ns": end_ns - start_ns, "cuda_event_generation_ms": device_ms},
    }


def run_work_unit(model, tokenizer, rows_by_id, config, outdir, ledger, checkpoint, *, phase: str, row_id: str, repetition: int, arm_id: str):
    key = ledger.key(phase, row_id, repetition, arm_id)
    if key in ledger.completed:
        return
    row = rows_by_id[row_id]
    prompt = render_prompt(config["base_prompt_template"], row["question"])
    result = generate(model, tokenizer, prompt, arm_id=arm_id)
    extracted = extract_answer(result["delivered_visible_text"] or result["raw_generated_text"])
    rec = {
        "schema_id": "kt.stop300.v2.measured_row.v1",
        "run_mode": RUN_MODE,
        "phase": phase,
        "row_id": row_id,
        "split_index": row["split_index"],
        "stratum": row.get("stratum"),
        "repetition": repetition,
        "arm_id": arm_id,
        "arm_order": arm_order(row_id, repetition),
        "prediction": extracted,
        "expected_answer": row["expected_answer"],
        "correct": score(extracted, row["expected_answer"]),
        **result,
    }
    append_jsonl(outdir / "truegen_predictions.jsonl", rec)
    ledger.mark(phase, row_id, repetition, arm_id)
    if phase == "natural" and arm_id == "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE" and len([k for k in ledger.completed if "/natural/" in k and k.endswith("/S1_STREAMING_DETECTOR_RUNTIME_TERMINATE")]) % 25 == 0:
        checkpoint.write_partial_zip()
    if phase == "timing":
        checkpoint.write_partial_zip()


def main() -> None:
    packet_root = Path(__file__).resolve().parents[1]
    config = read_json(packet_root / "runtime" / "ktstop300_v2_config.json")
    outdir = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktstop300_v2_outputs"))
    outdir.mkdir(parents=True, exist_ok=True)
    assessment = Path(os.environ.get("KT_ASSESSMENT_ZIP", "/kaggle/working/KT_STOP300_V2_ASSESSMENT_ONLY.zip"))
    wrapper = Path(os.environ.get("KT_WRAPPER_ZIP", "/kaggle/working/KT_STOP300_V2_WRAPPER_COLLECTION.zip"))
    env = environment_preflight(MODEL_REPO)
    write_json(outdir / "environment_contract_receipt.json", env)
    write_json(outdir / "quantization_authority_receipt.json", quantization_authority_receipt(MODEL_REPO))
    write_json(outdir / "generation_config_authority_receipt.json", generation_config_receipt({"max_new_tokens": 512, "do_sample": False}))
    write_json(outdir / "timing_protocol_receipt.json", timing_protocol_receipt())
    checkpoint = CheckpointManager(outdir, config["evidence_scope_hash"])
    if env["status"] != "PASS_FUNCTIONAL_FOR_THIS_EXACT_RUN":
        write_json(outdir / "BLOCKER_RECEIPT.json", {"schema_id": "kt.stop300.v2.blocker.v1", "status": "KT_STOP300_V2_ENVIRONMENT_BLOCKED", "environment": env, "claim_ceiling_status": "PRESERVED"})
        checkpoint.write_final_zips(assessment, wrapper)
        return
    rows_by_id = load_dataset_rows(config)
    model, tokenizer = load_model()
    ledger = ResumeLedger(outdir / "RUN_STATE.json", config["evidence_scope_hash"])
    max_wall = int(os.environ.get("KT_MAX_WALL_SECONDS", "0") or "0")
    start = time.monotonic()
    try:
        for row in config["edge_regression_rows"]:
            for arm_id in arm_order(row["row_id"], 0):
                run_work_unit(model, tokenizer, rows_by_id, config, outdir, ledger, checkpoint, phase="edge", row_id=row["row_id"], repetition=0, arm_id=arm_id)
        for row in config["natural_rows"]:
            for arm_id in ["L0_LEGACY_NO_DETECTOR", "S1_STREAMING_DETECTOR_RUNTIME_TERMINATE"]:
                run_work_unit(model, tokenizer, rows_by_id, config, outdir, ledger, checkpoint, phase="natural", row_id=row["row_id"], repetition=0, arm_id=arm_id)
                if max_wall and time.monotonic() - start > max_wall:
                    raise TimeoutError("KT_MAX_WALL_SECONDS")
        for row in config["timing_panel_rows"]:
            for repetition in [0, 1, 2]:
                arms = ["M0_STREAMING_DETECTOR_MONITOR_ONLY"] if repetition == 0 else arm_order(row["row_id"], repetition)
                for arm_id in arms:
                    run_work_unit(model, tokenizer, rows_by_id, config, outdir, ledger, checkpoint, phase="timing", row_id=row["row_id"], repetition=repetition, arm_id=arm_id)
        final_summary = execute_result_court(outdir / "truegen_predictions.jsonl", config)
        write_json(outdir / "final_summary.json", final_summary)
        evidence_receipt = publish_evidence(outdir, config)
        write_json(outdir / "HF_EVIDENCE_UPLOAD_RECEIPT.json", evidence_receipt)
    except TimeoutError:
        checkpoint.write_partial_zip()
        write_json(outdir / "final_summary.json", {"schema_id": "kt.stop300.v2.final_summary.v1", "status": "PARTIAL_WALL_TIME_CHECKPOINTED", "claim_ceiling_status": "PRESERVED"})
    finally:
        checkpoint.write_final_zips(assessment, wrapper)


if __name__ == "__main__":
    main()
