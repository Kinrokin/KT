from __future__ import annotations

import zipfile
from pathlib import Path


class CheckpointManager:
    def __init__(self, outdir: Path, scope_hash: str):
        self.outdir = Path(outdir)
        self.scope_hash = scope_hash

    def _write_zip(self, target: Path, include_all: bool = False) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(self.outdir.glob("*")):
                if path == target or path.suffix == ".zip":
                    continue
                if include_all or path.name in {"truegen_predictions.jsonl", "RUN_STATE.json", "final_summary.json", "environment_contract_receipt.json"}:
                    zf.write(path, path.name)

    def write_partial_zip(self) -> Path:
        target = self.outdir / "PARTIAL_MEASURED_OUTPUTS.zip"
        self._write_zip(target)
        return target

    def write_final_zips(self, assessment: Path, wrapper: Path) -> None:
        self._write_zip(assessment, include_all=True)
        with zipfile.ZipFile(wrapper, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(assessment, assessment.name)
            partial = self.outdir / "PARTIAL_MEASURED_OUTPUTS.zip"
            if partial.exists():
                zf.write(partial, partial.name)
