from __future__ import annotations

import os
from pathlib import Path


def publish_evidence(outdir: Path, config: dict) -> dict:
    run_id = config.get("run_id", "ktstop300_v2")
    repo_head = config.get("repo_head", "unknown")
    packet_sha = config.get("packet_sha256", "unknown")
    path = f"runs/{run_id}/{repo_head}/{packet_sha}/"
    token_present = bool(os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN"))
    return {
        "schema_id": "kt.stop300.v2.hf_evidence_upload_receipt.v1",
        "status": "HF_UPLOAD_SKIPPED_NO_TOKEN" if not token_present else "READY_FOR_HF_UPLOAD",
        "immutable_path": path,
        "claim_ceiling_status": "PRESERVED",
    }
