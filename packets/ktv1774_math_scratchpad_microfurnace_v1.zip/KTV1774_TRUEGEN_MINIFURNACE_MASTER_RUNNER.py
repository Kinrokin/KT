from KTV1774_MATH_SCRATCHPAD_MICROFURNACE_RUNNER import main
raise SystemExit(main())
