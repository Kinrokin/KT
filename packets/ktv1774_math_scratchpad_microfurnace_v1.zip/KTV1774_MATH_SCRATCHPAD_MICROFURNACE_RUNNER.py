from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

from KT_V1774_TRUEGEN_ARM_CORE import REPROLOCK_ARM_ID, read_json, read_jsonl, run_truegen_runtime, write_json


EXTRA_ASSESSMENT_FILES = [
    "v17_7_4_math_scratchpad_runtime_receipt.json",
    "v17_7_4_math_scratchpad_token_ledger_receipt.json",
    "v17_7_4_math_scratchpad_evaluation_gate.json",
]


def authority(**extra):
    payload = {
        "claim_ceiling_preserved": True,
        "runtime_authority": False,
        "promotion_authority": False,
        "adapter_training_authorized": False,
        "router_training_authorized": False,
        "policy_optimization_authorized": False,
        "learned_router_superiority_claim": False,
        "v18_runtime_authority": False,
        "commercial_claim": False,
        "external_validation_claim": False,
        "frontier_claim": False,
        "g2_recovered_claim": False,
        "heldout_generalization_claim": False,
        "multi_lobe_superiority_claim": False,
        "production_readiness_claim": False,
        "router_superiority_claim": False,
        "s_tier_claim": False,
        "seven_b_claim": False,
    }
    payload.update(extra)
    return payload


def append_assessment(out: Path) -> None:
    assessment = out / "KTV1774_TRUEGEN_MINIFURNACE_ASSESSMENT_ONLY.zip"
    if not assessment.exists():
        return
    with zipfile.ZipFile(assessment, "a", compression=zipfile.ZIP_DEFLATED) as archive:
        existing = set(archive.namelist())
        for name in EXTRA_ASSESSMENT_FILES:
            path = out / name
            if path.exists() and name not in existing:
                archive.write(path, name)


def write_scratchpad_receipts(runtime_root: Path, out: Path) -> None:
    matrix = read_jsonl(out / "truegen_arm_result_matrix.jsonl")
    token_ledger = read_json(out / "token_accounting_ledger.json")
    config = read_json(runtime_root / "runtime_inputs" / "arm_model_config.json")
    manifest = read_json(runtime_root / "runtime_inputs" / "truegen_row_manifest.json")
    scratchpad_arms = [arm["arm_id"] for arm in config.get("arms", []) if int(arm.get("scratchpad_budget_tokens") or 0) > 0]
    control_rows = [row for row in matrix if row.get("arm_id") == REPROLOCK_ARM_ID]
    scratchpad_rows = [row for row in matrix if row.get("arm_id") in scratchpad_arms]
    non_math_rows = [row for row in matrix if row.get("dataset") != "gsm8k"]
    token_defects = [
        row.get("sample_id")
        for row in scratchpad_rows
        if int(row.get("reasoning_tokens") or 0) > 0 and int(row.get("full_prompt_plus_output_tokens") or 0) < int(row.get("reasoning_tokens") or 0)
    ]
    write_json(
        out / "v17_7_4_math_scratchpad_runtime_receipt.json",
        authority(
            schema_id="kt.v17_7_4.math_scratchpad_runtime_receipt.v1",
            status="PASS" if not non_math_rows else "BLOCKED_NON_MATH_ROW_PRESENT",
            run_mode=os.environ.get("KT_RUN_MODE", ""),
            row_count=manifest.get("row_count"),
            dataset_mix=manifest.get("dataset_mix"),
            scratchpad_arms=scratchpad_arms,
            no_scratchpad_control_arm=REPROLOCK_ARM_ID,
            kt_hat_contamination=False,
            route_admission_changes=False,
            finalizer_v2_enabled=False,
            no_training=True,
            no_promotion=True,
            no_v18=True,
        ),
    )
    write_json(
        out / "v17_7_4_math_scratchpad_token_ledger_receipt.json",
        authority(
            schema_id="kt.v17_7_4.math_scratchpad_token_ledger_receipt.v1",
            status="PASS" if not token_defects else "BLOCKED_SCRATCHPAD_TOKEN_LEDGER_DEFECT",
            scratchpad_tokens_count_in_full_tpc=True,
            scratchpad_audit_visible=True,
            full_token_ledger_path="token_accounting_ledger.json",
            accounting_modes=token_ledger.get("accounting_modes", []),
            token_defects=token_defects,
        ),
    )
    arm_counts = {}
    for arm_id in [REPROLOCK_ARM_ID, *scratchpad_arms]:
        rows = [row for row in matrix if row.get("arm_id") == arm_id]
        arm_counts[arm_id] = {
            "correct": sum(1 for row in rows if row.get("correct") is True),
            "total": len(rows),
            "full_tokens": sum(int(row.get("full_prompt_plus_output_tokens") or 0) for row in rows),
            "reasoning_tokens": sum(int(row.get("reasoning_tokens") or 0) for row in rows),
        }
    write_json(
        out / "v17_7_4_math_scratchpad_evaluation_gate.json",
        authority(
            schema_id="kt.v17_7_4.math_scratchpad_evaluation_gate.v1",
            status="PASS",
            promotion_eligible=False,
            runtime_authority=False,
            control_arm=REPROLOCK_ARM_ID,
            arm_counts=arm_counts,
            success_interpretation="evidence only; scratchpad survives only if GSM8K improves without hidden token cost",
        ),
    )
    append_assessment(out)


def main() -> int:
    runtime_root = Path(__file__).resolve().parent
    out = Path(os.environ.get("KT_OUTPUT_DIR", "/kaggle/working/ktv1774_math_scratchpad_outputs"))
    if not out.parent.exists():
        out = Path("ktv1774_math_scratchpad_outputs")
    os.environ.setdefault("KT_COMPACT_ANSWER_CONTRACT", "1")
    os.environ.setdefault("KT_REASONING_PRESERVING_COMPACT", "1")
    summary = run_truegen_runtime(runtime_root, out=out)
    if summary.get("status") == "PASS":
        write_scratchpad_receipts(runtime_root, out)
    return 0 if summary.get("status") == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
