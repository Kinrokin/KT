Sample deterministic proof bundle contents.
